package com.blog.service;

import com.blog.entity.Category;
import com.blog.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * 分類業務邏輯服務
 */
@Service
@Transactional
public class CategoryService {
    
    @Autowired
    private CategoryRepository categoryRepository;
    
    /**
     * 查找所有啟用的分類
     */
    @Transactional(readOnly = true)
    public List<Category> findActiveCategories() {
        List<Category> categories = categoryRepository.findActiveCategories();
        
        // 如果沒有分類數據，初始化默認分類
        if (categories.isEmpty()) {
            initializeDefaultCategories();
            categories = categoryRepository.findActiveCategories();
        }
        
        return categories;
    }
    
    /**
     * 初始化默認分類
     */
    public void initializeDefaultCategories() {
        String[][] defaultCategories = {
            {"技術分享", "tech-sharing", "技術相關的知識分享和討論"},
            {"生活日記", "life-diary", "日常生活的記錄和感悟"},
            {"教學文章", "tutorial", "教學指南和學習資源"}
        };
        
        for (String[] categoryData : defaultCategories) {
            if (!categoryRepository.existsByName(categoryData[0])) {
                Category category = new Category();
                category.setName(categoryData[0]);
                category.setSlug(categoryData[1]);
                category.setDescription(categoryData[2]);
                category.setIsActive(true);
                categoryRepository.save(category);
            }
        }
    }
    
    /**
     * 根據ID查找分類
     */
    @Transactional(readOnly = true)
    public Optional<Category> findById(Integer categoryId) {
        return categoryRepository.findById(categoryId);
    }
    
    /**
     * 根據路徑查找分類
     */
    @Transactional(readOnly = true)
    public Optional<Category> findBySlug(String slug) {
        return categoryRepository.findBySlug(slug);
    }
    
    /**
     * 根據名稱查找分類
     */
    @Transactional(readOnly = true)
    public Optional<Category> findByName(String name) {
        return categoryRepository.findByName(name);
    }
    
    /**
     * 創建新分類
     */
    public Category createCategory(Category category) {
        // 驗證分類名稱唯一性
        if (categoryRepository.existsByName(category.getName())) {
            throw new RuntimeException("分類名稱已存在");
        }
        
        // 如果沒有設定路徑，生成一個
        if (category.getSlug() == null || category.getSlug().isEmpty()) {
            category.setSlug(generateSlug(category.getName()));
        }
        
        // 確保路徑唯一性
        category.setSlug(ensureUniqueSlug(category.getSlug()));
        
        return categoryRepository.save(category);
    }
    
    /**
     * 更新分類
     */
    public Category updateCategory(Integer categoryId, Category updatedCategory) {
        Category existingCategory = categoryRepository.findById(categoryId)
            .orElseThrow(() -> new RuntimeException("分類不存在"));
        
        // 檢查名稱唯一性（排除當前分類）
        if (!existingCategory.getName().equals(updatedCategory.getName()) &&
            categoryRepository.existsByName(updatedCategory.getName())) {
            throw new RuntimeException("分類名稱已存在");
        }
        
        // 更新欄位
        existingCategory.setName(updatedCategory.getName());
        existingCategory.setDescription(updatedCategory.getDescription());
        existingCategory.setColor(updatedCategory.getColor());
        existingCategory.setIsActive(updatedCategory.getIsActive());
        
        // 如果路徑為空，重新生成
        if (updatedCategory.getSlug() == null || updatedCategory.getSlug().isEmpty()) {
            existingCategory.setSlug(generateSlug(updatedCategory.getName()));
        } else {
            existingCategory.setSlug(updatedCategory.getSlug());
        }
        
        // 確保路徑唯一性（排除當前分類）
        existingCategory.setSlug(ensureUniqueSlug(existingCategory.getSlug(), categoryId));
        
        return categoryRepository.save(existingCategory);
    }
    
    /**
     * 刪除分類
     */
    public void deleteCategory(Integer categoryId) {
        Category category = categoryRepository.findById(categoryId)
            .orElseThrow(() -> new RuntimeException("分類不存在"));
        
        // 檢查是否有文章使用此分類
        Long postCount = categoryRepository.countPublishedPostsByCategory(categoryId);
        if (postCount > 0) {
            throw new RuntimeException("此分類下還有 " + postCount + " 篇文章，無法刪除");
        }
        
        categoryRepository.delete(category);
    }
    
    /**
     * 搜尋分類
     */
    @Transactional(readOnly = true)
    public Page<Category> searchCategories(String keyword, Pageable pageable) {
        return categoryRepository.searchCategories(keyword, pageable);
    }
    
    /**
     * 查找分類及其文章數量
     */
    @Transactional(readOnly = true)
    public List<Object[]> findCategoriesWithPostCount() {
        return categoryRepository.findCategoriesWithPostCount();
    }
    
    /**
     * 統計分類的已發布文章數量
     */
    @Transactional(readOnly = true)
    public Long countPublishedPostsByCategory(Integer categoryId) {
        return categoryRepository.countPublishedPostsByCategory(categoryId);
    }
    
    /**
     * 啟用/禁用分類
     */
    public Category toggleCategoryStatus(Integer categoryId) {
        Category category = categoryRepository.findById(categoryId)
            .orElseThrow(() -> new RuntimeException("分類不存在"));
        
        category.setIsActive(!category.getIsActive());
        return categoryRepository.save(category);
    }
    
    // 私有輔助方法
    
    /**
     * 生成分類路徑
     */
    private String generateSlug(String name) {
        return name.toLowerCase()
                .replaceAll("[^a-z0-9\\u4e00-\\u9fff\\s-]", "") // 保留中文、英文、數字、空格和連字符
                .replaceAll("\\s+", "-") // 空格替換為連字符
                .replaceAll("-+", "-") // 多個連字符合併為一個
                .replaceAll("^-|-$", ""); // 移除開頭和結尾的連字符
    }
    
    /**
     * 確保路徑唯一性
     */
    private String ensureUniqueSlug(String baseSlug) {
        return ensureUniqueSlug(baseSlug, null);
    }
    
    /**
     * 確保路徑唯一性（排除指定ID）
     */
    private String ensureUniqueSlug(String baseSlug, Integer excludeId) {
        String slug = baseSlug;
        int counter = 1;
        
        while (categoryRepository.existsBySlug(slug)) {
            // 如果是更新操作，檢查是否為當前分類本身
            if (excludeId != null) {
                Optional<Category> existing = categoryRepository.findBySlug(slug);
                if (existing.isPresent() && existing.get().getCategoryId().equals(excludeId)) {
                    break;
                }
            }
            
            slug = baseSlug + "-" + counter;
            counter++;
        }
        
        return slug;
    }

    /**
     * 計算總分類數量
     */
    public long countAll() {
        return categoryRepository.count();
    }

    /**
     * 計算活躍分類數量
     */
    public long countActive() {
        return categoryRepository.countByIsActiveTrue();
    }

    /**
     * 計算分類的文章數量
     */
    public Long countPostsByCategory(Integer categoryId) {
        return categoryRepository.countPublishedPostsByCategory(categoryId);
    }

    /**
     * 保存分類（新增或更新）
     */
    public Category save(Category category) {
        if (category.getCategoryId() == null) {
            // 新增
            return createCategory(category);
        } else {
            // 更新
            return updateCategory(category.getCategoryId(), category);
        }
    }

    /**
     * 根據ID刪除分類
     */
    public void deleteById(Integer categoryId) {
        deleteCategory(categoryId);
    }
} 