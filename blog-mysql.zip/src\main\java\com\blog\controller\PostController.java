package com.blog.controller;

import com.blog.dto.request.CreatePostRequest;
import com.blog.dto.response.PostResponse;
import com.blog.entity.Post;
import com.blog.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.transaction.annotation.Transactional;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Optional;

/**
 * 文章 REST API 控制器
 */
@RestController
@RequestMapping("/api/posts")
@CrossOrigin(origins = "*")
public class PostController {
    
    @Autowired
    private PostService postService;
    
    /**
     * 獲取已發布文章列表
     */
    @GetMapping
    @Transactional(readOnly = true)
    public ResponseEntity<Page<PostResponse>> getPublishedPosts(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "latest") String sort,
            @RequestParam(required = false) String author,
            @RequestParam(required = false) String category) {
        
        Page<Post> posts;
        if (author != null && !author.trim().isEmpty()) {
            // 如果指定了作者，根據作者用戶名篩選文章
            posts = postService.findPublishedPostsByAuthorUsername(author.trim(), page, size, sort);
        } else if (category != null && !category.trim().isEmpty()) {
            // 如果指定了分類，根據分類名稱或slug篩選文章
            posts = postService.findPublishedPostsByCategoryNameOrSlug(category.trim(), page, size, sort);
        } else {
            // 否則獲取所有已發布文章
            posts = postService.findPublishedPosts(page, size, sort);
        }
        
        Page<PostResponse> response = posts.map(this::convertToResponse);
        return ResponseEntity.ok(response);
    }
    
    /**
     * 根據ID獲取文章
     */
    @GetMapping("/{id}")
    public ResponseEntity<PostResponse> getPostById(@PathVariable Integer id) {
        Optional<Post> post = postService.findById(id);
        if (post.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        // 增加瀏覽次數
        postService.incrementViewCount(id);
        
        PostResponse response = convertToResponse(post.get());
        return ResponseEntity.ok(response);
    }
    
    /**
     * 根據路徑獲取文章
     */
    @GetMapping("/slug/{slug}")
    public ResponseEntity<PostResponse> getPostBySlug(@PathVariable String slug) {
        Optional<Post> post = postService.findBySlug(slug);
        if (post.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        // 增加瀏覽次數
        postService.incrementViewCount(post.get().getPostId());
        
        PostResponse response = convertToResponse(post.get());
        return ResponseEntity.ok(response);
    }
    
    /**
     * 創建新文章
     */
    @PostMapping
    public ResponseEntity<PostResponse> createPost(
            @Valid @RequestBody CreatePostRequest request,
            @RequestParam Integer authorId) {
        
        Post post = convertFromRequest(request);
        Post savedPost = postService.createPost(post, authorId, request.getCategoryId(), request.getTags());
        PostResponse response = convertToResponse(savedPost);
        
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
    
    /**
     * 更新文章
     */
    @PutMapping("/{id}")
    public ResponseEntity<PostResponse> updatePost(
            @PathVariable Integer id,
            @Valid @RequestBody CreatePostRequest request) {
        
        Post post = convertFromRequest(request);
        // ✅ 傳遞 categoryId 和 tags 到 service 層
        Post updatedPost = postService.updatePost(id, post, request.getCategoryId(), request.getTags());
        PostResponse response = convertToResponse(updatedPost);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 發布文章
     */
    @PutMapping("/{id}/publish")
    public ResponseEntity<PostResponse> publishPost(@PathVariable Integer id) {
        Post publishedPost = postService.publishPost(id);
        PostResponse response = convertToResponse(publishedPost);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 刪除文章
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePost(@PathVariable Integer id) {
        postService.deletePost(id);
        return ResponseEntity.noContent().build();
    }
    
    /**
     * 按讚文章
     */
    @PostMapping("/{id}/like")
    public ResponseEntity<Void> likePost(@PathVariable Integer id) {
        postService.incrementLikeCount(id);
        return ResponseEntity.ok().build();
    }

    /**
     * 取消按讚文章
     */
    @DeleteMapping("/{id}/like")
    public ResponseEntity<Void> unlikePost(@PathVariable Integer id) {
        postService.decrementLikeCount(id);
        return ResponseEntity.ok().build();
    }
    
    /**
     * 根據分類獲取文章
     */
    @GetMapping("/category/{categoryId}")
    public ResponseEntity<Page<PostResponse>> getPostsByCategory(
            @PathVariable Integer categoryId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Page<Post> posts = postService.findPublishedPostsByCategory(categoryId, page, size);
        Page<PostResponse> response = posts.map(this::convertToResponse);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 根據標籤獲取文章
     */
    @GetMapping("/tag/{tagId}")
    public ResponseEntity<Page<PostResponse>> getPostsByTag(
            @PathVariable Integer tagId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Page<Post> posts = postService.findPublishedPostsByTag(tagId, page, size);
        Page<PostResponse> response = posts.map(this::convertToResponse);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 搜尋文章
     */
    @GetMapping("/search")
    public ResponseEntity<Page<PostResponse>> searchPosts(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Page<Post> posts = postService.searchPublishedPosts(keyword, page, size);
        Page<PostResponse> response = posts.map(this::convertToResponse);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 獲取精選文章
     */
    @GetMapping("/featured")
    @Transactional(readOnly = true)
    public ResponseEntity<List<PostResponse>> getFeaturedPosts(
            @RequestParam(defaultValue = "5") int limit) {
        
        List<Post> posts = postService.findFeaturedPosts(limit);
        List<PostResponse> response = posts.stream()
                .map(this::convertToResponse)
                .toList();
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 獲取最新文章
     */
    @GetMapping("/latest")
    public ResponseEntity<List<PostResponse>> getLatestPosts(
            @RequestParam(defaultValue = "5") int limit) {
        
        List<Post> posts = postService.findLatestPosts(limit);
        List<PostResponse> response = posts.stream()
                .map(this::convertToResponse)
                .toList();
        
        return ResponseEntity.ok(response);
    }
    

    
    /**
     * 獲取相關文章
     */
    @GetMapping("/{id}/related")
    public ResponseEntity<List<PostResponse>> getRelatedPosts(
            @PathVariable Integer id,
            @RequestParam(defaultValue = "5") int limit) {
        
        List<Post> posts = postService.findRelatedPosts(id, limit);
        List<PostResponse> response = posts.stream()
                .map(this::convertToResponse)
                .toList();
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 根據作者獲取文章
     */
    @GetMapping("/author/{authorId}")
    public ResponseEntity<Page<PostResponse>> getPostsByAuthor(
            @PathVariable Integer authorId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Page<Post> posts = postService.findPostsByAuthor(authorId, page, size);
        Page<PostResponse> response = posts.map(this::convertToResponse);
        
        return ResponseEntity.ok(response);
    }
    
    // 私有轉換方法
    
    /**
     * 將 Post 實體轉換為 PostResponse DTO
     */
    private PostResponse convertToResponse(Post post) {
        PostResponse response = new PostResponse();
        response.setPostId(post.getPostId());
        response.setTitle(post.getTitle());
        response.setSlug(post.getSlug());
        response.setExcerpt(post.getExcerpt());
        response.setContent(post.getContent());
        response.setFeaturedImage(post.getFeaturedImage());
        response.setStatus(post.getStatus().name());
        response.setIsCommentEnabled(post.getIsCommentEnabled());
        response.setIsFeatured(post.getIsFeatured());
        response.setViewCount(post.getViewCount());
        response.setLikeCount(post.getLikeCount());
        response.setMetaTitle(post.getMetaTitle());
        response.setMetaDescription(post.getMetaDescription());
        response.setMetaKeywords(post.getMetaKeywords());
        response.setCreatedAt(post.getCreatedAt());
        response.setUpdatedAt(post.getUpdatedAt());
        response.setPublishedAt(post.getPublishedAt());
        
        // 設定作者資訊
        if (post.getAuthor() != null) {
            try {
                com.blog.dto.response.UserResponse author = new com.blog.dto.response.UserResponse();
                author.setUserId(post.getAuthor().getUserId());
                author.setUsername(post.getAuthor().getUsername());
                author.setDisplayName(post.getAuthor().getDisplayName());
                author.setAvatar(post.getAuthor().getAvatar());
                response.setAuthor(author);
            } catch (Exception e) {
                // 如果獲取作者資訊失敗，設置默認作者資訊
                com.blog.dto.response.UserResponse author = new com.blog.dto.response.UserResponse();
                author.setUserId(0);
                author.setUsername("unknown");
                author.setDisplayName("未知作者");
                author.setAvatar("images/placeholders/avatar-default.svg");
                response.setAuthor(author);
            }
        } else {
            // 如果沒有作者資訊，設置默認作者資訊
            com.blog.dto.response.UserResponse author = new com.blog.dto.response.UserResponse();
            author.setUserId(0);
            author.setUsername("unknown");
            author.setDisplayName("未知作者");
            author.setAvatar("images/placeholders/avatar-default.svg");
            response.setAuthor(author);
        }
        
        // 設定分類資訊
        if (post.getCategory() != null) {
            com.blog.dto.response.CategoryResponse category = new com.blog.dto.response.CategoryResponse();
            category.setCategoryId(post.getCategory().getCategoryId());
            category.setName(post.getCategory().getName());
            category.setSlug(post.getCategory().getSlug());
            category.setDescription(post.getCategory().getDescription());
            response.setCategory(category);
        }
        
        // 設定標籤資訊
        try {
            if (post.getTags() != null && !post.getTags().isEmpty()) {
                List<com.blog.dto.response.TagResponse> tags = post.getTags().stream()
                    .map(tag -> {
                        com.blog.dto.response.TagResponse tagResponse = new com.blog.dto.response.TagResponse();
                        tagResponse.setTagId(tag.getTagId());
                        tagResponse.setName(tag.getName());
                        tagResponse.setSlug(tag.getSlug());
                        tagResponse.setDescription(tag.getDescription());
                        return tagResponse;
                    })
                    .toList();
                response.setTags(tags);
            }
        } catch (Exception e) {
            // 如果標籤懶加載失敗，設置空列表
            response.setTags(new java.util.ArrayList<>());
            System.err.println("警告：無法載入文章標籤: " + e.getMessage());
        }
        
        return response;
    }
    
    /**
     * 將 CreatePostRequest DTO 轉換為 Post 實體
     */
    private Post convertFromRequest(CreatePostRequest request) {
        Post post = new Post();
        post.setTitle(request.getTitle());
        post.setSlug(request.getSlug());
        post.setExcerpt(request.getExcerpt());
        post.setContent(request.getContent());
        post.setFeaturedImage(request.getFeaturedImage());
        post.setIsCommentEnabled(request.getIsCommentEnabled());
        post.setIsFeatured(request.getIsFeatured());
        post.setMetaTitle(request.getMetaTitle());
        post.setMetaDescription(request.getMetaDescription());
        post.setMetaKeywords(request.getMetaKeywords());
        
        // 設置文章狀態
        if (request.getStatus() != null) {
            try {
                post.setStatus(com.blog.entity.PostStatus.valueOf(request.getStatus()));
            } catch (IllegalArgumentException e) {
                post.setStatus(com.blog.entity.PostStatus.DRAFT); // 預設為草稿
            }
        } else {
            post.setStatus(com.blog.entity.PostStatus.DRAFT);
        }
        
        return post;
    }
} 