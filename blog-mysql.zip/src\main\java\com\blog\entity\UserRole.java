package com.blog.entity;

/**
 * 使用者角色枚舉
 */
public enum UserRole {
    ADMIN,   // 管理員
    AUTHOR,  // 作者
    USER     // 一般使用者
} 