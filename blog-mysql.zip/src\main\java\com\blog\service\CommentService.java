package com.blog.service;

import com.blog.entity.Comment;
import com.blog.entity.CommentStatus;
import com.blog.entity.Post;
import com.blog.repository.CommentRepository;
import com.blog.repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * 評論業務邏輯服務
 */
@Service
@Transactional
public class CommentService {
    
    @Autowired
    private CommentRepository commentRepository;
    
    @Autowired
    private PostRepository postRepository;
    
    /**
     * 根據ID查找評論
     */
    @Transactional(readOnly = true)
    public Optional<Comment> findById(Integer commentId) {
        return commentRepository.findById(commentId);
    }
    
    /**
     * 根據文章查找已核准的評論
     */
    @Transactional(readOnly = true)
    public List<Comment> findApprovedCommentsByPost(Integer postId) {
        return commentRepository.findApprovedCommentsByPost(postId);
    }
    
    /**
     * 根據文章查找頂層評論
     */
    @Transactional(readOnly = true)
    public List<Comment> findTopLevelCommentsByPost(Integer postId) {
        return commentRepository.findTopLevelCommentsByPost(postId);
    }
    
    /**
     * 根據父評論查找回覆
     */
    @Transactional(readOnly = true)
    public List<Comment> findRepliesByParentComment(Integer parentId) {
        return commentRepository.findRepliesByParentComment(parentId);
    }
    
    /**
     * 查找所有評論（分頁）
     */
    @Transactional(readOnly = true)
    public Page<Comment> findAllComments(Pageable pageable) {
        List<Comment> allComments = commentRepository.findAllWithPost();
        
        // 手動實現分頁
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), allComments.size());
        
        if (start > allComments.size()) {
            return Page.empty(pageable);
        }
        
        List<Comment> pageContent = allComments.subList(start, end);
        
        return new PageImpl<>(pageContent, pageable, allComments.size());
    }
    
    /**
     * 創建新評論
     */
    public Comment createComment(Comment comment, Integer postId) {
        // 驗證文章存在
        Post post = postRepository.findById(postId)
            .orElseThrow(() -> new RuntimeException("文章不存在"));
        
        // 檢查文章是否允許評論
        if (!post.getIsCommentEnabled()) {
            throw new RuntimeException("此文章不允許評論");
        }
        
        comment.setPost(post);
        
        // 設定預設狀態
        if (comment.getStatus() == null) {
            comment.setStatus(CommentStatus.APPROVED);
        }
        
        return commentRepository.save(comment);
    }
    
    /**
     * 回覆評論
     */
    public Comment replyToComment(Comment reply, Integer parentCommentId, Integer postId) {
        // 驗證父評論存在
        Comment parentComment = commentRepository.findById(parentCommentId)
            .orElseThrow(() -> new RuntimeException("父評論不存在"));
        
        // 驗證父評論與文章匹配
        if (!parentComment.getPost().getPostId().equals(postId)) {
            throw new RuntimeException("評論與文章不匹配");
        }
        
        // 驗證文章存在且允許評論
        Post post = postRepository.findById(postId)
            .orElseThrow(() -> new RuntimeException("文章不存在"));
        
        if (!post.getIsCommentEnabled()) {
            throw new RuntimeException("此文章不允許評論");
        }
        
        reply.setPost(post);
        reply.setParentComment(parentComment);
        
        // 設定預設狀態
        if (reply.getStatus() == null) {
            reply.setStatus(CommentStatus.APPROVED);
        }
        
        return commentRepository.save(reply);
    }
    
    /**
     * 更新評論
     */
    @Transactional
    public Comment updateComment(Integer commentId, Comment updatedComment) {
        // 使用自定義查詢預加載 Post，避免懶加載問題
        Comment existingComment = commentRepository.findByIdWithPost(commentId)
            .orElseThrow(() -> new RuntimeException("評論不存在"));
        
        // 更新可編輯的欄位
        existingComment.setAuthorName(updatedComment.getAuthorName());
        existingComment.setAuthorEmail(updatedComment.getAuthorEmail());
        existingComment.setAuthorWebsite(updatedComment.getAuthorWebsite());
        existingComment.setContent(updatedComment.getContent());
        
        return commentRepository.save(existingComment);
    }
    
    /**
     * 刪除評論
     */
    public void deleteComment(Integer commentId) {
        Comment comment = commentRepository.findById(commentId)
            .orElseThrow(() -> new RuntimeException("評論不存在"));
        
        // 檢查是否有回覆
        List<Comment> replies = commentRepository.findRepliesByParentComment(commentId);
        if (!replies.isEmpty()) {
            throw new RuntimeException("此評論有 " + replies.size() + " 個回覆，無法刪除");
        }
        
        commentRepository.delete(comment);
    }
    

    
    /**
     * 標記為垃圾評論
     */
    public Comment markAsSpam(Integer commentId) {
        Comment comment = commentRepository.findById(commentId)
            .orElseThrow(() -> new RuntimeException("評論不存在"));
        
        comment.setStatus(CommentStatus.SPAM);
        return commentRepository.save(comment);
    }
    
    /**
     * 批量核准評論
     */
    public void batchApproveComments(List<Integer> commentIds) {
        for (Integer commentId : commentIds) {
            approveComment(commentId);
        }
    }
    
    /**
     * 批量刪除評論
     */
    public void batchDeleteComments(List<Integer> commentIds) {
        for (Integer commentId : commentIds) {
            commentRepository.deleteById(commentId);
        }
    }
    
    /**
     * 根據狀態查找評論
     */
    @Transactional(readOnly = true)
    public Page<Comment> findCommentsByStatus(String status, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return commentRepository.findByStatus(status, pageable);
    }
    
    /**
     * 查找待審核的評論
     */
    @Transactional(readOnly = true)
    public List<Comment> findPendingComments(int limit) {
        Pageable pageable = PageRequest.of(0, limit);
        return commentRepository.findPendingComments(pageable);
    }
    
    /**
     * 搜尋評論
     */
    @Transactional(readOnly = true)
    public Page<Comment> searchComments(String keyword, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return commentRepository.searchComments(keyword, pageable);
    }
    
    /**
     * 根據作者郵箱查找評論
     */
    @Transactional(readOnly = true)
    public Page<Comment> findCommentsByAuthorEmail(String authorEmail, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return commentRepository.findByAuthorEmail(authorEmail, pageable);
    }
    
    /**
     * 根據IP地址查找評論
     */
    @Transactional(readOnly = true)
    public Page<Comment> findCommentsByIp(String authorIp, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return commentRepository.findByAuthorIp(authorIp, pageable);
    }
    
    /**
     * 統計文章的評論數量
     */
    @Transactional(readOnly = true)
    public Long countApprovedCommentsByPost(Integer postId) {
        return commentRepository.countApprovedCommentsByPost(postId);
    }
    
    /**
     * 查找最新評論
     */
    @Transactional(readOnly = true)
    public List<Comment> findLatestComments(int limit) {
        Pageable pageable = PageRequest.of(0, limit);
        return commentRepository.findLatestCommentsWithPost(pageable);
    }
    
    /**
     * 統計各狀態的評論數量
     */
    @Transactional(readOnly = true)
    public List<Object[]> countCommentsByStatus() {
        return commentRepository.countCommentsByStatus();
    }
    
    /**
     * 查找指定時間範圍內的評論
     */
    @Transactional(readOnly = true)
    public List<Comment> findCommentsByDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        return commentRepository.findCommentsByDateRange(startDate, endDate);
    }
    
    /**
     * 查找需要通知的評論
     */
    @Transactional(readOnly = true)
    public List<Comment> findCommentsToNotify() {
        return commentRepository.findCommentsToNotify();
    }
    
    /**
     * 標記評論為已通知
     */
    public void markCommentAsNotified(Integer commentId) {
        Comment comment = commentRepository.findById(commentId)
            .orElseThrow(() -> new RuntimeException("評論不存在"));
        
        comment.setIsNotified(true);
        commentRepository.save(comment);
    }
    
    /**
     * 審核評論
     */
    public void approveComment(Integer commentId) {
        Comment comment = commentRepository.findById(commentId)
            .orElseThrow(() -> new RuntimeException("評論不存在"));
        
        comment.setStatus(CommentStatus.APPROVED);
        comment.setUpdatedAt(LocalDateTime.now());
        commentRepository.save(comment);
    }
    
    /**
     * 拒絕評論
     */
    public void rejectComment(Integer commentId) {
        Comment comment = commentRepository.findById(commentId)
            .orElseThrow(() -> new RuntimeException("評論不存在"));
        
        comment.setStatus(CommentStatus.REJECTED);
        comment.setUpdatedAt(LocalDateTime.now());
        commentRepository.save(comment);
    }
    
    /**
     * 按讚評論
     */
    @Transactional
    public Comment likeComment(Integer commentId) {
        Comment comment = commentRepository.findById(commentId)
            .orElseThrow(() -> new RuntimeException("Comment not found with id: " + commentId));
        
        Integer currentLikes = comment.getLikeCount();
        if (currentLikes == null) {
            currentLikes = 0;
        }
        comment.setLikeCount(currentLikes + 1);
        
        return commentRepository.save(comment);
    }
    
    /**
     * 取消按讚評論
     */
    @Transactional
    public Comment unlikeComment(Integer commentId) {
        Comment comment = commentRepository.findById(commentId)
            .orElseThrow(() -> new RuntimeException("Comment not found with id: " + commentId));
        
        Integer currentLikes = comment.getLikeCount();
        if (currentLikes == null) {
            currentLikes = 0;
        }
        if (currentLikes > 0) {
            comment.setLikeCount(currentLikes - 1);
        }
        
        return commentRepository.save(comment);
    }
}
