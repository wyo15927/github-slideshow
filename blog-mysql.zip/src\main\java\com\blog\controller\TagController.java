package com.blog.controller;

import com.blog.dto.response.TagResponse;
import com.blog.entity.Tag;
import com.blog.service.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 標籤 REST API 控制器
 */
@RestController
@RequestMapping("/api/tags")
@CrossOrigin(origins = "*")
public class TagController {

    @Autowired
    private TagService tagService;

    /**
     * 獲取所有標籤
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> getAllTags(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "name") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {

        try {
            Sort sort = sortDir.equalsIgnoreCase("desc") ? 
                Sort.by(sortBy).descending() : 
                Sort.by(sortBy).ascending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Tag> tagPage = tagService.findAll(pageable);

            List<TagResponse> tagResponses = tagPage.getContent().stream()
                .map(this::convertToTagResponse)
                .collect(Collectors.toList());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", tagResponses);
            response.put("page", page);
            response.put("size", size);
            response.put("totalElements", tagPage.getTotalElements());
            response.put("totalPages", tagPage.getTotalPages());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 根據 ID 獲取標籤
     */
    @GetMapping("/{tagId}")
    public ResponseEntity<TagResponse> getTagById(@PathVariable Integer tagId) {
        Optional<Tag> tag = tagService.findById(tagId);
        if (tag.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        TagResponse response = convertToTagResponse(tag.get());
        return ResponseEntity.ok(response);
    }

    /**
     * 根據 slug 獲取標籤
     */
    @GetMapping("/slug/{slug}")
    public ResponseEntity<TagResponse> getTagBySlug(@PathVariable String slug) {
        Optional<Tag> tag = tagService.findBySlug(slug);
        if (tag.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        TagResponse response = convertToTagResponse(tag.get());
        return ResponseEntity.ok(response);
    }

    /**
     * 獲取熱門標籤
     */
    @GetMapping("/popular")
    public ResponseEntity<Map<String, Object>> getPopularTags(
            @RequestParam(defaultValue = "10") int limit) {

        try {
            List<Tag> tags = tagService.findPopularTags(limit);
            List<TagResponse> tagResponses = tags.stream()
                .map(this::convertToTagResponse)
                .collect(Collectors.toList());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", tagResponses);
            response.put("total", tagResponses.size());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 獲取最新標籤
     */
    @GetMapping("/latest")
    public ResponseEntity<Map<String, Object>> getLatestTags(
            @RequestParam(defaultValue = "10") int limit) {

        try {
            List<Tag> tags = tagService.findLatestTags(limit);
            List<TagResponse> tagResponses = tags.stream()
                .map(this::convertToTagResponse)
                .collect(Collectors.toList());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", tagResponses);
            response.put("total", tagResponses.size());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 搜索標籤
     */
    @GetMapping("/search")
    public ResponseEntity<Map<String, Object>> searchTags(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "name") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {

        try {
            Sort sort = sortDir.equalsIgnoreCase("desc") ? 
                Sort.by(sortBy).descending() : 
                Sort.by(sortBy).ascending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Tag> tagPage = tagService.searchTags(keyword, pageable);

            List<TagResponse> tagResponses = tagPage.getContent().stream()
                .map(this::convertToTagResponse)
                .collect(Collectors.toList());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", tagResponses);
            response.put("page", page);
            response.put("size", size);
            response.put("totalElements", tagPage.getTotalElements());
            response.put("totalPages", tagPage.getTotalPages());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 根據文章 ID 獲取相關標籤
     */
    @GetMapping("/by-post/{postId}")
    public ResponseEntity<Map<String, Object>> getTagsByPost(@PathVariable Integer postId) {
        try {
            List<Tag> tags = tagService.findTagsByPost(postId);
            List<TagResponse> tagResponses = tags.stream()
                .map(this::convertToTagResponse)
                .collect(Collectors.toList());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", tagResponses);
            response.put("total", tagResponses.size());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 獲取標籤雲數據
     */
    @GetMapping("/cloud")
    public ResponseEntity<Map<String, Object>> getTagCloud(
            @RequestParam(defaultValue = "50") int limit) {

        try {
            List<Tag> tags = tagService.findPopularTags(limit);
            
            // 創建標籤雲數據結構
            List<Map<String, Object>> tagCloudData = tags.stream()
                .map(tag -> {
                    Map<String, Object> tagData = new HashMap<>();
                    tagData.put("name", tag.getName());
                    tagData.put("slug", tag.getSlug());
                    tagData.put("count", tag.getUsageCount());
                    tagData.put("color", tag.getColor());
                    return tagData;
                })
                .collect(Collectors.toList());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", tagCloudData);
            response.put("total", tagCloudData.size());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 獲取標籤統計資訊
     */
    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getTagStats() {
        try {
            long totalTags = tagService.countAll();
            long usedTags = tagService.countUsedTags();

            Map<String, Object> stats = new HashMap<>();
            stats.put("totalTags", totalTags);
            stats.put("usedTags", usedTags);
            stats.put("unusedTags", totalTags - usedTags);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", stats);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 創建新標籤
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> createTag(@RequestBody Tag tag) {
        try {
            Tag savedTag = tagService.save(tag);
            TagResponse response = convertToTagResponse(savedTag);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("data", response);
            result.put("message", "標籤創建成功");
            
            return ResponseEntity.ok(result);
            
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 更新標籤
     */
    @PutMapping("/{tagId}")
    public ResponseEntity<Map<String, Object>> updateTag(
            @PathVariable Integer tagId, 
            @RequestBody Tag tag) {
        try {
            Optional<Tag> existingTag = tagService.findById(tagId);
            if (existingTag.isEmpty()) {
                return ResponseEntity.notFound().build();
            }
            
            // 更新標籤資訊
            Tag tagToUpdate = existingTag.get();
            tagToUpdate.setName(tag.getName());
            tagToUpdate.setSlug(tag.getSlug());
            tagToUpdate.setDescription(tag.getDescription());
            tagToUpdate.setColor(tag.getColor());
            if (tag.getUsageCount() != null) {
                tagToUpdate.setUsageCount(tag.getUsageCount());
            }
            
            Tag updatedTag = tagService.save(tagToUpdate);
            TagResponse response = convertToTagResponse(updatedTag);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("data", response);
            result.put("message", "標籤更新成功");
            
            return ResponseEntity.ok(result);
            
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 刪除標籤
     */
    @DeleteMapping("/{tagId}")
    public ResponseEntity<Map<String, Object>> deleteTag(@PathVariable Integer tagId) {
        try {
            Optional<Tag> tag = tagService.findById(tagId);
            if (tag.isEmpty()) {
                return ResponseEntity.notFound().build();
            }
            
            tagService.deleteById(tagId);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("message", "標籤刪除成功");
            
            return ResponseEntity.ok(result);
            
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    // 私有輔助方法

    private TagResponse convertToTagResponse(Tag tag) {
        TagResponse response = new TagResponse();
        response.setTagId(tag.getTagId());
        response.setName(tag.getName());
        response.setSlug(tag.getSlug());
        response.setDescription(tag.getDescription());
        response.setColor(tag.getColor());
        response.setUsageCount(tag.getUsageCount());
        response.setCreatedAt(tag.getCreatedAt());
        return response;
    }

    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        return response;
    }
} 