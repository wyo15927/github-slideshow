package com.blog.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.util.List;

/**
 * 創建文章請求 DTO
 */
public class CreatePostRequest {
    
    @NotBlank(message = "文章標題不能為空")
    @Size(max = 200, message = "標題長度不能超過200字符")
    private String title;
    
    @Size(max = 200, message = "路徑長度不能超過200字符")
    private String slug;
    
    @Size(max = 500, message = "摘要長度不能超過500字符")
    private String excerpt;
    
    @NotBlank(message = "文章內容不能為空")
    private String content;
    
    private String featuredImage;
    
    private Integer categoryId;
    
    private List<String> tags;
    
    private String status = "DRAFT";
    
    private Boolean isCommentEnabled = true;
    
    private Boolean isFeatured = false;
    
    @Size(max = 200, message = "SEO標題長度不能超過200字符")
    private String metaTitle;
    
    @Size(max = 300, message = "SEO描述長度不能超過300字符")
    private String metaDescription;
    
    @Size(max = 500, message = "SEO關鍵字長度不能超過500字符")
    private String metaKeywords;
    
    public CreatePostRequest() {}
    
    // Getters and Setters
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getSlug() {
        return slug;
    }
    
    public void setSlug(String slug) {
        this.slug = slug;
    }
    
    public String getExcerpt() {
        return excerpt;
    }
    
    public void setExcerpt(String excerpt) {
        this.excerpt = excerpt;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public String getFeaturedImage() {
        return featuredImage;
    }
    
    public void setFeaturedImage(String featuredImage) {
        this.featuredImage = featuredImage;
    }
    
    public Integer getCategoryId() {
        return categoryId;
    }
    
    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }
    
    public List<String> getTags() {
        return tags;
    }
    
    public void setTags(List<String> tags) {
        this.tags = tags;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Boolean getIsCommentEnabled() {
        return isCommentEnabled;
    }
    
    public void setIsCommentEnabled(Boolean isCommentEnabled) {
        this.isCommentEnabled = isCommentEnabled;
    }
    
    public Boolean getIsFeatured() {
        return isFeatured;
    }
    
    public void setIsFeatured(Boolean isFeatured) {
        this.isFeatured = isFeatured;
    }
    
    public String getMetaTitle() {
        return metaTitle;
    }
    
    public void setMetaTitle(String metaTitle) {
        this.metaTitle = metaTitle;
    }
    
    public String getMetaDescription() {
        return metaDescription;
    }
    
    public void setMetaDescription(String metaDescription) {
        this.metaDescription = metaDescription;
    }
    
    public String getMetaKeywords() {
        return metaKeywords;
    }
    
    public void setMetaKeywords(String metaKeywords) {
        this.metaKeywords = metaKeywords;
    }
} 