package com.blog.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 使用者實體類別
 * 對應資料庫 Users 表格
 */
@Entity
@Table(name = "Users")
@EntityListeners(AuditingEntityListener.class)
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "UserId")
    private Integer userId;
    
    @NotBlank(message = "使用者名稱不能為空")
    @Size(max = 50, message = "使用者名稱不能超過50個字元")
    @Column(name = "Username", unique = true, nullable = false, length = 50)
    private String username;
    
    @NotBlank(message = "電子郵件不能為空")
    @Email(message = "電子郵件格式不正確")
    @Size(max = 100, message = "電子郵件不能超過100個字元")
    @Column(name = "Email", unique = true, nullable = false, length = 100)
    private String email;
    
    @NotBlank(message = "密碼不能為空")
    @Column(name = "PasswordHash", nullable = false)
    private String passwordHash;
    
    @Size(max = 100, message = "顯示名稱不能超過100個字元")
    @Column(name = "DisplayName", length = 100)
    private String displayName;
    
    @Size(max = 500, message = "頭像路徑不能超過500個字元")
    @Column(name = "Avatar", length = 500)
    private String avatar;
    
    @Size(max = 100, message = "職業不能超過100個字元")
    @Column(name = "Profession", length = 100)
    private String profession;
    
    @Size(max = 1000, message = "個人簡介不能超過1000個字元")
    @Column(name = "Bio", length = 1000)
    private String bio;
    
    @Size(max = 100, message = "所在地不能超過100個字元")
    @Column(name = "Location", length = 100)
    private String location;
    
    @Size(max = 200, message = "個人網站不能超過200個字元")
    @Column(name = "Website", length = 200)
    private String website;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "Role", length = 20)
    private UserRole role = UserRole.USER;
    
    @Column(name = "IsActive")
    private Boolean isActive = true;
    
    @CreatedDate
    @Column(name = "CreatedAt", updatable = false)
    private LocalDateTime createdAt;
    
    @LastModifiedDate
    @Column(name = "UpdatedAt")
    private LocalDateTime updatedAt;
    
    @Column(name = "LastLoginAt")
    private LocalDateTime lastLoginAt;
    
    // 關聯關係
    @OneToMany(mappedBy = "author", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Post> posts;
    
    @OneToMany(mappedBy = "uploadedBy", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Media> mediaFiles;
    
    // 預設建構子
    public User() {}
    
    // 建構子
    public User(String username, String email, String passwordHash) {
        this.username = username;
        this.email = email;
        this.passwordHash = passwordHash;
    }
    
    // Getters and Setters
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    
    public String getAvatar() { return avatar; }
    public void setAvatar(String avatar) { this.avatar = avatar; }
    
    public String getProfession() { return profession; }
    public void setProfession(String profession) { this.profession = profession; }
    
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
    
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    
    public String getWebsite() { return website; }
    public void setWebsite(String website) { this.website = website; }
    
    public UserRole getRole() { return role; }
    public void setRole(UserRole role) { this.role = role; }
    
    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    
    public LocalDateTime getLastLoginAt() { return lastLoginAt; }
    public void setLastLoginAt(LocalDateTime lastLoginAt) { this.lastLoginAt = lastLoginAt; }
    
    public List<Post> getPosts() { return posts; }
    public void setPosts(List<Post> posts) { this.posts = posts; }
    
    public List<Media> getMediaFiles() { return mediaFiles; }
    public void setMediaFiles(List<Media> mediaFiles) { this.mediaFiles = mediaFiles; }
}

 