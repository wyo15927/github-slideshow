package com.blog.entity;

/**
 * 文章狀態枚舉
 */
public enum PostStatus {
    DRAFT,      // 草稿
    PUBLISHED,  // 已發布
    ARCHIVED    // 已封存
} 