/**
 * 認證管理器
 * 處理用戶登入、登出和認證狀態管理
 */

class AuthManager {
    constructor() {
        this.tokenKey = 'authToken';
        this.userKey = 'user';
        this.isInitialized = false;
        console.log('AuthManager 構造函數被調用');
    }

    /**
     * 初始化認證管理器
     */
    init() {
        if (this.isInitialized) return;
        
        console.log('AuthManager.init() 被調用');
        console.log('this 綁定檢查:', {
            hasIsLoggedIn: typeof this.isLoggedIn === 'function',
            hasGetToken: typeof this.getToken === 'function',
            methods: Object.getOwnPropertyNames(this)
        });
        
        // 檢查是否有有效的認證狀態
        this.checkAuthState();
        this.isInitialized = true;
        
        console.log('認證管理器初始化完成');
    }

    /**
     * 檢查認證狀態
     */
    checkAuthState() {
        const token = this.getToken();
        if (token) {
            // 驗證 token 是否有效
            if (this.isTokenValid(token)) {
                this.updateAuthState(true);
            } else {
                this.logout();
            }
        } else {
            this.updateAuthState(false);
        }
    }

    /**
     * 獲取認證 token
     */
    getToken() {
        return localStorage.getItem(this.tokenKey) || sessionStorage.getItem(this.tokenKey);
    }

    /**
     * 設置認證 token
     */
    setToken(token, rememberMe = false) {
        if (rememberMe) {
            localStorage.setItem(this.tokenKey, token);
        } else {
            sessionStorage.setItem(this.tokenKey, token);
        }
        this.updateAuthState(true);
    }

    /**
     * 移除認證 token
     */
    removeToken() {
        localStorage.removeItem(this.tokenKey);
        sessionStorage.removeItem(this.tokenKey);
        this.updateAuthState(false);
    }

    /**
     * 檢查是否已登入
     */
    isLoggedIn() {
        const token = this.getToken();
        return token && this.isTokenValid(token);
    }

    /**
     * 檢查 token 是否有效
     */
    isTokenValid(token) {
        if (!token) return false;
        
        try {
            // 簡單的 token 格式檢查
            if (token.includes(':')) {
                const parts = token.split(':');
                if (parts.length >= 2) {
                    const timestamp = parseInt(parts[1]);
                    const now = Date.now();
                    // 檢查 token 是否在 24 小時內有效
                    return (now - timestamp) < (24 * 60 * 60 * 1000);
                }
            }
            return false;
        } catch (error) {
            console.error('Token 驗證失敗:', error);
            return false;
        }
    }

    /**
     * 獲取認證頭
     */
    getAuthHeaders() {
        const token = this.getToken();
        return token ? { 'Authorization': `Bearer ${token}` } : {};
    }

    /**
     * 獲取當前用戶資訊
     */
    getCurrentUser() {
        try {
            const userData = localStorage.getItem(this.userKey) || sessionStorage.getItem(this.userKey);
            return userData ? JSON.parse(userData) : null;
        } catch (error) {
            console.error('獲取用戶資訊失敗:', error);
            return null;
        }
    }

    /**
     * 設置用戶資訊
     */
    setCurrentUser(user, rememberMe = false) {
        const userData = JSON.stringify(user);
        if (rememberMe) {
            localStorage.setItem(this.userKey, userData);
        } else {
            sessionStorage.setItem(this.userKey, userData);
        }
    }

    /**
     * 清除用戶資訊
     */
    clearCurrentUser() {
        localStorage.removeItem(this.userKey);
        sessionStorage.removeItem(this.userKey);
    }

    /**
     * 登入
     */
    async login(credentials) {
        try {
            // 這裡應該調用後端 API
            // 暫時使用模擬登入
            const response = await fetch('http://localhost:8080/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(credentials)
            });

            if (response.ok) {
                const result = await response.json();
                if (result.success) {
                    this.setToken(result.token || `${credentials.username}:${Date.now()}`);
                    if (result.user) {
                        this.setCurrentUser(result.user);
                    }
                    return { success: true, user: result.user };
                }
            }
            
            return { success: false, message: '登入失敗' };
        } catch (error) {
            console.error('登入錯誤:', error);
            return { success: false, message: '網路錯誤' };
        }
    }

    /**
     * 登出
     */
    logout() {
        this.removeToken();
        this.clearCurrentUser();
        this.updateAuthState(false);
        
        // 觸發登出事件
        window.dispatchEvent(new CustomEvent('authStateChanged', {
            detail: { isLoggedIn: false }
        }));
    }

    /**
     * 更新認證狀態
     */
    updateAuthState(isLoggedIn) {
        // 觸發認證狀態變化事件
        window.dispatchEvent(new CustomEvent('authStateChanged', {
            detail: { isLoggedIn: isLoggedIn }
        }));
    }

    /**
     * 檢查用戶權限
     */
    hasRole(role) {
        const user = this.getCurrentUser();
        return user && user.role === role;
    }

    /**
     * 檢查是否為管理員
     */
    isAdmin() {
        return this.hasRole('ADMIN');
    }

    /**
     * 檢查是否為作者
     */
    isAuthor() {
        return this.hasRole('AUTHOR') || this.isAdmin();
    }
}

// 創建全局實例
window.AuthManager = new AuthManager();

// 調試：檢查實例的方法
console.log('AuthManager 實例檢查:', {
    exists: !!window.AuthManager,
    constructor: window.AuthManager.constructor.name,
    methods: Object.getOwnPropertyNames(window.AuthManager),
    prototype: Object.getOwnPropertyNames(Object.getPrototypeOf(window.AuthManager)),
    hasInit: typeof window.AuthManager.init === 'function',
    hasIsLoggedIn: typeof window.AuthManager.isLoggedIn === 'function'
});

// 立即初始化（不等待 DOMContentLoaded）
if (window.AuthManager && typeof window.AuthManager.init === 'function') {
    window.AuthManager.init();
    console.log('AuthManager 立即初始化完成');
} else {
    console.error('AuthManager 初始化失敗');
}

// 頁面載入完成後再次檢查（確保所有元素都已載入）
document.addEventListener('DOMContentLoaded', () => {
    if (window.AuthManager && typeof window.AuthManager.init === 'function' && !window.AuthManager.isInitialized) {
        window.AuthManager.init();
        console.log('AuthManager DOMContentLoaded 初始化完成');
    }
});
