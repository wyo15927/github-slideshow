package com.blog.service;

import com.blog.entity.Media;
import com.blog.entity.User;
import com.blog.repository.MediaRepository;
import com.blog.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * 媒體檔案業務邏輯服務
 */
@Service
@Transactional
public class MediaService {
    
    @Autowired
    private MediaRepository mediaRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Value("${app.upload.path:./uploads}")
    private String uploadPath;
    
    @Value("${app.upload.url:http://localhost:8080/api/files}")
    private String uploadUrl;
    
    /**
     * 根據ID查找媒體檔案
     */
    @Transactional(readOnly = true)
    public Optional<Media> findById(Integer mediaId) {
        return mediaRepository.findById(mediaId);
    }
    
    /**
     * 根據檔案名稱查找媒體檔案
     */
    @Transactional(readOnly = true)
    public Optional<Media> findByFileName(String fileName) {
        return mediaRepository.findByFileName(fileName);
    }
    
    /**
     * 上傳檔案
     */
    public Media uploadFile(MultipartFile file, Integer uploadedBy, String altText, String caption) {
        if (file.isEmpty()) {
            throw new RuntimeException("檔案不能為空");
        }
        
        // 驗證上傳者
        User uploader = userRepository.findById(uploadedBy)
            .orElseThrow(() -> new RuntimeException("使用者不存在"));
        
        try {
            // 創建上傳目錄
            Path uploadDir = Paths.get(uploadPath);
            if (!Files.exists(uploadDir)) {
                Files.createDirectories(uploadDir);
            }
            
            // 生成唯一檔案名稱
            String originalFileName = StringUtils.cleanPath(file.getOriginalFilename());
            String fileExtension = getFileExtension(originalFileName);
            String fileName = generateUniqueFileName(fileExtension);
            
            // 複製檔案到目標位置
            Path targetPath = uploadDir.resolve(fileName);
            Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);
            
            // 創建媒體檔案記錄
            Media media = new Media();
            media.setOriginalName(originalFileName);
            media.setFileName(fileName);
            media.setFilePath(targetPath.toString());
            media.setFileType(file.getContentType());
            media.setFileSize(file.getSize());
            media.setAltText(altText);
            media.setCaption(caption);
            media.setUploadedBy(uploader);
            
            // 如果是圖片，嘗試獲取尺寸
            if (isImageFile(file.getContentType())) {
                // 這裡可以添加圖片尺寸獲取邏輯
                // 暫時設為 null，後續可以使用 ImageIO 獲取實際尺寸
            }
            
            return mediaRepository.save(media);
            
        } catch (IOException e) {
            throw new RuntimeException("檔案上傳失敗: " + e.getMessage());
        }
    }
    
    /**
     * 批量上傳檔案
     */
    public List<Media> uploadFiles(List<MultipartFile> files, Integer uploadedBy) {
        return files.stream()
            .map(file -> uploadFile(file, uploadedBy, null, null))
            .toList();
    }
    
    /**
     * 更新媒體檔案資訊
     */
    public Media updateMedia(Integer mediaId, String altText, String caption) {
        Media media = mediaRepository.findById(mediaId)
            .orElseThrow(() -> new RuntimeException("媒體檔案不存在"));
        
        media.setAltText(altText);
        media.setCaption(caption);
        
        return mediaRepository.save(media);
    }
    
    /**
     * 刪除媒體檔案
     */
    public void deleteMedia(Integer mediaId) {
        Media media = mediaRepository.findById(mediaId)
            .orElseThrow(() -> new RuntimeException("媒體檔案不存在"));
        
        try {
            // 刪除實際檔案
            Path filePath = Paths.get(media.getFilePath());
            if (Files.exists(filePath)) {
                Files.delete(filePath);
            }
            
            // 刪除資料庫記錄
            mediaRepository.delete(media);
            
        } catch (IOException e) {
            throw new RuntimeException("檔案刪除失敗: " + e.getMessage());
        }
    }
    
    /**
     * 根據檔案類型查找媒體檔案
     */
    @Transactional(readOnly = true)
    public Page<Media> findByFileType(String fileType, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return mediaRepository.findByFileType(fileType, pageable);
    }
    
    /**
     * 查找圖片檔案
     */
    @Transactional(readOnly = true)
    public Page<Media> findImageFiles(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return mediaRepository.findImageFiles(pageable);
    }
    
    /**
     * 根據上傳者查找媒體檔案
     */
    @Transactional(readOnly = true)
    public Page<Media> findByUploadedBy(Integer userId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return mediaRepository.findByUploadedByUserId(userId, pageable);
    }
    
    /**
     * 搜尋媒體檔案
     */
    @Transactional(readOnly = true)
    public Page<Media> searchMediaFiles(String keyword, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return mediaRepository.searchMediaFiles(keyword, pageable);
    }
    
    /**
     * 查找最新媒體檔案
     */
    @Transactional(readOnly = true)
    public List<Media> findLatestMedia(int limit) {
        Pageable pageable = PageRequest.of(0, limit);
        return mediaRepository.findLatestMedia(pageable);
    }
    
    /**
     * 查找大檔案
     */
    @Transactional(readOnly = true)
    public List<Media> findLargeFiles(Long sizeLimit, int limit) {
        Pageable pageable = PageRequest.of(0, limit);
        return mediaRepository.findLargeFiles(sizeLimit, pageable);
    }
    
    /**
     * 查找未使用的媒體檔案
     */
    @Transactional(readOnly = true)
    public List<Media> findUnusedMediaFiles() {
        return mediaRepository.findUnusedMediaFiles();
    }
    
    /**
     * 統計檔案類型
     */
    @Transactional(readOnly = true)
    public List<Object[]> countMediaByFileType() {
        return mediaRepository.countMediaByFileType();
    }
    
    /**
     * 計算總檔案大小
     */
    @Transactional(readOnly = true)
    public Long calculateTotalFileSize() {
        return mediaRepository.calculateTotalFileSize();
    }
    
    /**
     * 根據使用者計算檔案大小
     */
    @Transactional(readOnly = true)
    public Long calculateFileSizeByUser(Integer userId) {
        return mediaRepository.calculateFileSizeByUser(userId);
    }
    
    /**
     * 清理未使用的檔案
     */
    public int cleanupUnusedFiles() {
        List<Media> unusedFiles = findUnusedMediaFiles();
        int cleanedCount = 0;
        
        for (Media media : unusedFiles) {
            try {
                deleteMedia(media.getMediaId());
                cleanedCount++;
            } catch (Exception e) {
                // 記錄錯誤但繼續清理其他檔案
                System.err.println("清理檔案失敗: " + media.getFileName() + " - " + e.getMessage());
            }
        }
        
        return cleanedCount;
    }
    
    /**
     * 獲取檔案訪問 URL
     */
    @Transactional(readOnly = true)
    public String getFileUrl(String fileName) {
        return uploadUrl + "/" + fileName;
    }
    
    /**
     * 根據檔案大小範圍查找
     */
    @Transactional(readOnly = true)
    public Page<Media> findByFileSizeRange(Long minSize, Long maxSize, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return mediaRepository.findByFileSizeRange(minSize, maxSize, pageable);
    }
    
    /**
     * 根據日期範圍查找
     */
    @Transactional(readOnly = true)
    public List<Media> findByDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        return mediaRepository.findMediaByDateRange(startDate, endDate);
    }
    
    // 私有輔助方法
    
    /**
     * 生成唯一檔案名稱
     */
    private String generateUniqueFileName(String fileExtension) {
        String fileName = UUID.randomUUID().toString();
        if (fileExtension != null && !fileExtension.isEmpty()) {
            fileName += "." + fileExtension;
        }
        
        // 確保檔案名稱唯一
        while (mediaRepository.existsByFileName(fileName)) {
            fileName = UUID.randomUUID().toString();
            if (fileExtension != null && !fileExtension.isEmpty()) {
                fileName += "." + fileExtension;
            }
        }
        
        return fileName;
    }
    
    /**
     * 獲取檔案副檔名
     */
    private String getFileExtension(String fileName) {
        if (fileName == null || !fileName.contains(".")) {
            return "";
        }
        return fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
    }
    
    /**
     * 檢查是否為圖片檔案
     */
    private boolean isImageFile(String contentType) {
        return contentType != null && contentType.startsWith("image/");
    }
    
    /**
     * 驗證檔案類型
     */
    public boolean isValidFileType(String fileName, String contentType) {
        String extension = getFileExtension(fileName);
        
        // 允許的檔案類型
        List<String> allowedExtensions = List.of(
            "jpg", "jpeg", "png", "gif", "bmp", "webp", // 圖片
            "pdf", "doc", "docx", "txt", "rtf", // 文檔
            "zip", "rar", "7z" // 壓縮檔
        );
        
        return allowedExtensions.contains(extension.toLowerCase());
    }
    
    /**
     * 驗證檔案大小
     */
    public boolean isValidFileSize(long fileSize, long maxSize) {
        return fileSize > 0 && fileSize <= maxSize;
    }
} 