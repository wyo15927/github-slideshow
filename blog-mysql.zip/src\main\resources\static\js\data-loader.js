/**
 * 數據載入器類
 * 負責載入各種數據
 */

const DataLoader = {
    // 載入文章列表
    async loadPosts(page = 1, reset = false, filters = {}) {
        try {
            console.log('DataLoader.loadPosts 開始，參數:', { page, reset, filters });
            
            // 嘗試從 API 獲取文章
            const params = { page: page - 1, size: 6 };
            
            // 添加篩選條件
            if (filters.author) {
                params.author = filters.author;
            }
            
            console.log('嘗試從 API 獲取文章，參數:', params);
            const response = await BlogAPI.posts.getList(params);
            const posts = response.content || response || [];
            console.log('API 返回的文章:', posts);
            return posts;
            
        } catch (error) {
            console.error('載入文章失敗，使用 mock 數據:', error);
            
            // 當後端不可用時，返回示例數據
            const mockPosts = [
                // Alice 的文章
                {
                    slug: 'alice-frontend-tips',
                    title: 'Alice的第一篇文章：前端開發心得',
                    excerpt: '分享我在前端開發中學到的一些實用技巧和最佳實踐',
                    content: '前端開發的精彩內容...',
                    featuredImage: 'images/placeholders/post-default.svg',
                    author: { displayName: 'Alice Wang', username: 'alice' },
                    publishedAt: '2025-08-16T10:00:00',
                    viewCount: 45,
                    commentCount: 8,
                    category: { name: '前端開發' },
                    tags: [{ name: 'JavaScript' }, { name: 'React' }]
                },
                {
                    slug: 'alice-react-hooks',
                    title: 'React Hooks 深度解析',
                    excerpt: '深入探討 React Hooks 的使用技巧和最佳實踐',
                    content: 'React Hooks 的詳細內容...',
                    featuredImage: 'images/placeholders/post-default.svg',
                    author: { displayName: 'Alice Wang', username: 'alice' },
                    publishedAt: '2025-08-15T14:30:00',
                    viewCount: 38,
                    commentCount: 6,
                    category: { name: '前端開發' },
                    tags: [{ name: 'React' }, { name: 'Hooks' }]
                },
                {
                    slug: 'alice-css-grid',
                    title: 'CSS Grid 佈局完全指南',
                    excerpt: '從基礎到進階的 CSS Grid 佈局教學',
                    content: 'CSS Grid 的完整指南...',
                    featuredImage: 'images/placeholders/post-default.svg',
                    author: { displayName: 'Alice Wang', username: 'alice' },
                    publishedAt: '2025-08-14T09:15:00',
                    viewCount: 29,
                    commentCount: 4,
                    category: { name: '前端開發' },
                    tags: [{ name: 'CSS' }, { name: 'Grid' }]
                },
                // Bob 的文章
                {
                    slug: 'bob-developer-journey',
                    title: 'Bob的程式人生：從新手到資深開發者',
                    excerpt: '回顧我從程式新手成長為資深開發者的心路歷程',
                    content: '程式開發的成長故事...',
                    featuredImage: 'images/placeholders/post-default.svg',
                    author: { displayName: 'Bob Chen', username: 'bob' },
                    publishedAt: '2025-08-16T11:00:00',
                    viewCount: 32,
                    commentCount: 5,
                    category: { name: '職業發展' },
                    tags: [{ name: 'Career' }, { name: 'Programming' }]
                },
                {
                    slug: 'bob-java-spring',
                    title: 'Spring Boot 微服務架構實戰',
                    excerpt: '使用 Spring Boot 構建可擴展的微服務架構',
                    content: 'Spring Boot 微服務的實戰內容...',
                    featuredImage: 'images/placeholders/post-default.svg',
                    author: { displayName: 'Bob Chen', username: 'bob' },
                    publishedAt: '2025-08-15T16:00:00',
                    viewCount: 41,
                    commentCount: 7,
                    category: { name: '後端開發' },
                    tags: [{ name: 'Java' }, { name: 'Spring Boot' }]
                },
                {
                    slug: 'bob-database-design',
                    title: '資料庫設計最佳實踐',
                    excerpt: '分享我在資料庫設計方面的經驗和技巧',
                    content: '資料庫設計的詳細內容...',
                    featuredImage: 'images/placeholders/post-default.svg',
                    author: { displayName: 'Bob Chen', username: 'bob' },
                    publishedAt: '2025-08-14T13:00:00',
                    viewCount: 35,
                    commentCount: 3,
                    category: { name: '資料庫' },
                    tags: [{ name: 'SQL' }, { name: 'Database' }]
                }
            ];
            
            // 如果有作者篩選，過濾文章
            if (filters.author) {
                console.log('根據作者篩選文章:', filters.author);
                const filteredPosts = mockPosts.filter(post => 
                    post.author?.username === filters.author
                );
                console.log('篩選後的文章:', filteredPosts);
                return filteredPosts;
            }
            
            console.log('返回所有 mock 文章:', mockPosts);
            return mockPosts;
        }
    },
    
    // 載入精選文章
    async loadFeaturedPosts() {
        try {
            const posts = await BlogAPI.posts.getFeatured();
            return posts;
        } catch (error) {
            console.error('載入精選文章失敗:', error);
            return [];
        }
    },
    

};

// 暴露到全局
window.DataLoader = DataLoader;
