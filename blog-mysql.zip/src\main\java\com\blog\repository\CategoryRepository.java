package com.blog.repository;

import com.blog.entity.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * 分類資料存取介面
 */
@Repository
public interface CategoryRepository extends JpaRepository<Category, Integer> {
    
    /**
     * 根據路徑查找分類
     */
    Optional<Category> findBySlug(String slug);
    
    /**
     * 檢查路徑是否存在
     */
    boolean existsBySlug(String slug);
    
    /**
     * 根據啟用狀態查找分類
     */
    List<Category> findByIsActive(Boolean isActive);
    
    /**
     * 根據名稱查找分類
     */
    Optional<Category> findByName(String name);
    
    /**
     * 檢查分類名稱是否存在
     */
    boolean existsByName(String name);
    
    /**
     * 查找啟用的分類，依建立時間排序
     */
    @Query("SELECT c FROM Category c WHERE c.isActive = true ORDER BY c.createdAt DESC")
    List<Category> findActiveCategories();
    
    /**
     * 搜尋分類 (根據名稱或描述)
     */
    @Query("SELECT c FROM Category c WHERE " +
           "(:keyword IS NULL OR " +
           "c.name LIKE CONCAT('%', :keyword, '%') OR " +
           "c.description LIKE CONCAT('%', :keyword, '%'))")
    Page<Category> searchCategories(@Param("keyword") String keyword, Pageable pageable);
    
    /**
     * 查找有文章的分類 (帶文章數量)
     */
    @Query("SELECT c, COUNT(p) as postCount FROM Category c " +
           "LEFT JOIN c.posts p " +
           "WHERE c.isActive = true AND (p.status = com.blog.entity.PostStatus.PUBLISHED OR p IS NULL) " +
           "GROUP BY c " +
           "ORDER BY postCount DESC")
    List<Object[]> findCategoriesWithPostCount();
    
    /**
     * 根據分類查找已發布文章數量
     */
    @Query("SELECT COUNT(p) FROM Post p WHERE p.category.categoryId = :categoryId AND p.status = com.blog.entity.PostStatus.PUBLISHED")
    Long countPublishedPostsByCategory(@Param("categoryId") Integer categoryId);

    /**
     * 計算活躍分類數量
     */
    long countByIsActiveTrue();
} 