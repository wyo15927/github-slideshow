package com.blog.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 標籤實體類別
 * 對應資料庫 Tags 表格
 */
@Entity
@Table(name = "Tags")
@EntityListeners(AuditingEntityListener.class)
public class Tag {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TagId")
    private Integer tagId;
    
    @NotBlank(message = "標籤名稱不能為空")
    @Size(max = 50, message = "標籤名稱不能超過50個字元")
    @Column(name = "Name", unique = true, nullable = false, length = 50)
    private String name;
    
    @NotBlank(message = "標籤路徑不能為空")
    @Size(max = 50, message = "標籤路徑不能超過50個字元")
    @Column(name = "Slug", unique = true, nullable = false, length = 50)
    private String slug;
    
    @Size(max = 200, message = "標籤描述不能超過200個字元")
    @Column(name = "Description", length = 200)
    private String description;
    
    @Size(max = 7, message = "顏色代碼格式不正確")
    @Column(name = "Color", length = 7)
    private String color = "#6c757d";
    
    @Column(name = "UsageCount")
    private Integer usageCount = 0;
    
    @CreatedDate
    @Column(name = "CreatedAt", updatable = false)
    private LocalDateTime createdAt;
    
    // 關聯關係
    @ManyToMany(mappedBy = "tags", fetch = FetchType.LAZY)
    private List<Post> posts;
    
    // 預設建構子
    public Tag() {}
    
    // 建構子
    public Tag(String name, String slug) {
        this.name = name;
        this.slug = slug;
    }
    
    // Getters and Setters
    public Integer getTagId() { return tagId; }
    public void setTagId(Integer tagId) { this.tagId = tagId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getSlug() { return slug; }
    public void setSlug(String slug) { this.slug = slug; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    
    public Integer getUsageCount() { return usageCount; }
    public void setUsageCount(Integer usageCount) { this.usageCount = usageCount; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public List<Post> getPosts() { return posts; }
    public void setPosts(List<Post> posts) { this.posts = posts; }
} 