package com.blog.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;

/**
 * 更新個人資料請求 DTO
 */
public class UpdateProfileRequest {
    
    @Size(max = 100, message = "顯示名稱不能超過100個字元")
    private String displayName;
    
    @Email(message = "電子郵件格式不正確")
    @Size(max = 100, message = "電子郵件不能超過100個字元")
    private String email;
    
    @Size(max = 500, message = "頭像路徑不能超過500個字元")
    private String avatar;
    
    @Size(max = 100, message = "職業不能超過100個字元")
    private String profession;
    
    @Size(max = 1000, message = "個人簡介不能超過1000個字元")
    private String bio;
    
    @Size(max = 100, message = "所在地不能超過100個字元")
    private String location;
    
    @Size(max = 200, message = "個人網站不能超過200個字元")
    private String website;
    
    public UpdateProfileRequest() {}
    
    // Getters and Setters
    public String getDisplayName() {
        return displayName;
    }
    
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getAvatar() {
        return avatar;
    }
    
    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }
    
    public String getProfession() {
        return profession;
    }
    
    public void setProfession(String profession) {
        this.profession = profession;
    }
    
    public String getBio() {
        return bio;
    }
    
    public void setBio(String bio) {
        this.bio = bio;
    }
    
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public String getWebsite() {
        return website;
    }
    
    public void setWebsite(String website) {
        this.website = website;
    }
}
