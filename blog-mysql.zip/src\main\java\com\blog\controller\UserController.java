package com.blog.controller;

import com.blog.dto.request.UpdateProfileRequest;
import com.blog.dto.response.UserResponse;
import com.blog.entity.User;
import com.blog.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * 用戶個人資料管理控制器
 */
@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "*")
public class UserController {
    
    @Autowired
    private UserService userService;
    
    /**
     * 獲取當前用戶資料
     */
    @GetMapping("/profile")
    public ResponseEntity<Map<String, Object>> getCurrentUserProfile(HttpServletRequest request) {
        try {
            // 從請求頭獲取token（簡單實現）
            String authHeader = request.getHeader("Authorization");
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.status(401).body(createErrorResponse("未授權"));
            }
            
            String token = authHeader.substring(7);
            String username = token.split(":")[0]; // 簡單token解析
            
            Optional<User> userOpt = userService.findByUsername(username);
            if (userOpt.isEmpty()) {
                return ResponseEntity.status(404).body(createErrorResponse("用戶不存在"));
            }
            
            User user = userOpt.get();
            UserResponse userResponse = convertToUserResponse(user);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", userResponse);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            return ResponseEntity.status(500).body(createErrorResponse("獲取用戶資料失敗"));
        }
    }
    
    /**
     * 更新當前用戶資料
     */
    @PutMapping("/profile")
    public ResponseEntity<Map<String, Object>> updateCurrentUserProfile(
            @Valid @RequestBody UpdateProfileRequest request,
            HttpServletRequest httpRequest) {
        try {
            // 從請求頭獲取token
            String authHeader = httpRequest.getHeader("Authorization");
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.status(401).body(createErrorResponse("未授權"));
            }
            
            String token = authHeader.substring(7);
            String username = token.split(":")[0];
            
            Optional<User> userOpt = userService.findByUsername(username);
            if (userOpt.isEmpty()) {
                return ResponseEntity.status(404).body(createErrorResponse("用戶不存在"));
            }
            
            User user = userOpt.get();
            
            // 更新用戶資料
            if (request.getDisplayName() != null) {
                user.setDisplayName(request.getDisplayName());
            }
            if (request.getEmail() != null) {
                user.setEmail(request.getEmail());
            }
            if (request.getAvatar() != null) {
                user.setAvatar(request.getAvatar());
            }
            if (request.getProfession() != null) {
                user.setProfession(request.getProfession());
            }
            if (request.getBio() != null) {
                user.setBio(request.getBio());
            }
            if (request.getLocation() != null) {
                user.setLocation(request.getLocation());
            }
            if (request.getWebsite() != null) {
                user.setWebsite(request.getWebsite());
            }
            
            // 保存更新
            User updatedUser = userService.updateUser(user);
            UserResponse userResponse = convertToUserResponse(updatedUser);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "個人資料更新成功");
            response.put("data", userResponse);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            return ResponseEntity.status(500).body(createErrorResponse("更新個人資料失敗: " + e.getMessage()));
        }
    }
    
    /**
     * 根據用戶名獲取公開資料
     */
    @GetMapping("/profile/{username}")
    public ResponseEntity<Map<String, Object>> getUserPublicProfile(@PathVariable String username) {
        try {
            // 使用帶有 posts 關聯的方法獲取用戶資料
            Optional<User> userOpt = userService.findByUsernameWithPosts(username);
            if (userOpt.isEmpty()) {
                return ResponseEntity.status(404).body(createErrorResponse("用戶不存在"));
            }
            
            User user = userOpt.get();
            UserResponse userResponse = convertToPublicUserResponse(user);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", userResponse);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            e.printStackTrace(); // 添加錯誤日誌
            return ResponseEntity.status(500).body(createErrorResponse("獲取用戶資料失敗: " + e.getMessage()));
        }
    }
    
    /**
     * 獲取所有用戶列表（用於作者頁面）
     */
    @GetMapping("/users")
    public ResponseEntity<Map<String, Object>> getAllUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "false") boolean includeStats,
            @RequestParam(defaultValue = "false") boolean includePosts) {
        try {
            // 獲取所有用戶並加載文章數據（用於作者列表）
            java.util.List<User> users = userService.getAllUsersWithPosts();
            
            // 轉換為公開資料格式
            java.util.List<UserResponse> userResponses = users.stream()
                .map(this::convertToPublicUserResponse)
                .collect(java.util.stream.Collectors.toList());
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", userResponses);
            response.put("total", users.size());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            return ResponseEntity.status(500).body(createErrorResponse("獲取用戶列表失敗: " + e.getMessage()));
        }
    }
    
    // 私有輔助方法
    private UserResponse convertToUserResponse(User user) {
        UserResponse response = new UserResponse();
        response.setUserId(user.getUserId());
        response.setUsername(user.getUsername());
        response.setEmail(user.getEmail());
        response.setDisplayName(user.getDisplayName());
        response.setAvatar(user.getAvatar());
        response.setProfession(user.getProfession());
        response.setBio(user.getBio());
        response.setLocation(user.getLocation());
        response.setWebsite(user.getWebsite());
        response.setRole(user.getRole().name());
        response.setIsActive(user.getIsActive());
        response.setCreatedAt(user.getCreatedAt());
        response.setLastLoginAt(user.getLastLoginAt());
        
        return response;
    }
    
    private UserResponse convertToPublicUserResponse(User user) {
        UserResponse response = new UserResponse();
        response.setUserId(user.getUserId());
        response.setUsername(user.getUsername());
        // 不返回email給公開API
        response.setDisplayName(user.getDisplayName());
        response.setAvatar(user.getAvatar());
        response.setProfession(user.getProfession());
        response.setBio(user.getBio());
        response.setLocation(user.getLocation());
        response.setWebsite(user.getWebsite());
        response.setRole(user.getRole().name());
        response.setCreatedAt(user.getCreatedAt());
        
        // 計算文章統計數據
        if (user.getPosts() != null) {
            int postCount = user.getPosts().size();
            int totalViews = user.getPosts().stream()
                .mapToInt(post -> post.getViewCount() != null ? post.getViewCount() : 0)
                .sum();
            int totalLikes = user.getPosts().stream()
                .mapToInt(post -> post.getLikeCount() != null ? post.getLikeCount() : 0)
                .sum();
            
            response.setPostCount(postCount);
            response.setTotalViews(totalViews);
            response.setTotalLikes(totalLikes);
        } else {
            response.setPostCount(0);
            response.setTotalViews(0);
            response.setTotalLikes(0);
        }
        
        return response;
    }
    
    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        return response;
    }
}
