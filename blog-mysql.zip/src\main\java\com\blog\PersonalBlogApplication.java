package com.blog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * 個人部落格網站主應用程式
 * 
 * @author Blog Developer
 * @version 1.0.0
 */
@SpringBootApplication
@EnableJpaAuditing
@EnableAsync
@EnableTransactionManagement
public class PersonalBlogApplication {

    public static void main(String[] args) {
        SpringApplication.run(PersonalBlogApplication.class, args);
        System.out.println("\n🚀 個人部落格網站啟動成功！");
        System.out.println("📖 API 文檔: http://localhost:8080/api/swagger-ui.html");
        System.out.println("🔗 基礎 URL: http://localhost:8080/api");
        System.out.println("==========================================");
    }
} 