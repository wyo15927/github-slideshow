/**
 * 工具函數類
 * 提供常用的工具方法
 */

const Utils = {
    // 格式化日期
    formatDate(dateString) {
        if (!dateString) return '未知時間';
        
        try {
            const date = new Date(dateString);
            const now = new Date();
            const diffInMinutes = Math.floor((now - date) / (1000 * 60));
            
            if (diffInMinutes < 1) return '剛剛';
            if (diffInMinutes < 60) return `${diffInMinutes} 分鐘前`;
            
            const diffInHours = Math.floor(diffInMinutes / 60);
            if (diffInHours < 24) return `${diffInHours} 小時前`;
            
            const diffInDays = Math.floor(diffInHours / 24);
            if (diffInDays < 7) return `${diffInDays} 天前`;
            
            return date.toLocaleDateString('zh-TW', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        } catch (error) {
            return '未知時間';
        }
    },
    
    // 截取文字
    truncateText(text, maxLength = 150) {
        if (!text || text.length <= maxLength) return text;
        return text.substring(0, maxLength) + '...';
    },
    
    // 生成隨機顏色
    generateColor() {
        const colors = [
            'primary', 'secondary', 'success', 'info', 
            'warning', 'danger', 'light', 'dark'
        ];
        return colors[Math.floor(Math.random() * colors.length)];
    },
    
    // 顯示提示訊息
    showToast(message, type = 'info') {
        // 簡單的提示訊息實作
        const toast = document.createElement('div');
        toast.className = `alert alert-${type} position-fixed`;
        toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        toast.textContent = message;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.remove();
        }, 3000);
    },
    
    // 防抖函數
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
};

// 暴露到全局
window.Utils = Utils;
