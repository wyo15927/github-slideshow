package com.blog.repository;

import com.blog.entity.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * 標籤資料存取介面
 */
@Repository
public interface TagRepository extends JpaRepository<Tag, Integer> {
    
    /**
     * 根據路徑查找標籤
     */
    Optional<Tag> findBySlug(String slug);
    
    /**
     * 檢查路徑是否存在
     */
    boolean existsBySlug(String slug);
    
    /**
     * 根據名稱查找標籤
     */
    Optional<Tag> findByName(String name);
    
    /**
     * 檢查標籤名稱是否存在
     */
    boolean existsByName(String name);
    
    /**
     * 根據名稱列表查找標籤
     */
    List<Tag> findByNameIn(List<String> names);
    
    /**
     * 搜尋標籤 (根據名稱或描述)
     */
    @Query("SELECT t FROM Tag t WHERE " +
           "(:keyword IS NULL OR " +
           "t.name LIKE CONCAT('%', :keyword, '%') OR " +
           "t.description LIKE CONCAT('%', :keyword, '%'))")
    Page<Tag> searchTags(@Param("keyword") String keyword, Pageable pageable);
    
    /**
     * 查找熱門標籤 (依使用次數排序)
     */
    @Query("SELECT t FROM Tag t WHERE t.usageCount > 0 ORDER BY t.usageCount DESC")
    List<Tag> findPopularTags(Pageable pageable);
    
    /**
     * 查找最新標籤
     */
    @Query("SELECT t FROM Tag t ORDER BY t.createdAt DESC")
    List<Tag> findLatestTags(Pageable pageable);
    
    /**
     * 根據使用次數範圍查找標籤
     */
    @Query("SELECT t FROM Tag t WHERE t.usageCount BETWEEN :minUsage AND :maxUsage ORDER BY t.usageCount DESC")
    List<Tag> findTagsByUsageRange(@Param("minUsage") Integer minUsage, 
                                   @Param("maxUsage") Integer maxUsage);
    
    /**
     * 查找指定文章的標籤
     */
    @Query("SELECT t FROM Tag t JOIN t.posts p WHERE p.postId = :postId")
    List<Tag> findTagsByPostId(@Param("postId") Integer postId);
    
    /**
     * 查找與指定標籤相關的其他標籤 (共同出現在文章中)
     */
    @Query("SELECT DISTINCT t FROM Tag t " +
           "JOIN t.posts p " +
           "JOIN p.tags ot " +
           "WHERE ot.tagId = :tagId AND t.tagId != :tagId " +
           "ORDER BY t.usageCount DESC")
    List<Tag> findRelatedTags(@Param("tagId") Integer tagId, Pageable pageable);

    /**
     * 計算使用次數大於指定值的標籤數量
     */
    long countByUsageCountGreaterThan(int usageCount);
} 