/**
 * 文章編輯器 JavaScript 功能
 * 提供完整的文章編輯體驗
 */

// 全域變數
let quill = null;
let currentArticleId = null;
let isEditing = false;
let autoSaveTimer = null;
let tags = [];

// DOM 載入完成後初始化
document.addEventListener('DOMContentLoaded', function() {
    initializeEditor();
});

/**
 * 初始化編輯器
 */
function initializeEditor() {
    try {
        // 檢查登入狀態
        if (!window.AuthManager || !window.AuthManager.isLoggedIn()) {
            alert('請先登入後再使用編輯器');
            window.location.href = 'login.html';
            return;
        }
        
        // 檢查是否為編輯模式
        checkEditMode();
        
        // 初始化 Quill 編輯器
        initializeQuillEditor();
        
        // 初始化標籤輸入
        initializeTagInput();
        
        // 載入分類數據
        loadCategories();
        
        // 設置自動保存
        setupAutoSave();
        
        // 綁定表單事件
        bindFormEvents();
        
    } catch (error) {
        console.error('初始化編輯器失敗:', error);
        alert('初始化編輯器失敗，請重新載入頁面');
    }
}

/**
 * 檢查是否為編輯模式
 */
function checkEditMode() {
    const urlParams = new URLSearchParams(window.location.search);
    const editId = urlParams.get('edit');
    
    if (editId) {
        isEditing = true;
        // ⚠️ 不要在這裡設置 currentArticleId，因為 editId 是 slug（字符串）
        // currentArticleId 必須是數字（postId），會在 loadArticleForEdit() 中設置
        document.getElementById('editor-title').textContent = '編輯文章';
        loadArticleForEdit(editId);
    }
}

/**
 * 初始化 Quill 編輯器
 */
function initializeQuillEditor() {
    // Quill 編輯器配置
    const toolbarOptions = [
        ['bold', 'italic', 'underline', 'strike'],
        ['blockquote', 'code-block'],
        [{ 'header': 1 }, { 'header': 2 }],
        [{ 'list': 'ordered'}, { 'list': 'bullet' }],
        [{ 'script': 'sub'}, { 'script': 'super' }],
        [{ 'indent': '-1'}, { 'indent': '+1' }],
        [{ 'direction': 'rtl' }],
        [{ 'size': ['small', false, 'large', 'huge'] }],
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
        [{ 'color': [] }, { 'background': [] }],
        [{ 'font': [] }],
        [{ 'align': [] }],
        ['clean'],
        ['link', 'image', 'video']
    ];
    
    // 創建 Quill 實例
    quill = new Quill('#editor', {
        theme: 'snow',
        modules: {
            toolbar: toolbarOptions
        },
        placeholder: '開始撰寫您的文章內容...'
    });
    
    // 監聽內容變化
    quill.on('text-change', function() {
        triggerAutoSave();
    });
}

/**
 * 初始化標籤輸入
 */
function initializeTagInput() {
    const tagInput = document.getElementById('tag-input-field');
    
    tagInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            addTag(this.value.trim());
            this.value = '';
        }
    });
    
    tagInput.addEventListener('blur', function() {
        if (this.value.trim()) {
            addTag(this.value.trim());
            this.value = '';
        }
    });
}

/**
 * 添加標籤
 */
function addTag(tagName) {
    if (!tagName || tagName.length === 0) return;
    
    // 檢查標籤是否已存在
    if (tags.includes(tagName)) {
        showAlert('標籤已存在', 'warning');
        return;
    }
    
    // 檢查標籤長度
    if (tagName.length > 20) {
        showAlert('標籤長度不能超過20個字符', 'warning');
        return;
    }
    
    tags.push(tagName);
    renderTags();
    triggerAutoSave();
}

/**
 * 移除標籤
 */
function removeTag(tagName) {
    const index = tags.indexOf(tagName);
    if (index > -1) {
        tags.splice(index, 1);
        renderTags();
        triggerAutoSave();
    }
}

/**
 * 渲染標籤
 */
function renderTags() {
    const tagInput = document.getElementById('tag-input');
    const tagInputField = document.getElementById('tag-input-field');
    
    // 清空現有標籤
    tagInput.innerHTML = '';
    
    // 渲染標籤
    tags.forEach(tag => {
        const tagElement = document.createElement('span');
        tagElement.className = 'tag-item';
        tagElement.innerHTML = `
            ${tag}
            <span class="remove-tag" onclick="removeTag('${tag}')">&times;</span>
        `;
        tagInput.appendChild(tagElement);
    });
    
    // 添加輸入框
    tagInput.appendChild(tagInputField);
}

/**
 * 載入分類數據
 */
async function loadCategories() {
    try {
        // 這裡應該呼叫 API 獲取分類列表
        // 暫時使用模擬數據
        const categories = [
            { id: 1, name: '前端開發' },
            { id: 2, name: '後端開發' },
            { id: 3, name: '移動開發' },
            { id: 4, name: '資料庫' },
            { id: 5, name: 'DevOps' }
        ];
        
        renderCategories(categories);
        
    } catch (error) {
        console.error('載入分類失敗:', error);
    }
}

/**
 * 渲染分類選項
 */
function renderCategories(categories) {
    const select = document.getElementById('article-category');
    
    // 清空現有選項（保留預設選項）
    select.innerHTML = '<option value="">選擇分類</option>';
    
    // 添加分類選項
    categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category.id;
        option.textContent = category.name;
        select.appendChild(option);
    });
}

/**
 * 設置自動保存
 */
function setupAutoSave() {
    // 每30秒自動保存一次
    setInterval(() => {
        if (hasContentChanges()) {
            saveDraft(true); // 靜默保存
        }
    }, 30000);
}

/**
 * 觸發自動保存
 */
function triggerAutoSave() {
    // 清除現有計時器
    if (autoSaveTimer) {
        clearTimeout(autoSaveTimer);
    }
    
    // 設置新的計時器（3秒後保存）
    autoSaveTimer = setTimeout(() => {
        if (hasContentChanges()) {
            saveDraft(true); // 靜默保存
        }
    }, 3000);
}

/**
 * 檢查是否有內容變化
 */
function hasContentChanges() {
    const title = document.getElementById('article-title').value.trim();
    const content = quill.getText().trim();
    
    return title.length > 0 || content.length > 0;
}

/**
 * 綁定表單事件
 */
function bindFormEvents() {
    const form = document.getElementById('article-form');
    const inputs = form.querySelectorAll('input, select, textarea');
    
    inputs.forEach(input => {
        input.addEventListener('change', triggerAutoSave);
        input.addEventListener('input', triggerAutoSave);
    });
}

/**
 * 保存草稿
 */
async function saveDraft(silent = false) {
    try {
        const articleData = collectArticleData();
        
        if (!articleData.title.trim()) {
            if (!silent) {
                showAlert('請輸入文章標題', 'warning');
            }
            return;
        }
        
        // 設置為草稿狀態
        articleData.status = 'draft';
        
        if (isEditing) {
            // 更新現有文章
            await updateArticle(articleData);
        } else {
            // 創建新文章
            const result = await createArticle(articleData);
            if (result) {
                currentArticleId = result.id;
                isEditing = true;
                document.getElementById('editor-title').textContent = '編輯文章';
                
                // 更新 URL
                const newUrl = new URL(window.location);
                newUrl.searchParams.set('edit', result.id);
                window.history.replaceState({}, '', newUrl);
            }
        }
        
        if (!silent) {
            showAlert('草稿保存成功', 'success');
        }
        
        // 顯示保存指示器
        showSaveIndicator();
        
    } catch (error) {
        console.error('保存草稿失敗:', error);
        if (!silent) {
            showAlert('保存草稿失敗', 'error');
        }
    }
}

/**
 * 發布文章
 */
async function publishArticle() {
    try {
        const articleData = collectArticleData();
        
        if (!articleData.title.trim()) {
            showAlert('請輸入文章標題', 'warning');
            return;
        }
        
        if (!quill.getText().trim()) {
            showAlert('請輸入文章內容', 'warning');
            return;
        }
        
        // 設置為發布狀態
        articleData.status = 'published';
        articleData.publishedAt = new Date().toISOString();
        
        if (isEditing) {
            // 更新現有文章
            await updateArticle(articleData);
        } else {
            // 創建新文章
            const result = await createArticle(articleData);
            if (result) {
                currentArticleId = result.id;
                isEditing = true;
            }
        }
        
        showAlert('文章發布成功！', 'success');
        
        // 延遲跳轉到後台
        setTimeout(() => {
            window.location.href = 'admin.html';
        }, 1500);
        
    } catch (error) {
        console.error('發布文章失敗:', error);
        showAlert('發布文章失敗', 'error');
    }
}

/**
 * 收集文章數據
 */
function collectArticleData() {
    const status = document.getElementById('article-status').value;
    const categoryId = document.getElementById('article-category').value;
    
    const data = {
        title: document.getElementById('article-title').value.trim(),
        excerpt: document.getElementById('article-excerpt').value.trim(),
        content: quill.root.innerHTML,
        contentText: quill.getText().trim(),
        categoryId: categoryId ? parseInt(categoryId) : null,
        tags: tags || [],
        status: status.toUpperCase() // 後端期望大寫狀態
    };
    
    console.log('收集的文章數據:', data);
    return data;
}

/**
 * 創建文章
 */
async function createArticle(articleData) {
    try {
        // 這裡應該呼叫 API 創建文章
        // 暫時使用模擬數據
        console.log('創建文章:', articleData);
        
        // 模擬 API 響應
        return {
            id: Date.now(),
            slug: generateSlug(articleData.title),
            ...articleData
        };
        
    } catch (error) {
        console.error('創建文章失敗:', error);
        throw error;
    }
}

/**
 * 更新文章
 */
async function updateArticle(articleData) {
    try {
        // ✅ 驗證 currentArticleId 是否為有效的數字
        if (!currentArticleId || typeof currentArticleId !== 'number') {
            throw new Error(`無效的文章 ID: ${currentArticleId} (類型: ${typeof currentArticleId})`);
        }
        
        console.log('更新文章 ID:', currentArticleId, '(類型:', typeof currentArticleId, ')');
        console.log('更新數據:', articleData);
        
        // 🆕 調用後端 API 更新文章
        const response = await BlogAPI.posts.update(currentArticleId, articleData);
        console.log('✅ 更新文章 API 成功:', response);
        
        return response;
        
    } catch (error) {
        console.error('❌ 更新文章 API 失敗:', error);
        throw error;
    }
}

/**
 * 載入文章進行編輯
 */
async function loadArticleForEdit(articleId) {
    try {
        console.log('載入文章進行編輯（slug）:', articleId);
        
        // 🆕 調用後端 API 獲取文章數據
        const article = await BlogAPI.posts.getBySlug(articleId);
        console.log('✅ 載入文章成功:', article);
        
        // ✅ 必須保存數字型的 postId，而不是字符串型的 slug
        if (!article.postId) {
            throw new Error('文章數據缺少 postId 字段');
        }
        
        currentArticleId = article.postId;
        console.log('✅ 設置 currentArticleId:', currentArticleId, '(類型:', typeof currentArticleId, ')');
        
        populateEditor(article);
        
    } catch (error) {
        console.error('❌ 載入文章失敗:', error);
        showAlert('載入文章失敗，請稍後再試', 'error');
    }
}

/**
 * 填充編輯器數據
 */
function populateEditor(article) {
    console.log('填充編輯器數據:', article);
    
    // 標題
    document.getElementById('article-title').value = article.title || '';
    
    // 摘要
    document.getElementById('article-excerpt').value = article.excerpt || '';
    
    // 分類（處理可能的對象格式）
    const categoryId = article.categoryId || (article.category ? article.category.categoryId : '');
    document.getElementById('article-category').value = categoryId;
    
    // 狀態（轉換為小寫以匹配前端）
    const status = (article.status || 'draft').toLowerCase();
    document.getElementById('article-status').value = status;
    
    // 內容
    if (article.content) {
        quill.root.innerHTML = article.content;
    }
    
    // 標籤（處理可能的對象數組格式）
    if (article.tags && Array.isArray(article.tags)) {
        // 如果是對象數組，提取name字段
        tags = article.tags.map(tag => typeof tag === 'object' ? tag.name : tag);
        renderTags();
    }
    
    console.log('✅ 編輯器數據已填充');
}

/**
 * 生成文章 slug
 */
function generateSlug(title) {
    return title
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .trim('-');
}

/**
 * 切換預覽模式
 */
function togglePreview() {
    const previewSection = document.getElementById('preview-section');
    const isVisible = previewSection.style.display !== 'none';
    
    if (isVisible) {
        previewSection.style.display = 'none';
    } else {
        generatePreview();
        previewSection.style.display = 'block';
    }
}

/**
 * 生成預覽內容
 */
function generatePreview() {
    const previewContent = document.getElementById('preview-content');
    const articleData = collectArticleData();
    
    const previewHtml = `
        <div class="article-preview">
            <h1 class="mb-3">${articleData.title || '無標題'}</h1>
            
            ${articleData.excerpt ? `
                <div class="excerpt mb-4">
                    <p class="lead text-muted">${articleData.excerpt}</p>
                </div>
            ` : ''}
            
            ${articleData.categoryId ? `
                <div class="meta mb-3">
                    <span class="badge bg-primary me-2">分類: ${getCategoryName(articleData.categoryId)}</span>
                </div>
            ` : ''}
            
            ${tags.length > 0 ? `
                <div class="tags mb-3">
                    ${tags.map(tag => `<span class="badge bg-secondary me-1">${tag}</span>`).join('')}
                </div>
            ` : ''}
            
            <div class="content">
                ${articleData.content || '<p class="text-muted">暫無內容</p>'}
            </div>
        </div>
    `;
    
    previewContent.innerHTML = previewHtml;
}

/**
 * 獲取分類名稱
 */
function getCategoryName(categoryId) {
    const select = document.getElementById('article-category');
    const option = select.querySelector(`option[value="${categoryId}"]`);
    return option ? option.textContent : '未知分類';
}

/**
 * 顯示保存指示器
 */
function showSaveIndicator() {
    const indicator = document.getElementById('save-indicator');
    indicator.classList.add('show');
    
    setTimeout(() => {
        indicator.classList.remove('show');
    }, 3000);
}

/**
 * 顯示提示訊息
 */
function showAlert(message, type = 'info') {
    // 創建提示元素
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // 添加到頁面
    document.body.appendChild(alertDiv);
    
    // 3秒後自動移除
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.parentNode.removeChild(alertDiv);
        }
    }, 3000);
}

// 頁面離開前提示保存
window.addEventListener('beforeunload', function(e) {
    if (hasContentChanges()) {
        e.preventDefault();
        e.returnValue = '您有未保存的內容，確定要離開嗎？';
    }
});
