package com.blog.repository;

import com.blog.entity.Post;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * 文章資料存取介面
 */
@Repository
public interface PostRepository extends JpaRepository<Post, Integer> {
    
    /**
     * 根據路徑查找文章（含關聯數據）
     */
    @Query("SELECT p FROM Post p LEFT JOIN FETCH p.author LEFT JOIN FETCH p.category LEFT JOIN FETCH p.tags WHERE p.slug = :slug")
    Optional<Post> findBySlug(@Param("slug") String slug);
    
    /**
     * 根據ID查找文章（含關聯數據）
     */
    @Query("SELECT p FROM Post p LEFT JOIN FETCH p.author LEFT JOIN FETCH p.category LEFT JOIN FETCH p.tags WHERE p.postId = :postId")
    Optional<Post> findByIdWithAssociations(@Param("postId") Integer postId);
    
    /**
     * 檢查路徑是否存在
     */
    boolean existsBySlug(String slug);
    
    /**
     * 根據狀態查找文章
     */
    Page<Post> findByStatus(String status, Pageable pageable);
    
    /**
     * 查找已發布的文章
     */
    @Query("SELECT p FROM Post p LEFT JOIN FETCH p.author WHERE p.status = com.blog.entity.PostStatus.PUBLISHED AND p.publishedAt <= :now")
    Page<Post> findPublishedPosts(@Param("now") LocalDateTime now, Pageable pageable);
    
    /**
     * 根據作者查找文章
     */
    Page<Post> findByAuthorUserId(Integer authorId, Pageable pageable);
    
    /**
     * 根據作者用戶名查找已發布的文章
     */
    @Query("SELECT p FROM Post p LEFT JOIN FETCH p.author WHERE p.author.username = :username AND " +
           "p.status = com.blog.entity.PostStatus.PUBLISHED AND p.publishedAt <= :now")
    Page<Post> findPublishedPostsByAuthorUsername(@Param("username") String username, 
                                                 @Param("now") LocalDateTime now, 
                                                 Pageable pageable);
    
    /**
     * 根據分類名稱或slug查找已發布的文章
     */
    @Query("SELECT p FROM Post p LEFT JOIN FETCH p.author LEFT JOIN FETCH p.category WHERE " +
           "(p.category.name = :categoryNameOrSlug OR p.category.slug = :categoryNameOrSlug) AND " +
           "p.status = com.blog.entity.PostStatus.PUBLISHED AND p.publishedAt <= :now")
    Page<Post> findPublishedPostsByCategoryNameOrSlug(@Param("categoryNameOrSlug") String categoryNameOrSlug, 
                                                     @Param("now") LocalDateTime now, 
                                                     Pageable pageable);
    
    /**
     * 根據分類查找已發布文章
     */
    @Query("SELECT p FROM Post p LEFT JOIN FETCH p.author WHERE p.category.categoryId = :categoryId AND " +
           "p.status = com.blog.entity.PostStatus.PUBLISHED AND p.publishedAt <= :now")
    Page<Post> findPublishedPostsByCategory(@Param("categoryId") Integer categoryId, 
                                          @Param("now") LocalDateTime now, 
                                          Pageable pageable);
    
    /**
     * 根據標籤查找已發布文章
     */
    @Query("SELECT DISTINCT p FROM Post p LEFT JOIN FETCH p.author JOIN p.tags t WHERE t.tagId = :tagId AND " +
           "p.status = com.blog.entity.PostStatus.PUBLISHED AND p.publishedAt <= :now")
    Page<Post> findPublishedPostsByTag(@Param("tagId") Integer tagId, 
                                     @Param("now") LocalDateTime now, 
                                     Pageable pageable);
    
    /**
     * 查找精選文章
     */
    @Query("SELECT p FROM Post p LEFT JOIN FETCH p.author WHERE p.isFeatured = true AND " +
           "p.status = com.blog.entity.PostStatus.PUBLISHED AND p.publishedAt <= :now")
    List<Post> findFeaturedPosts(@Param("now") LocalDateTime now, Pageable pageable);
    
    /**
     * 搜尋文章
     */
    @Query("SELECT DISTINCT p FROM Post p " +
           "LEFT JOIN FETCH p.author " +
           "LEFT JOIN FETCH p.category " +
           "LEFT JOIN FETCH p.tags " +
           "WHERE (:keyword IS NULL OR " +
           "p.title LIKE CONCAT('%', :keyword, '%') OR " +
           "p.content LIKE CONCAT('%', :keyword, '%') OR " +
           "p.excerpt LIKE CONCAT('%', :keyword, '%')) AND " +
           "p.status = com.blog.entity.PostStatus.PUBLISHED AND p.publishedAt <= :now")
    Page<Post> searchPublishedPosts(@Param("keyword") String keyword, 
                                   @Param("now") LocalDateTime now, 
                                   Pageable pageable);
    
    /**
     * 增加瀏覽次數
     */
    @Modifying
    @Query("UPDATE Post p SET p.viewCount = p.viewCount + 1 WHERE p.postId = :postId")
    void incrementViewCount(@Param("postId") Integer postId);
    
    /**
     * 增加按讚次數
     */
    @Modifying
    @Query("UPDATE Post p SET p.likeCount = p.likeCount + 1 WHERE p.postId = :postId")
    void incrementLikeCount(@Param("postId") Integer postId);

    @Modifying
    @Query("UPDATE Post p SET p.likeCount = GREATEST(p.likeCount - 1, 0) WHERE p.postId = :postId")
    void decrementLikeCount(@Param("postId") Integer postId);
    
    /**
     * 查找相關文章（同分類）
     */
    @Query("SELECT p FROM Post p LEFT JOIN FETCH p.author WHERE p.category.categoryId = :categoryId AND " +
           "p.postId != :excludePostId AND p.status = com.blog.entity.PostStatus.PUBLISHED AND p.publishedAt <= :now")
    List<Post> findRelatedPosts(@Param("categoryId") Integer categoryId, 
                               @Param("excludePostId") Integer excludePostId,
                               @Param("now") LocalDateTime now,
                               Pageable pageable);
    
    /**
     * 查找最新文章
     */
    @Query("SELECT p FROM Post p LEFT JOIN FETCH p.author WHERE p.status = com.blog.entity.PostStatus.PUBLISHED AND p.publishedAt <= :now " +
           "ORDER BY p.publishedAt DESC")
    List<Post> findLatestPosts(@Param("now") LocalDateTime now, Pageable pageable);
    

} 