package com.blog.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 評論實體類別
 * 對應資料庫 Comments 表格
 */
@Entity
@Table(name = "Comments")
@EntityListeners(AuditingEntityListener.class)
public class Comment {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CommentId")
    private Integer commentId;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PostId", nullable = false)
    private Post post;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ParentCommentId")
    private Comment parentComment;
    
    @NotBlank(message = "作者姓名不能為空")
    @Size(max = 100, message = "作者姓名不能超過100個字元")
    @Column(name = "AuthorName", nullable = false, length = 100)
    private String authorName;
    
    @NotBlank(message = "作者郵箱不能為空")
    @Email(message = "郵箱格式不正確")
    @Size(max = 100, message = "作者郵箱不能超過100個字元")
    @Column(name = "AuthorEmail", nullable = false, length = 100)
    private String authorEmail;
    
    @Size(max = 200, message = "作者網站不能超過200個字元")
    @Column(name = "AuthorWebsite", length = 200)
    private String authorWebsite;
    
    @Size(max = 45, message = "IP地址不能超過45個字元")
    @Column(name = "AuthorIp", length = 45)
    private String authorIp;
    
    @NotBlank(message = "評論內容不能為空")
    @Lob
    @Column(name = "Content", nullable = false, columnDefinition = "NTEXT")
    private String content;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "Status", length = 20)
    private CommentStatus status = CommentStatus.PENDING;
    
    @Column(name = "IsNotified")
    private Boolean isNotified = false;
    
    // 按讚計數
    @Column(name = "LikeCount")
    private Integer likeCount = 0;
    
    @CreatedDate
    @Column(name = "CreatedAt", updatable = false)
    private LocalDateTime createdAt;
    
    @LastModifiedDate
    @Column(name = "UpdatedAt")
    private LocalDateTime updatedAt;
    
    // 關聯關係
    @OneToMany(mappedBy = "parentComment", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Comment> replies;
    
    // 預設建構子
    public Comment() {}
    
    // 建構子
    public Comment(String authorName, String authorEmail, String content, Post post) {
        this.authorName = authorName;
        this.authorEmail = authorEmail;
        this.content = content;
        this.post = post;
    }
    
    // Getters and Setters
    public Integer getCommentId() { return commentId; }
    public void setCommentId(Integer commentId) { this.commentId = commentId; }
    
    public Post getPost() { return post; }
    public void setPost(Post post) { this.post = post; }
    
    public Comment getParentComment() { return parentComment; }
    public void setParentComment(Comment parentComment) { this.parentComment = parentComment; }
    
    public String getAuthorName() { return authorName; }
    public void setAuthorName(String authorName) { this.authorName = authorName; }
    
    public String getAuthorEmail() { return authorEmail; }
    public void setAuthorEmail(String authorEmail) { this.authorEmail = authorEmail; }
    
    public String getAuthorWebsite() { return authorWebsite; }
    public void setAuthorWebsite(String authorWebsite) { this.authorWebsite = authorWebsite; }
    
    public String getAuthorIp() { return authorIp; }
    public void setAuthorIp(String authorIp) { this.authorIp = authorIp; }
    
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    
    public CommentStatus getStatus() { return status; }
    public void setStatus(CommentStatus status) { this.status = status; }
    
    public Boolean getIsNotified() { return isNotified; }
    public void setIsNotified(Boolean isNotified) { this.isNotified = isNotified; }
    
    public Integer getLikeCount() { return likeCount; }
    public void setLikeCount(Integer likeCount) { this.likeCount = likeCount; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    
    public List<Comment> getReplies() { return replies; }
    public void setReplies(List<Comment> replies) { this.replies = replies; }
}

 