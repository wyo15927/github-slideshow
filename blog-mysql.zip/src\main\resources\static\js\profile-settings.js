/**
 * 個人設定頁面管理
 */

class ProfileSettings {
    constructor() {
        this.currentUser = null;
        this.originalData = null;
        this.availableAvatars = [
            'images/placeholders/avatar-default.svg',
            'images/placeholders/avatar-male-1.svg',
            'images/placeholders/avatar-female-1.svg',
            'images/placeholders/avatar-male-2.svg',
            'images/placeholders/avatar-female-2.svg',
            'images/placeholders/avatar-tech-1.svg',
            'images/placeholders/avatar-tech-2.svg'
        ];
    }

    // 初始化
    async init() {
        console.log('ProfileSettings 初始化開始');
        console.log('AuthManager 狀態:', {
            exists: typeof window.AuthManager !== 'undefined',
            isLoggedIn: typeof window.AuthManager !== 'undefined' ? window.AuthManager.isLoggedIn() : 'N/A',
            methods: typeof window.AuthManager !== 'undefined' ? Object.getOwnPropertyNames(window.AuthManager) : 'N/A'
        });

        // 檢查登入狀態
        if (!window.AuthManager || !window.AuthManager.isLoggedIn()) {
            Utils.showToast('請先登入', 'warning');
            window.location.href = 'index.html';
            return;
        }

        try {
            // 載入當前用戶資料
            await this.loadCurrentUserProfile();
            
            // 綁定表單事件
            this.bindEvents();
            
            // 生成頭像選項
            this.generateAvatarOptions();
            
            console.log('ProfileSettings 初始化完成');
            
        } catch (error) {
            console.error('初始化個人設定頁面失敗:', error);
            Utils.showToast('載入個人設定失敗，請稍後再試', 'danger');
        }
    }

    // 載入當前用戶資料
    async loadCurrentUserProfile() {
        try {
            console.log('載入當前用戶資料...');
            
            // 使用 BlogAPI.user.getCurrentProfile() 方法
            if (window.BlogAPI && window.BlogAPI.user) {
                const result = await window.BlogAPI.user.getCurrentProfile();
                if (result && result.data) {
                    this.currentUser = result.data;
                    this.originalData = { ...result.data };
                    
                    console.log('用戶資料載入成功:', this.currentUser);
                    
                    // 填充表單
                    this.populateForm();
                    
                    // 隱藏載入指示器，顯示表單
                    document.getElementById('loading').style.display = 'none';
                    document.getElementById('profile-form').style.display = 'block';
                    return;
                }
            }
            
            // 如果 API 調用失敗，使用本地資料
            throw new Error('API 調用失敗，使用本地資料');
            
        } catch (error) {
            console.error('載入用戶資料失敗:', error);
            
            // 嘗試從localStorage獲取用戶資料作為備用
            const localUser = this.getLocalUserData();
            if (localUser) {
                console.log('使用本地用戶資料作為備用');
                this.currentUser = localUser;
                this.originalData = { ...localUser };
                this.populateForm();
                document.getElementById('loading').style.display = 'none';
                document.getElementById('profile-form').style.display = 'block';
                Utils.showToast('使用本地資料，部分功能可能受限', 'warning');
            } else {
                throw error;
            }
        }
    }

    // 獲取本地用戶資料
    getLocalUserData() {
        try {
            const localUser = localStorage.getItem('user');
            const sessionUser = sessionStorage.getItem('user');
            const userData = localUser || sessionUser;
            
            if (userData) {
                return JSON.parse(userData);
            }
            
            // 如果沒有完整的用戶資料，從token解析基本資訊
            const token = window.AuthManager ? window.AuthManager.getToken() : null;
            if (token && token.includes(':')) {
                const username = token.split(':')[0];
                return {
                    username: username,
                    displayName: username,
                    email: '',
                    avatar: 'images/placeholders/avatar-default.svg',
                    profession: '',
                    bio: '',
                    location: '',
                    website: ''
                };
            }
            
            return null;
        } catch (error) {
            console.error('解析本地用戶資料失敗:', error);
            return null;
        }
    }

    // 填充表單
    populateForm() {
        if (!this.currentUser) return;

        console.log('填充表單資料:', this.currentUser);

        document.getElementById('username').value = this.currentUser.username || '';
        document.getElementById('displayName').value = this.currentUser.displayName || '';
        document.getElementById('email').value = this.currentUser.email || '';
        document.getElementById('profession').value = this.currentUser.profession || '';
        document.getElementById('bio').value = this.currentUser.bio || '';
        document.getElementById('location').value = this.currentUser.location || '';
        document.getElementById('website').value = this.currentUser.website || '';
        
        // 設置頭像
        const avatarUrl = this.currentUser.avatar || 'images/placeholders/avatar-default.svg';
        document.getElementById('avatarPreview').src = avatarUrl;
        document.getElementById('avatar').value = avatarUrl;
    }

    // 綁定事件
    bindEvents() {
        // 表單提交事件
        const form = document.getElementById('profileForm');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveProfile();
        });

        // 監聽表單變化
        const inputs = form.querySelectorAll('input, textarea');
        inputs.forEach(input => {
            input.addEventListener('input', () => {
                this.checkFormChanges();
            });
        });
    }

    // 檢查表單是否有變化
    checkFormChanges() {
        if (!this.originalData) return;

        const currentFormData = this.getFormData();
        const hasChanges = JSON.stringify(currentFormData) !== JSON.stringify(this.getOriginalFormData());
        
        // 可以在這裡添加視覺提示表示有未保存的更改
        console.log('表單是否有變化:', hasChanges);
    }

    // 獲取表單資料
    getFormData() {
        return {
            displayName: document.getElementById('displayName').value.trim(),
            email: document.getElementById('email').value.trim(),
            profession: document.getElementById('profession').value.trim(),
            bio: document.getElementById('bio').value.trim(),
            location: document.getElementById('location').value.trim(),
            website: document.getElementById('website').value.trim(),
            avatar: document.getElementById('avatar').value
        };
    }

    // 獲取原始表單資料
    getOriginalFormData() {
        if (!this.originalData) return {};
        
        return {
            displayName: this.originalData.displayName || '',
            email: this.originalData.email || '',
            profession: this.originalData.profession || '',
            bio: this.originalData.bio || '',
            location: this.originalData.location || '',
            website: this.originalData.website || '',
            avatar: this.originalData.avatar || 'images/placeholders/avatar-default.svg'
        };
    }

    // 保存個人資料
    async saveProfile() {
        try {
            console.log('開始保存個人資料...');
            
            const formData = this.getFormData();
            console.log('表單資料:', formData);

            // 驗證必填欄位
            if (!formData.displayName) {
                Utils.showToast('請輸入顯示名稱', 'warning');
                document.getElementById('displayName').focus();
                return;
            }

            if (!formData.email) {
                Utils.showToast('請輸入電子郵件', 'warning');
                document.getElementById('email').focus();
                return;
            }

            // 驗證電子郵件格式
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(formData.email)) {
                Utils.showToast('請輸入有效的電子郵件格式', 'warning');
                document.getElementById('email').focus();
                return;
            }

            // 驗證網站URL格式（如果有填寫）
            if (formData.website && !formData.website.startsWith('http')) {
                formData.website = 'https://' + formData.website;
            }

            // 顯示保存中狀態
            const submitBtn = document.querySelector('#profileForm button[type="submit"]');
            const originalBtnText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>保存中...';
            submitBtn.disabled = true;

            try {
                console.log('開始調用 BlogAPI.user.updateProfile...');
                // 使用 BlogAPI.user.updateProfile() 方法
                if (window.BlogAPI && window.BlogAPI.user) {
                    console.log('BlogAPI.user 存在，調用 updateProfile...');
                    const result = await window.BlogAPI.user.updateProfile(formData);
                    console.log('API 調用結果:', result);
                    
                    if (result && result.data) {
                        // 更新當前用戶資料
                        this.currentUser = result.data;
                        this.originalData = { ...result.data };

                        // 更新本地存儲的用戶資料
                        this.updateLocalUserData(result.data);

                        Utils.showToast('個人資料保存成功！', 'success');
                        console.log('個人資料保存成功:', result.data);
                        
                        // 觸發用戶資料更新事件
                        window.dispatchEvent(new CustomEvent('userProfileUpdated', {
                            detail: result.data
                        }));
                        
                        // 恢復按鈕狀態
                        submitBtn.innerHTML = originalBtnText;
                        submitBtn.disabled = false;
                        return;
                    } else {
                        console.log('API 返回結果異常:', result);
                        throw new Error('API 返回結果異常');
                    }
                } else {
                    console.log('BlogAPI.user 不存在:', window.BlogAPI);
                    throw new Error('BlogAPI.user 不存在');
                }
                
                // 如果 API 調用失敗，使用本地保存
                throw new Error('API 調用失敗，使用本地保存');
                
            } catch (apiError) {
                console.error('API保存失敗，嘗試本地保存:', apiError);
                
                // API失敗時保存到本地存儲
                const updatedUser = { ...this.currentUser, ...formData };
                this.updateLocalUserData(updatedUser);
                this.currentUser = updatedUser;
                this.originalData = { ...updatedUser };
                
                Utils.showToast('資料已保存到本地，下次連線時將同步', 'warning');
                
                // 恢復按鈕狀態
                submitBtn.innerHTML = originalBtnText;
                submitBtn.disabled = false;
            }

        } catch (error) {
            console.error('保存個人資料失敗:', error);
            Utils.showToast('保存失敗，請稍後再試', 'danger');
            
            // 恢復按鈕狀態
            const submitBtn = document.querySelector('#profileForm button[type="submit"]');
            submitBtn.innerHTML = '<i class="fas fa-save me-1"></i>保存設定';
            submitBtn.disabled = false;
        } finally {
            // 確保按鈕狀態總是被恢復
            const submitBtn = document.querySelector('#profileForm button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = false;
                if (!submitBtn.innerHTML.includes('保存設定')) {
                    submitBtn.innerHTML = '<i class="fas fa-save me-1"></i>保存設定';
                }
            }
        }
    }

    // 更新本地用戶資料
    updateLocalUserData(userData) {
        try {
            const userDataStr = JSON.stringify(userData);
            
            // 更新localStorage
            if (localStorage.getItem('user')) {
                localStorage.setItem('user', userDataStr);
            }
            
            // 更新sessionStorage
            if (sessionStorage.getItem('user')) {
                sessionStorage.setItem('user', userDataStr);
            }
            
            console.log('本地用戶資料已更新');
        } catch (error) {
            console.error('更新本地用戶資料失敗:', error);
        }
    }

    // 重置表單
    resetForm() {
        if (confirm('確定要重置所有更改嗎？')) {
            this.populateForm();
            Utils.showToast('表單已重置', 'info');
        }
    }

    // 生成頭像選項
    generateAvatarOptions() {
        const container = document.getElementById('avatarOptions');
        container.innerHTML = '';

        this.availableAvatars.forEach((avatarUrl, index) => {
            const col = document.createElement('div');
            col.className = 'col-4 mb-3';
            
            col.innerHTML = `
                <div class="avatar-option text-center" onclick="profileSettings.selectAvatarOption('${avatarUrl}')" style="cursor: pointer;">
                    <img src="${avatarUrl}" class="img-fluid rounded-circle border" 
                         style="width: 80px; height: 80px; object-fit: cover;" 
                         alt="頭像選項 ${index + 1}"
                         onerror="this.src='images/placeholders/avatar-default.svg'">
                </div>
            `;
            
            container.appendChild(col);
        });
    }

    // 選擇頭像選項
    selectAvatarOption(avatarUrl) {
        document.getElementById('avatar').value = avatarUrl;
        document.getElementById('avatarPreview').src = avatarUrl;
        
        // 關閉模態框
        const modal = bootstrap.Modal.getInstance(document.getElementById('avatarModal'));
        if (modal) {
            modal.hide();
        }
        
        Utils.showToast('頭像已更新', 'success');
    }
}

// 全局函數
function selectAvatar() {
    const modal = new bootstrap.Modal(document.getElementById('avatarModal'));
    modal.show();
}

function resetForm() {
    if (window.profileSettings) {
        window.profileSettings.resetForm();
    }
}

// 頁面載入完成後初始化
document.addEventListener('DOMContentLoaded', async () => {
    console.log('個人設定頁面 DOM 載入完成');
    
    // 創建個人設定管理器實例
    window.profileSettings = new ProfileSettings();
    
    // 初始化
    await window.profileSettings.init();
});
