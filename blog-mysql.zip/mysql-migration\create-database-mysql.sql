-- ================================================
-- MySQL 數據庫創建腳本
-- 從 SQL Server 遷移到 MySQL
-- ================================================

-- 設置字符集
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

-- ================================================
-- 1. Users 表（用戶表）
-- ================================================
CREATE TABLE IF NOT EXISTS Users (
    UserId INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(50) NOT NULL UNIQUE,
    Email VARCHAR(100) NOT NULL UNIQUE,
    PasswordHash VARCHAR(255) NOT NULL,
    DisplayName VARCHAR(100),
    Avatar VARCHAR(500),
    Bio TEXT,
    Website VARCHAR(200),
    Location VARCHAR(100),
    Profession VARCHAR(100),
    Role VARCHAR(20) DEFAULT 'USER',
    IsActive BOOLEAN DEFAULT TRUE,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    LastLoginAt TIMESTAMP NULL,
    INDEX idx_username (Username),
    INDEX idx_email (Email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- 2. Categories 表（分類表）
-- ================================================
CREATE TABLE IF NOT EXISTS Categories (
    CategoryId INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL UNIQUE,
    Slug VARCHAR(50) NOT NULL UNIQUE,
    Description TEXT,
    Color VARCHAR(7),
    Icon VARCHAR(50),
    DisplayOrder INT DEFAULT 0,
    PostCount INT DEFAULT 0,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_slug (Slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- 3. Tags 表（標籤表）
-- ================================================
CREATE TABLE IF NOT EXISTS Tags (
    TagId INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL UNIQUE,
    Slug VARCHAR(50) NOT NULL UNIQUE,
    Description TEXT,
    Color VARCHAR(7),
    UsageCount INT DEFAULT 0,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_slug (Slug),
    INDEX idx_name (Name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- 4. Posts 表（文章表）
-- ================================================
CREATE TABLE IF NOT EXISTS Posts (
    PostId INT AUTO_INCREMENT PRIMARY KEY,
    Title VARCHAR(200) NOT NULL,
    Slug VARCHAR(200) NOT NULL UNIQUE,
    Content LONGTEXT NOT NULL,
    Excerpt TEXT,
    FeaturedImage VARCHAR(500),
    AuthorId INT NOT NULL,
    CategoryId INT,
    Status VARCHAR(20) DEFAULT 'DRAFT',
    ViewCount INT DEFAULT 0,
    LikeCount INT DEFAULT 0,
    IsCommentEnabled BOOLEAN DEFAULT TRUE,
    IsFeatured BOOLEAN DEFAULT FALSE,
    MetaTitle VARCHAR(200),
    MetaDescription TEXT,
    MetaKeywords VARCHAR(500),
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PublishedAt TIMESTAMP NULL,
    FOREIGN KEY (AuthorId) REFERENCES Users(UserId) ON DELETE CASCADE,
    FOREIGN KEY (CategoryId) REFERENCES Categories(CategoryId) ON DELETE SET NULL,
    INDEX idx_slug (Slug),
    INDEX idx_author (AuthorId),
    INDEX idx_category (CategoryId),
    INDEX idx_status (Status),
    INDEX idx_published (PublishedAt),
    INDEX idx_featured (IsFeatured)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- 5. PostTags 表（文章標籤關聯表）
-- ================================================
CREATE TABLE IF NOT EXISTS PostTags (
    PostId INT NOT NULL,
    TagId INT NOT NULL,
    PRIMARY KEY (PostId, TagId),
    FOREIGN KEY (PostId) REFERENCES Posts(PostId) ON DELETE CASCADE,
    FOREIGN KEY (TagId) REFERENCES Tags(TagId) ON DELETE CASCADE,
    INDEX idx_post (PostId),
    INDEX idx_tag (TagId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- 6. Comments 表（評論表）
-- ================================================
CREATE TABLE IF NOT EXISTS Comments (
    CommentId INT AUTO_INCREMENT PRIMARY KEY,
    PostId INT NOT NULL,
    ParentCommentId INT NULL,
    AuthorName VARCHAR(100),
    AuthorEmail VARCHAR(100),
    AuthorWebsite VARCHAR(200),
    AuthorIp VARCHAR(45),
    Content TEXT NOT NULL,
    Status VARCHAR(20) DEFAULT 'APPROVED',
    LikeCount INT DEFAULT 0,
    IsNotified BOOLEAN DEFAULT FALSE,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (PostId) REFERENCES Posts(PostId) ON DELETE CASCADE,
    FOREIGN KEY (ParentCommentId) REFERENCES Comments(CommentId) ON DELETE CASCADE,
    INDEX idx_post (PostId),
    INDEX idx_parent (ParentCommentId),
    INDEX idx_status (Status),
    INDEX idx_created (CreatedAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- 7. Media 表（媒體文件表）
-- ================================================
CREATE TABLE IF NOT EXISTS Media (
    MediaId INT AUTO_INCREMENT PRIMARY KEY,
    FileName VARCHAR(255) NOT NULL,
    OriginalName VARCHAR(255),
    FilePath VARCHAR(500) NOT NULL,
    FileUrl VARCHAR(500) NOT NULL,
    FileType VARCHAR(50),
    FileSize BIGINT,
    MimeType VARCHAR(100),
    Width INT,
    Height INT,
    UploadedBy INT NOT NULL,
    AltText VARCHAR(255),
    Caption TEXT,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (UploadedBy) REFERENCES Users(UserId) ON DELETE CASCADE,
    INDEX idx_uploaded_by (UploadedBy),
    INDEX idx_file_type (FileType)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- 插入默認數據
-- ================================================

-- 默認分類
INSERT INTO Categories (Name, Slug, Description, Color, DisplayOrder) VALUES
('技術文章', 'tech', '技術相關的文章', '#3498db', 1),
('生活隨筆', 'life', '生活點滴記錄', '#2ecc71', 2),
('學習筆記', 'study', '學習心得分享', '#e74c3c', 3),
('專案分享', 'project', '專案開發記錄', '#f39c12', 4);

-- 默認標籤
INSERT INTO Tags (Name, Slug, Description, Color) VALUES
('Java', 'java', 'Java 程式語言', '#007396'),
('Spring Boot', 'spring-boot', 'Spring Boot 框架', '#6db33f'),
('前端開發', 'frontend', '前端技術', '#61dafb'),
('後端開發', 'backend', '後端技術', '#68a063'),
('數據庫', 'database', '數據庫相關', '#336791'),
('教程', 'tutorial', '教程文章', '#ff6b6b');

-- 默認管理員用戶（密碼: admin123）
INSERT INTO Users (Username, Email, PasswordHash, DisplayName, Role, IsActive) VALUES
('admin', 'admin@example.com', '$2a$10$rQ0qX9qH7pRGQJJc6zYxPeZVvJGX8DJp5KqvK5qxH7pRGQJJc6zYxPe', '管理員', 'ADMIN', TRUE);

-- ================================================
-- 完成
-- ================================================
SELECT '數據庫創建完成！' AS Message;

