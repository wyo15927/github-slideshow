package com.blog.repository;

import com.blog.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * 使用者資料存取介面
 */
@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    
    /**
     * 根據使用者名稱查找使用者
     */
    Optional<User> findByUsername(String username);
    
    /**
     * 根據電子郵件查找使用者
     */
    Optional<User> findByEmail(String email);
    
    /**
     * 檢查使用者名稱是否存在
     */
    boolean existsByUsername(String username);
    
    /**
     * 檢查電子郵件是否存在
     */
    boolean existsByEmail(String email);
    
    /**
     * 根據角色查找使用者
     */
    Page<User> findByRole(String role, Pageable pageable);
    
    /**
     * 根據啟用狀態查找使用者
     */
    Page<User> findByIsActive(Boolean isActive, Pageable pageable);
    
    /**
     * 根據使用者名稱或電子郵件搜尋使用者
     */
    @Query("SELECT u FROM User u WHERE " +
           "(:keyword IS NULL OR " +
           "u.username LIKE CONCAT('%', :keyword, '%') OR " +
           "u.email LIKE CONCAT('%', :keyword, '%') OR " +
           "u.displayName LIKE CONCAT('%', :keyword, '%'))")
    Page<User> searchUsers(@Param("keyword") String keyword, Pageable pageable);
    
    /**
     * 根據角色和啟用狀態查找使用者
     */
    @Query("SELECT u FROM User u WHERE " +
           "(:role IS NULL OR u.role = :role) AND " +
           "(:isActive IS NULL OR u.isActive = :isActive)")
    Page<User> findByRoleAndIsActive(@Param("role") String role, 
                                   @Param("isActive") Boolean isActive, 
                                   Pageable pageable);
} 