package com.blog.dto.response;

import java.time.LocalDateTime;

/**
 * Comment Response DTO
 */
public class CommentResponse {
    
    private Integer commentId;
    private String content;
    private String status;
    private Integer likeCount;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    // Author information
    private UserResponse author;
    
    // Post information
    private Integer postId;
    private String postTitle;
    private String postSlug;
    
    // Parent comment information
    private Integer parentCommentId;
    
    // Constructor
    public CommentResponse() {}
    
    // Getter and Setter methods
    public Integer getCommentId() {
        return commentId;
    }
    
    public void setCommentId(Integer commentId) {
        this.commentId = commentId;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Integer getLikeCount() {
        return likeCount;
    }
    
    public void setLikeCount(Integer likeCount) {
        this.likeCount = likeCount;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public UserResponse getAuthor() {
        return author;
    }
    
    public void setAuthor(UserResponse author) {
        this.author = author;
    }
    
    public Integer getPostId() {
        return postId;
    }
    
    public void setPostId(Integer postId) {
        this.postId = postId;
    }
    
    public String getPostTitle() {
        return postTitle;
    }
    
    public void setPostTitle(String postTitle) {
        this.postTitle = postTitle;
    }
    
    public String getPostSlug() {
        return postSlug;
    }
    
    public void setPostSlug(String postSlug) {
        this.postSlug = postSlug;
    }
    
    public Integer getParentCommentId() {
        return parentCommentId;
    }
    
    public void setParentCommentId(Integer parentCommentId) {
        this.parentCommentId = parentCommentId;
    }
}
