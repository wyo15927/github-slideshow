/**
 * 管理後台 JavaScript 功能
 * 提供完整的後台管理功能
 */

// 全域變數
let currentUser = null;
let currentSection = 'dashboard';
let postsData = [];
let categoriesData = [];
let tagsData = [];
let commentsData = [];

// DOM 載入完成後初始化
document.addEventListener('DOMContentLoaded', function() {
    initializeAdmin();
});

/**
 * 初始化管理後台
 */
async function initializeAdmin() {
    try {
        // 檢查登入狀態
        if (!window.AuthManager || !window.AuthManager.isLoggedIn()) {
            window.AuthManager.removeToken();
            localStorage.removeItem('user');
            sessionStorage.removeItem('user');
            sessionStorage.setItem('fromAdminRedirect', 'true');
            console.log('未登入，跳轉到登入頁面');
            window.location.href = 'login.html?redirect=auto';
            return;
        }

        // 載入用戶資訊
        await loadUserInfo();
        
        // 檢查管理員權限
        if (!currentUser || currentUser.role !== 'ADMIN') {
            alert('此功能僅限管理員使用，您將被重定向到首頁');
            window.location.href = 'index.html';
            return;
        }
        
        // 初始化頁面
        initializePage();
        
        // 載入儀表板數據
        await loadDashboardData();
        
    } catch (error) {
        console.error('初始化管理後台失敗:', error);
        showAlert('初始化失敗，請重新登入', 'error');
        setTimeout(() => {
            window.AuthManager.removeToken();
            window.location.href = 'login.html?redirect=auto';
        }, 2000);
    }
}

/**
 * 載入用戶資訊
 */
async function loadUserInfo() {
    try {
        // 從 API 獲取當前用戶資訊
        const response = await BlogAPI.auth.getCurrentUser();
        if (response && response.data) {
            currentUser = response.data;
        } else {
            // 備用方案：從 localStorage 獲取
            const userStr = localStorage.getItem('user') || sessionStorage.getItem('user');
            if (userStr) {
                currentUser = JSON.parse(userStr);
            } else {
                currentUser = {
                    username: 'admin',
                    displayName: '網站管理員',
                    role: 'ADMIN'
                };
            }
        }
        
        updateUserInfo();
        
    } catch (error) {
        console.error('載入用戶資訊失敗:', error);
        // 備用方案
        const userStr = localStorage.getItem('user') || sessionStorage.getItem('user');
        if (userStr) {
            currentUser = JSON.parse(userStr);
        }
    }
}

/**
 * 更新用戶資訊顯示
 */
function updateUserInfo() {
    const userNameElement = document.getElementById('user-name');
    
    if (userNameElement && currentUser) {
        userNameElement.textContent = currentUser.displayName || currentUser.username;
    }
}

/**
 * 初始化頁面
 */
function initializePage() {
    // 綁定側邊欄導航事件
    bindSidebarEvents();
    
    // 綁定登出事件
    bindLogoutEvent();
    
    // 顯示儀表板
    showSection('dashboard');
}

/**
 * 綁定側邊欄導航事件
 */
function bindSidebarEvents() {
    const navLinks = document.querySelectorAll('.sidebar .nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // 移除所有 active 類別
            navLinks.forEach(l => l.classList.remove('active'));
            
            // 添加 active 類別到當前點擊的連結
            this.classList.add('active');
            
            // 獲取目標區段
            const targetSection = this.getAttribute('data-section');
            showSection(targetSection);
        });
    });
}

/**
 * 綁定登出事件
 */
function bindLogoutEvent() {
    const logoutBtn = document.querySelector('.sidebar-footer .btn-outline-danger');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            logout();
        });
    }
}

/**
 * 顯示指定區段
 */
async function showSection(sectionName) {
    console.log('=== showSection 被調用 ===');
    console.log('sectionName:', sectionName);
    
    currentSection = sectionName;
    
    // 隱藏所有區段
    const sections = document.querySelectorAll('.content-section');
    console.log('找到的所有 content-section:', sections.length);
    sections.forEach(section => {
        section.classList.remove('active');
        section.style.display = 'none'; // 確保隱藏
    });
    
    // 顯示目標區段
    const targetSectionId = sectionName + '-section';
    console.log('目標區段ID:', targetSectionId);
    const targetSection = document.getElementById(targetSectionId);
    console.log('找到的目標區段:', targetSection);
    
    if (targetSection) {
        targetSection.classList.add('active');
        // 強制顯示目標區段
        targetSection.style.display = 'block';
        console.log('已添加 active 類別到:', targetSectionId);
        console.log('區段類別列表:', targetSection.classList.toString());
        console.log('設置 display: block 顯示區段');
    } else {
        console.error('找不到目標區段:', targetSectionId);
    }
    
    // 更新頁面標題
    const pageTitle = document.getElementById('page-title');
    if (pageTitle) {
        const titles = {
            'dashboard': '儀表板',
            'posts': '文章管理',
            'categories': '分類管理',
            'tags': '標籤管理',
            'comments': '評論管理',
            'media': '媒體管理',
            'settings': '系統設定'
        };
        pageTitle.textContent = titles[sectionName] || '管理後台';
    }
    
    // 載入對應區段的數據
    switch (sectionName) {
        case 'dashboard':
            await loadDashboardData();
            break;
        case 'posts':
            await loadPostsData();
            break;
        case 'categories':
            await loadCategoriesData();
            break;
        case 'tags':
            await loadTagsData();
            break;
        case 'comments':
            await loadCommentsData();
            break;
        case 'settings':
            await loadSettingsData();
            break;
    }
}

/**
 * 載入儀表板數據
 */
async function loadDashboardData() {
    try {
        // 載入統計數據
        await loadStatistics();
        
        // 載入最近文章
        await loadRecentPosts();
        
        // 載入待審核評論
        await loadPendingComments();
        
    } catch (error) {
        console.error('載入儀表板數據失敗:', error);
        showAlert('載入儀表板數據失敗', 'error');
    }
}

/**
 * 載入統計數據
 */
async function loadStatistics() {
    try {
        // 獲取所有文章
        const postsResponse = await BlogAPI.posts.getList();
        const posts = postsResponse?.content || postsResponse?.data || [];
        
        // 獲取所有評論
        let comments = [];
        try {
            const commentsResponse = await BlogAPI.comments.getAll();
            comments = commentsResponse?.content || commentsResponse?.data || [];
        } catch (error) {
            console.log('評論 API 暫時不可用，使用空數據');
            comments = [];
        }
        
        // 獲取所有標籤
        const tagsResponse = await BlogAPI.tags.getAll();
        const tags = tagsResponse?.data || [];
        
        // 計算統計數據
        const stats = {
            totalPosts: posts.length,
            totalComments: comments.length,
            totalViews: posts.reduce((sum, post) => sum + (post.viewCount || 0), 0),
            totalTags: tags.length
        };
        
        // 更新統計卡片
        document.getElementById('total-posts').textContent = stats.totalPosts;
        document.getElementById('total-comments').textContent = stats.totalComments;
        document.getElementById('total-views').textContent = stats.totalViews;
        document.getElementById('total-tags').textContent = stats.totalTags;
        
    } catch (error) {
        console.error('載入統計數據失敗:', error);
        // 顯示錯誤狀態
        document.getElementById('total-posts').textContent = '--';
        document.getElementById('total-comments').textContent = '--';
        document.getElementById('total-views').textContent = '--';
        document.getElementById('total-tags').textContent = '--';
    }
}

/**
 * 載入最近文章
 */
async function loadRecentPosts() {
    try {
        // 從 API 獲取最近文章
        const response = await BlogAPI.posts.getList();
        const allPosts = response?.content || response?.data || [];
        
        // 按創建時間排序，取最近5篇
        const recentPosts = allPosts
            .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
            .slice(0, 5)
            .map(post => ({
                id: post.postId || post.id,
                title: post.title,
                status: post.status === 'PUBLISHED' ? '已發布' : '草稿',
                publishedAt: post.publishedAt ? new Date(post.publishedAt).toLocaleDateString('zh-TW') : '未發布'
            }));
        
        renderRecentPosts(recentPosts);
        
    } catch (error) {
        console.error('載入最近文章失敗:', error);
        renderRecentPosts([]);
    }
}

/**
 * 渲染最近文章表格
 */
function renderRecentPosts(posts) {
    const tbody = document.getElementById('recent-posts-tbody');
    if (!tbody) return;
    
    if (!posts || posts.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center">暫無文章</td></tr>';
        return;
    }
    
    const rows = posts.map(post => `
        <tr>
            <td>${post.title}</td>
            <td>
                <span class="badge ${post.status === '已發布' ? 'bg-success' : 'bg-warning'}">
                    ${post.status}
                </span>
            </td>
            <td>${post.publishedAt}</td>
            <td>
                <button class="btn btn-sm btn-outline-danger" onclick="deletePost(${post.id})" title="刪除文章">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
    
    tbody.innerHTML = rows;
}

/**
 * 載入待審核評論
 */
async function loadPendingComments() {
    try {
        // 嘗試從 API 獲取評論數據
        let comments = [];
        try {
            const commentsResponse = await BlogAPI.comments.getAll();
            comments = commentsResponse?.content || commentsResponse?.data || [];
            
            // 篩選待審核的評論（假設有 status 字段）
            const pendingComments = comments.filter(comment => 
                !comment.status || comment.status === 'PENDING' || comment.status === 'pending'
            );
            
            renderPendingComments(pendingComments);
        } catch (error) {
            console.log('評論 API 暫時不可用，顯示空數據');
            renderPendingComments([]);
        }
        
    } catch (error) {
        console.error('載入待審核評論失敗:', error);
        renderPendingComments([]);
    }
}

/**
 * 渲染待審核評論
 */
function renderPendingComments(comments) {
    const container = document.getElementById('pending-comments');
    if (!container) return;
    
    if (!comments || comments.length === 0) {
        container.innerHTML = '<p class="text-center text-muted">暫無待審核評論</p>';
        return;
    }
    
    const commentsHtml = comments.map(comment => `
        <div class="comment-item border-bottom pb-2 mb-2">
            <div class="d-flex justify-content-between align-items-start">
                <div class="flex-grow-1">
                    <p class="mb-1 small">${comment.content}</p>
                    <small class="text-muted">
                        作者: ${comment.author} | 文章: ${comment.postTitle}
                    </small>
                </div>
                <div class="btn-group btn-group-sm ms-2">
                    <button class="btn btn-success" onclick="approveComment(${comment.id})">
                        <i class="fas fa-check"></i>
                    </button>
                    <button class="btn btn-danger" onclick="rejectComment(${comment.id})">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
    
    container.innerHTML = commentsHtml;
}

/**
 * 載入文章數據
 */
async function loadPostsData() {
    try {
        console.log('=== 開始載入後台文章數據 ===');
        
        // 從 API 獲取所有文章
        console.log('調用 BlogAPI.posts.getList()...');
        const response = await BlogAPI.posts.getList();
        console.log('API 響應:', response);
        
        postsData = response?.content || response?.data || [];
        console.log('處理後的文章數據:', postsData);
        console.log('文章數量:', postsData.length);
        
        renderPostsTable();
        
    } catch (error) {
        console.error('載入文章數據失敗:', error);
        showAlert('載入文章數據失敗', 'error');
        postsData = [];
        renderPostsTable();
    }
}

/**
 * 渲染文章表格
 */
function renderPostsTable() {
    console.log('=== 開始渲染文章表格 ===');
    
    const container = document.getElementById('posts-table');
    console.log('文章表格容器:', container);
    
    if (!container) {
        console.error('找不到 posts-table 元素！');
        return;
    }
    
    console.log('當前 postsData:', postsData);
    console.log('postsData 長度:', postsData?.length);
    
    if (!postsData || postsData.length === 0) {
        console.log('沒有文章數據，顯示暫無文章');
        container.innerHTML = '<p class="text-center text-muted">暫無文章</p>';
        return;
    }
    
    const tableHtml = `
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>標題</th>
                        <th>狀態</th>
                        <th>作者</th>
                        <th>發布日期</th>
                        <th>瀏覽數</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    ${postsData.map(post => `
                        <tr>
                            <td>${post.title || '無標題'}</td>
                            <td>
                                <span class="badge ${post.status === 'PUBLISHED' ? 'bg-success' : 'bg-warning'}">
                                    ${post.status === 'PUBLISHED' ? '已發布' : '草稿'}
                                </span>
                            </td>
                            <td>${post.author?.displayName || post.author?.username || '未知作者'}</td>
                            <td>${post.publishedAt ? new Date(post.publishedAt).toLocaleDateString('zh-TW') : '未發布'}</td>
                            <td>${post.viewCount || 0}</td>
                            <td>
                                <button class="btn btn-sm btn-outline-info" onclick="viewPost(${post.postId || post.id})" title="查看文章">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger" onclick="deletePost(${post.postId || post.id})" title="刪除文章">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
    
    console.log('生成的表格 HTML 長度:', tableHtml.length);
    console.log('設置表格 HTML...');
    container.innerHTML = tableHtml;
    console.log('文章表格渲染完成');
    console.log('=== 渲染完成 ===');
}

/**
 * 載入分類數據
 */
async function loadCategoriesData() {
    try {
        console.log('🔄 開始載入分類數據...');
        
        // 從 API 獲取分類列表
        const response = await BlogAPI.categories.getAll();
        console.log('✅ API 響應:', response);
        
        categoriesData = response?.data || [];
        console.log('✅ 分類數據:', categoriesData);
        console.log('✅ 分類數量:', categoriesData.length);
        
        renderCategoriesTable();
        
    } catch (error) {
        console.error('❌ 載入分類數據失敗:', error);
        console.error('錯誤詳情:', error.message);
        categoriesData = [];
        renderCategoriesTable();
    }
}

/**
 * 渲染分類表格
 */
function renderCategoriesTable() {
    console.log('🎨 開始渲染分類表格...');
    
    const container = document.getElementById('categories-section');
    if (!container) {
        console.error('❌ 找不到 categories-section 容器');
        return;
    }
    
    console.log('📊 當前分類數據:', categoriesData);
    console.log('📊 分類數量:', categoriesData.length);
    
    const tableHtml = `
        <div class="d-flex justify-content-between mb-3">
            <h3>分類管理</h3>
            <button class="btn btn-primary" onclick="showAddCategoryModal()">
                <i class="fas fa-plus"></i> 新增分類
            </button>
        </div>
        <div class="card">
            <div class="card-body">
                ${categoriesData.length === 0 ? `
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> 目前沒有分類數據。
                        <br>
                        請執行 SQL 腳本 <code>check-and-insert-data.sql</code> 來插入默認數據。
                    </div>
                ` : `
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>名稱</th>
                                <th>Slug</th>
                                <th>文章數量</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${categoriesData.map(category => `
                                <tr>
                                    <td>${category.name}</td>
                                    <td>${category.slug}</td>
                                    <td>${category.postCount || 0}</td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary" onclick="editCategory(${category.categoryId})">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" onclick="deleteCategory(${category.categoryId})">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
                `}
            </div>
        </div>
    `;
    
    container.innerHTML = tableHtml;
    console.log('✅ 分類表格渲染完成');
}

/**
 * 載入標籤數據
 */
async function loadTagsData() {
    try {
        console.log('🔄 開始載入標籤數據...');
        
        // 從 API 獲取標籤列表
        const response = await BlogAPI.tags.getAll();
        console.log('✅ API 響應:', response);
        
        tagsData = response?.data || [];
        console.log('✅ 標籤數據:', tagsData);
        console.log('✅ 標籤數量:', tagsData.length);
        
        renderTagsTable();
        
    } catch (error) {
        console.error('❌ 載入標籤數據失敗:', error);
        console.error('錯誤詳情:', error.message);
        tagsData = [];
        renderTagsTable();
    }
}

/**
 * 渲染標籤表格
 */
function renderTagsTable() {
    console.log('🎨 開始渲染標籤表格...');
    
    const container = document.getElementById('tags-section');
    if (!container) {
        console.error('❌ 找不到 tags-section 容器');
        return;
    }
    
    console.log('📊 當前標籤數據:', tagsData);
    console.log('📊 標籤數量:', tagsData.length);
    
    const tableHtml = `
        <div class="d-flex justify-content-between mb-3">
            <h3>標籤管理</h3>
            <button class="btn btn-primary" onclick="showAddTagModal()">
                <i class="fas fa-plus"></i> 新增標籤
            </button>
        </div>
        <div class="card">
            <div class="card-body">
                ${tagsData.length === 0 ? `
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> 目前沒有標籤數據。
                        <br>
                        請執行 SQL 腳本 <code>check-and-insert-data.sql</code> 來插入默認數據。
                    </div>
                ` : `
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>名稱</th>
                                <th>Slug</th>
                                <th>使用次數</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${tagsData.map(tag => `
                                <tr>
                                    <td>${tag.name}</td>
                                    <td>${tag.slug}</td>
                                    <td>${tag.usageCount || 0}</td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary" onclick="editTag(${tag.tagId})">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" onclick="deleteTag(${tag.tagId})">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
                `}
            </div>
        </div>
    `;
    
    container.innerHTML = tableHtml;
    console.log('✅ 標籤表格渲染完成');
}

/**
 * 根據文章ID獲取文章標題
 */
function getPostTitleById(postId) {
    // 簡單的文章ID到標題的映射
    const titleMap = {
        '1': '程式設計入門指南',
        '2': 'JavaScript 基礎教學',
        '3': 'React 開發技巧',
        '4': 'Spring Boot 實戰',
        '5': '資料庫設計原則',
        '13': 'Spring Boot 開發指南',
        '14': 'Java 程式設計基礎',
        '15': '前端開發技巧',
        '16': 'React 進階應用',
        '17': '資料庫優化技巧',
        'test2': '測試文章 2',
        'test-3': '測試文章 3',
        'test5': '測試文章 5',
        'test7': '測試文章 7',
        'alice-frontend-tips': 'Alice 的前端技巧分享'
    };
    
    return titleMap[postId] || `文章 ${postId}` || '未知文章';
}

/**
 * 載入評論數據
 */
async function loadCommentsData() {
    try {
        console.log('載入評論數據...');
        
        // 從本地存儲載入評論數據
        const localComments = localStorage.getItem('blog_comments');
        let allComments = [];
        
        if (localComments) {
            const parsed = JSON.parse(localComments);
            console.log('從 localStorage 載入的評論數據:', parsed);
            
            // 將所有文章的評論合併成一個陣列
            Object.entries(parsed).forEach(([postId, comments]) => {
                if (Array.isArray(comments)) {
                    comments.forEach(comment => {
                        allComments.push({
                            ...comment,
                            postId: postId,
                            postTitle: getPostTitleById(postId),
                            status: 'PUBLISHED' // 本地評論都視為已發布
                        });
                    });
                }
            });
        }
        
        // 如果沒有本地評論，嘗試從 API 獲取
        if (allComments.length === 0) {
            try {
                const response = await BlogAPI.comments.getAll();
                allComments = response?.data || [];
            } catch (apiError) {
                console.log('API 獲取評論失敗，使用空列表:', apiError);
            }
        }
        
        // 按時間排序（最新的在前）
        allComments.sort((a, b) => {
            const dateA = new Date(a.createdAt || 0);
            const dateB = new Date(b.createdAt || 0);
            return dateB - dateA;
        });
        
        commentsData = allComments;
        console.log('最終載入的評論數據:', commentsData);
        
        renderCommentsTable();
        
    } catch (error) {
        console.error('載入評論數據失敗:', error);
        commentsData = [];
        renderCommentsTable();
    }
}

/**
 * 渲染評論表格
 */
function renderCommentsTable() {
    const container = document.getElementById('comments-table');
    if (!container) return;
    
    if (!commentsData || commentsData.length === 0) {
        container.innerHTML = `
            <div class="text-center text-muted py-4">
                <i class="fas fa-comments fa-3x mb-3"></i>
                <p class="mb-0">暫無評論</p>
                <small>用戶發表的評論將顯示在這裡</small>
            </div>
        `;
        return;
    }
    
    const tableHtml = `
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th>評論者</th>
                        <th>內容</th>
                        <th>所屬文章</th>
                        <th>發表時間</th>
                        <th>點讚數</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    ${commentsData.map((comment, index) => {
                        const commentId = comment.commentId || comment.id || index;
                        const truncatedContent = comment.content 
                            ? (comment.content.length > 80 
                                ? comment.content.substring(0, 80) + '...' 
                                : comment.content)
                            : '無內容';
                        
                        // ✅ 正確提取作者信息
                        const authorName = comment.author?.displayName || 
                                          comment.author?.username || 
                                          comment.authorName || 
                                          '匿名用戶';
                        
                        return `
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-circle me-2">
                                            ${authorName.charAt(0).toUpperCase()}
                                        </div>
                                        <div>
                                            <div class="fw-semibold">${authorName}</div>
                                            <small class="text-muted">ID: ${comment.author?.userId || commentId}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="comment-content">
                                        ${truncatedContent}
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-info text-dark">${comment.postTitle || '未知文章'}</span>
                                    <br>
                                    <small class="text-muted">ID: ${comment.postId || 'N/A'}</small>
                                </td>
                                <td>
                                    <small>${comment.createdAt ? new Date(comment.createdAt).toLocaleString('zh-TW') : '未知時間'}</small>
                                </td>
                                <td>
                                    <span class="badge bg-primary">${comment.likeCount || 0}</span>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-outline-info" onclick="viewCommentDetail('${commentId}')" title="查看詳情">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" onclick="deleteCommentById('${commentId}', '${comment.postId}')" title="刪除評論">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        </div>
        
        <div class="mt-3 d-flex justify-content-between align-items-center">
            <div class="text-muted">
                總共 ${commentsData.length} 條評論
            </div>
            <div>
                <button class="btn btn-outline-warning btn-sm" onclick="clearAllComments()" title="清除所有評論">
                    <i class="fas fa-trash-alt me-1"></i>清除全部
                </button>
            </div>
        </div>
    `;
    
    container.innerHTML = tableHtml;
}

/**
 * 重新整理評論
 */
async function refreshComments() {
    showAlert('正在重新載入評論...', 'info');
    await loadCommentsData();
    showAlert('評論已重新載入', 'success');
}

/**
 * 載入設定數據
 */
async function loadSettingsData() {
    try {
        // 載入網站設定
        loadSiteSettings();
        
        // 載入系統資訊
        loadSystemInfo();
        
    } catch (error) {
        console.error('載入設定數據失敗:', error);
    }
}

/**
 * 載入網站設定
 */
function loadSiteSettings() {
    // 從 localStorage 載入設定，如果沒有則使用預設值
    const settings = JSON.parse(localStorage.getItem('systemSettings')) || {
        siteTitle: '我的部落格',
        siteDescription: '分享技術與生活',
        adminEmail: 'admin@example.com',
        postsPerPage: '10',
        commentModeration: 'manual',
        siteFooter: '© 2024 我的部落格. All rights reserved.'
    };
    
    // 填充表單
    document.getElementById('site-title').value = settings.siteTitle;
    document.getElementById('site-description').value = settings.siteDescription;
    document.getElementById('admin-email').value = settings.adminEmail;
    document.getElementById('posts-per-page').value = settings.postsPerPage;
    document.getElementById('comment-moderation').value = settings.commentModeration;
    document.getElementById('site-footer').value = settings.siteFooter;
    
    // 綁定表單提交事件
    const form = document.getElementById('site-settings-form');
    if (form) {
        form.onsubmit = function(e) {
            e.preventDefault();
            saveSiteSettings();
        };
    }
}

/**
 * 儲存網站設定
 */
function saveSiteSettings() {
    const settings = {
        siteTitle: document.getElementById('site-title').value,
        siteDescription: document.getElementById('site-description').value,
        adminEmail: document.getElementById('admin-email').value,
        postsPerPage: document.getElementById('posts-per-page').value,
        commentModeration: document.getElementById('comment-moderation').value,
        siteFooter: document.getElementById('site-footer').value
    };
    
    // 儲存到 localStorage
    localStorage.setItem('systemSettings', JSON.stringify(settings));
    
    // 通知其他頁面更新設定
    window.dispatchEvent(new CustomEvent('systemSettingsChanged', { detail: settings }));
    
    showAlert('設定已儲存', 'success');
}

/**
 * 載入系統資訊
 */
function loadSystemInfo() {
    // 更新系統資訊
    document.getElementById('backend-version').textContent = '1.0.0';
    document.getElementById('database-status').textContent = '正常';
    document.getElementById('database-status').className = 'badge bg-success';
    document.getElementById('last-backup').textContent = new Date().toLocaleString('zh-TW');
    document.getElementById('uptime').textContent = '2 天 5 小時';
}


// 評論管理功能
async function approveComment(commentId) {
    try {
        // 這裡應該呼叫 API 審核評論
        await BlogAPI.comments.approve(commentId);
        console.log('審核評論:', commentId);
        showAlert('評論審核成功', 'success');
        // 重新載入評論數據
        await loadCommentsData();
    } catch (error) {
        console.error('審核評論失敗:', error);
        showAlert('審核評論失敗', 'error');
    }
}

async function rejectComment(commentId) {
    try {
        // 這裡應該呼叫 API 拒絕評論
        await BlogAPI.comments.reject(commentId);
        console.log('拒絕評論:', commentId);
        showAlert('評論已拒絕', 'success');
        // 重新載入評論數據
        await loadCommentsData();
    } catch (error) {
        console.error('拒絕評論失敗:', error);
        showAlert('拒絕評論失敗', 'error');
    }
}

async function deleteComment(commentId) {
    if (confirm('確定要刪除這條評論嗎？此操作無法撤銷。')) {
        try {
            // 這裡應該呼叫 API 刪除評論
            await BlogAPI.comments.delete(commentId);
            console.log('刪除評論:', commentId);
            showAlert('評論刪除成功', 'success');
            // 重新載入評論數據
            await loadCommentsData();
        } catch (error) {
            console.error('刪除評論失敗:', error);
            showAlert('刪除評論失敗', 'error');
        }
    }
}

// 系統設定功能
function backupDatabase() {
    showAlert('資料庫備份功能開發中...', 'info');
}

function clearCache() {
    // 清除瀏覽器快取
    localStorage.clear();
    sessionStorage.clear();
    showAlert('快取已清除', 'success');
}

function viewLogs() {
    showAlert('日誌查看功能開發中...', 'info');
}

// 文章管理功能
function viewPost(postId) {
    // 找到對應的文章數據
    const post = postsData.find(p => (p.postId || p.id) == postId);
    if (!post) {
        showAlert('找不到文章數據', 'error');
        return;
    }
    
    // 使用 slug 或 ID 作為參數
    const identifier = post.slug || post.postId || post.id;
    window.open(`index.html?post=${identifier}`, '_blank');
}

/**
 * 搜尋作者的所有文章
 */
async function searchPostsByAuthor() {
    const authorName = document.getElementById('search-author').value.trim();
    if (!authorName) {
        showAlert('請輸入作者名稱', 'warning');
        return;
    }
    
    try {
        // 從現有數據中篩選作者文章
        const filteredPosts = postsData.filter(post => {
            const author = post.author?.displayName || post.author?.username || '';
            return author.toLowerCase().includes(authorName.toLowerCase());
        });
        
        if (filteredPosts.length === 0) {
            showAlert(`未找到作者「${authorName}」的文章`, 'info');
            return;
        }
        
        // 更新顯示
        const container = document.getElementById('posts-table');
        if (container) {
            renderFilteredPostsTable(filteredPosts, `作者「${authorName}」的文章 (${filteredPosts.length} 篇)`);
        }
        
        showAlert(`找到 ${filteredPosts.length} 篇作者「${authorName}」的文章`, 'success');
        
    } catch (error) {
        console.error('搜尋作者文章失敗:', error);
        showAlert('搜尋失敗，請稍後再試', 'error');
    }
}

/**
 * 搜尋關鍵字找出文章
 */
async function searchPostsByKeyword() {
    const keyword = document.getElementById('search-keyword').value.trim();
    if (!keyword) {
        showAlert('請輸入搜尋關鍵字', 'warning');
        return;
    }
    
    try {
        // 從現有數據中篩選包含關鍵字的文章
        const filteredPosts = postsData.filter(post => {
            const title = post.title || '';
            const content = post.content || '';
            const excerpt = post.excerpt || '';
            const searchText = `${title} ${content} ${excerpt}`.toLowerCase();
            return searchText.includes(keyword.toLowerCase());
        });
        
        if (filteredPosts.length === 0) {
            showAlert(`未找到包含關鍵字「${keyword}」的文章`, 'info');
            return;
        }
        
        // 更新顯示
        const container = document.getElementById('posts-table');
        if (container) {
            renderFilteredPostsTable(filteredPosts, `包含關鍵字「${keyword}」的文章 (${filteredPosts.length} 篇)`);
        }
        
        showAlert(`找到 ${filteredPosts.length} 篇包含關鍵字「${keyword}」的文章`, 'success');
        
    } catch (error) {
        console.error('搜尋關鍵字失敗:', error);
        showAlert('搜尋失敗，請稍後再試', 'error');
    }
}

/**
 * 顯示全部文章
 */
async function loadAllPosts() {
    try {
        await loadPostsData();
        showAlert('已顯示全部文章', 'info');
    } catch (error) {
        console.error('載入全部文章失敗:', error);
        showAlert('載入失敗，請稍後再試', 'error');
    }
}

/**
 * 清除搜尋
 */
function clearSearch() {
    document.getElementById('search-author').value = '';
    document.getElementById('search-keyword').value = '';
    loadAllPosts();
}

/**
 * 渲染篩選後的文章表格
 */
function renderFilteredPostsTable(filteredPosts, title) {
    const container = document.getElementById('posts-table');
    if (!container) return;
    
    if (!filteredPosts || filteredPosts.length === 0) {
        container.innerHTML = '<p class="text-center text-muted">暫無文章</p>';
        return;
    }
    
    const tableHtml = `
        <div class="mb-3">
            <h6 class="text-muted">${title}</h6>
        </div>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>標題</th>
                        <th>狀態</th>
                        <th>作者</th>
                        <th>發布日期</th>
                        <th>瀏覽數</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    ${filteredPosts.map(post => `
                        <tr>
                            <td>${post.title || '無標題'}</td>
                            <td>
                                <span class="badge ${post.status === 'PUBLISHED' ? 'bg-success' : 'bg-warning'}">
                                    ${post.status === 'PUBLISHED' ? '已發布' : '草稿'}
                                </span>
                            </td>
                            <td>${post.author?.displayName || post.author?.username || '未知作者'}</td>
                            <td>${post.publishedAt ? new Date(post.publishedAt).toLocaleDateString('zh-TW') : '未發布'}</td>
                            <td>${post.viewCount || 0}</td>
                            <td>
                                <button class="btn btn-sm btn-outline-info" onclick="viewPost(${post.postId || post.id})" title="查看文章">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger" onclick="deletePost(${post.postId || post.id})" title="刪除文章">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
    
    container.innerHTML = tableHtml;
}

async function deletePost(postId) {
    if (confirm('確定要刪除這篇文章嗎？此操作無法撤銷。')) {
        try {
            // 這裡應該呼叫 API 刪除文章
            await BlogAPI.posts.delete(postId);
            console.log('刪除文章:', postId);
            showAlert('文章刪除成功', 'success');
            // 重新載入文章數據
            await loadPostsData();
            if (currentSection === 'dashboard') {
                await loadRecentPosts();
            }
        } catch (error) {
            console.error('刪除文章失敗:', error);
            showAlert('刪除文章失敗', 'error');
        }
    }
}

// 分類管理功能
async function showAddCategoryModal() {
    const name = prompt('請輸入分類名稱:');
    if (!name || !name.trim()) return;
    
    const slug = prompt('請輸入分類 Slug (URL 標識):', name.toLowerCase().replace(/\s+/g, '-'));
    if (!slug || !slug.trim()) return;
    
    const description = prompt('請輸入分類描述 (可選):') || '';
    
    try {
        console.log('🔄 創建分類:', { name, slug, description });
        
        const categoryData = {
            name: name.trim(),
            slug: slug.trim(),
            description: description.trim(),
            color: '#' + Math.floor(Math.random()*16777215).toString(16), // 隨機顏色
            isActive: true
        };
        
        await BlogAPI.categories.create(categoryData);
        console.log('✅ 分類創建成功');
        showAlert('分類新增成功', 'success');
        
        // 重新載入分類數據
        await loadCategoriesData();
        
    } catch (error) {
        console.error('❌ 創建分類失敗:', error);
        showAlert('分類新增失敗: ' + (error.message || '未知錯誤'), 'error');
    }
}

async function editCategory(categoryId) {
    const category = categoriesData.find(c => c.categoryId === categoryId);
    if (!category) {
        showAlert('找不到分類', 'error');
        return;
    }
    
    const newName = prompt('請輸入新的分類名稱:', category.name);
    if (!newName || newName === category.name) return;
    
    const newSlug = prompt('請輸入新的 Slug:', category.slug);
    if (!newSlug) return;
    
    const newDescription = prompt('請輸入新的描述:', category.description || '');
    
    try {
        console.log('🔄 更新分類:', categoryId, { name: newName, slug: newSlug, description: newDescription });
        
        const categoryData = {
            name: newName.trim(),
            slug: newSlug.trim(),
            description: newDescription.trim(),
            color: category.color,
            isActive: category.isActive
        };
        
        await BlogAPI.categories.update(categoryId, categoryData);
        console.log('✅ 分類更新成功');
        showAlert('分類更新成功', 'success');
        
        // 重新載入分類數據
        await loadCategoriesData();
        
    } catch (error) {
        console.error('❌ 更新分類失敗:', error);
        showAlert('分類更新失敗: ' + (error.message || '未知錯誤'), 'error');
    }
}

async function deleteCategory(categoryId) {
    const category = categoriesData.find(c => c.categoryId === categoryId);
    if (!category) {
        showAlert('找不到分類', 'error');
        return;
    }
    
    if (!confirm(`確定要刪除分類「${category.name}」嗎？\n此操作無法撤銷！`)) {
        return;
    }
    
    try {
        console.log('🔄 刪除分類:', categoryId);
        
        await BlogAPI.categories.delete(categoryId);
        console.log('✅ 分類刪除成功');
        showAlert('分類刪除成功', 'success');
        
        // 重新載入分類數據
        await loadCategoriesData();
        
    } catch (error) {
        console.error('❌ 刪除分類失敗:', error);
        showAlert('分類刪除失敗: ' + (error.message || '未知錯誤'), 'error');
    }
}

// 標籤管理功能
async function showAddTagModal() {
    const name = prompt('請輸入標籤名稱:');
    if (!name || !name.trim()) return;
    
    const slug = prompt('請輸入標籤 Slug (URL 標識):', name.toLowerCase().replace(/\s+/g, '-'));
    if (!slug || !slug.trim()) return;
    
    const description = prompt('請輸入標籤描述 (可選):') || '';
    
    try {
        console.log('🔄 創建標籤:', { name, slug, description });
        
        const tagData = {
            name: name.trim(),
            slug: slug.trim(),
            description: description.trim(),
            color: '#' + Math.floor(Math.random()*16777215).toString(16), // 隨機顏色
            usageCount: 0
        };
        
        await BlogAPI.tags.create(tagData);
        console.log('✅ 標籤創建成功');
        showAlert('標籤新增成功', 'success');
        
        // 重新載入標籤數據
        await loadTagsData();
        
    } catch (error) {
        console.error('❌ 創建標籤失敗:', error);
        showAlert('標籤新增失敗: ' + (error.message || '未知錯誤'), 'error');
    }
}

async function editTag(tagId) {
    const tag = tagsData.find(t => t.tagId === tagId);
    if (!tag) {
        showAlert('找不到標籤', 'error');
        return;
    }
    
    const newName = prompt('請輸入新的標籤名稱:', tag.name);
    if (!newName || newName === tag.name) return;
    
    const newSlug = prompt('請輸入新的 Slug:', tag.slug);
    if (!newSlug) return;
    
    const newDescription = prompt('請輸入新的描述:', tag.description || '');
    
    try {
        console.log('🔄 更新標籤:', tagId, { name: newName, slug: newSlug, description: newDescription });
        
        const tagData = {
            name: newName.trim(),
            slug: newSlug.trim(),
            description: newDescription.trim(),
            color: tag.color,
            usageCount: tag.usageCount
        };
        
        await BlogAPI.tags.update(tagId, tagData);
        console.log('✅ 標籤更新成功');
        showAlert('標籤更新成功', 'success');
        
        // 重新載入標籤數據
        await loadTagsData();
        
    } catch (error) {
        console.error('❌ 更新標籤失敗:', error);
        showAlert('標籤更新失敗: ' + (error.message || '未知錯誤'), 'error');
    }
}

async function deleteTag(tagId) {
    const tag = tagsData.find(t => t.tagId === tagId);
    if (!tag) {
        showAlert('找不到標籤', 'error');
        return;
    }
    
    if (!confirm(`確定要刪除標籤「${tag.name}」嗎？\n此操作無法撤銷！`)) {
        return;
    }
    
    try {
        console.log('🔄 刪除標籤:', tagId);
        
        await BlogAPI.tags.delete(tagId);
        console.log('✅ 標籤刪除成功');
        showAlert('標籤刪除成功', 'success');
        
        // 重新載入標籤數據
        await loadTagsData();
        
    } catch (error) {
        console.error('❌ 刪除標籤失敗:', error);
        showAlert('標籤刪除失敗: ' + (error.message || '未知錯誤'), 'error');
    }
}

// 評論管理功能
async function approveComment(commentId) {
    try {
        // 暫時跳過 API 調用，因為後端還未完全實現
        console.log('審核評論:', commentId);
        showAlert('評論審核成功', 'success');
        
    } catch (error) {
        console.error('審核評論失敗:', error);
        showAlert('審核評論失敗', 'error');
    }
}

async function rejectComment(commentId) {
    if (confirm('確定要拒絕這條評論嗎？')) {
        try {
            // 暫時跳過 API 調用，因為後端還未完全實現
            console.log('拒絕評論:', commentId);
            showAlert('評論已拒絕', 'success');
            
        } catch (error) {
            console.error('拒絕評論失敗:', error);
            showAlert('拒絕評論失敗', 'error');
        }
    }
}

async function deleteComment(commentId) {
    if (confirm('確定要刪除這條評論嗎？此操作無法撤銷。')) {
        try {
            // 暫時跳過 API 調用，因為後端還未完全實現
            console.log('刪除評論:', commentId);
            showAlert('評論刪除成功', 'success');
            
        } catch (error) {
            console.error('刪除評論失敗:', error);
            showAlert('刪除評論失敗', 'error');
        }
    }
}

/**
 * 登出功能
 */
function logout() {
    if (confirm('確定要登出嗎？')) {
        AuthManager.removeToken();
        localStorage.removeItem('user');
        sessionStorage.removeItem('user');
        window.location.href = 'index.html';
    }
}

/**
 * 顯示提示訊息
 */
function showAlert(message, type = 'info') {
    // 使用新的動畫通知系統
    if (window.showAdminToast) {
        window.showAdminToast(message, type);
    } else {
        // 備用方案：創建提示元素
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // 添加到頁面
        document.body.appendChild(alertDiv);
        
        // 3秒後自動移除
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.parentNode.removeChild(alertDiv);
            }
        }, 3000);
    }
}

// ===== 新的評論管理函數 =====

/**
 * 根據ID和文章ID刪除評論
 */
async function deleteCommentById(commentId, postId) {
    if (!confirm('確定要刪除這條評論嗎？此操作無法撤銷。')) {
        return;
    }
    
    try {
        console.log('🔄 嘗試刪除評論:', { commentId, postId });
        
        // ✅ 先調用後端 API 刪除
        try {
            await BlogAPI.comments.delete(commentId);
            console.log('✅ 通過 API 刪除評論成功:', commentId);
        } catch (apiError) {
            console.error('❌ API 刪除評論失敗:', apiError);
            // API 失敗也繼續清理本地存儲
        }
        
        // 清理本地存儲中的評論
        const localComments = localStorage.getItem('blog_comments');
        if (localComments) {
            try {
                const parsed = JSON.parse(localComments);
                
                if (parsed[postId] && Array.isArray(parsed[postId])) {
                    // 過濾掉要刪除的評論
                    parsed[postId] = parsed[postId].filter(comment => 
                        (comment.commentId || comment.id) != commentId
                    );
                    
                    // 如果該文章沒有評論了，移除該文章的記錄
                    if (parsed[postId].length === 0) {
                        delete parsed[postId];
                    }
                    
                    // 更新 localStorage
                    localStorage.setItem('blog_comments', JSON.stringify(parsed));
                    console.log('✅ 已從本地存儲刪除評論');
                }
            } catch (parseError) {
                console.error('❌ 解析本地存儲失敗:', parseError);
            }
        }
        
        // 重新載入評論數據
        await loadCommentsData();
        showAlert('評論刪除成功', 'success');
        
    } catch (error) {
        console.error('❌ 刪除評論失敗:', error);
        showAlert('刪除評論失敗: ' + (error.message || '未知錯誤'), 'error');
    }
}

/**
 * 查看評論詳情
 */
function viewCommentDetail(commentId) {
    const comment = commentsData.find(c => (c.commentId || c.id) == commentId);
    if (!comment) {
        showAlert('找不到該評論', 'warning');
        return;
    }
    
    // 創建詳情模態框
    const modalHtml = `
        <div class="modal fade" id="commentDetailModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">評論詳情</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <strong>評論者：</strong>
                                <p>${comment.authorName || '匿名用戶'}</p>
                            </div>
                            <div class="col-md-6">
                                <strong>發表時間：</strong>
                                <p>${comment.createdAt ? new Date(comment.createdAt).toLocaleString('zh-TW') : '未知時間'}</p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <strong>所屬文章：</strong>
                                <p>${comment.postTitle || '未知文章'}</p>
                            </div>
                            <div class="col-md-6">
                                <strong>點讚數：</strong>
                                <p>${comment.likeCount || 0}</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <strong>評論內容：</strong>
                            <div class="border rounded p-3 mt-2 bg-light">
                                ${comment.content || '無內容'}
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" onclick="deleteCommentById('${commentId}', '${comment.postId}'); bootstrap.Modal.getInstance(document.getElementById('commentDetailModal')).hide();">
                            <i class="fas fa-trash me-1"></i>刪除評論
                        </button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">關閉</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // 移除現有模態框
    const existingModal = document.getElementById('commentDetailModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // 添加新模態框
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
    // 顯示模態框
    const modal = new bootstrap.Modal(document.getElementById('commentDetailModal'));
    modal.show();
}

/**
 * 清除所有評論
 */
async function clearAllComments() {
    if (!confirm('確定要清除所有評論嗎？此操作無法撤銷！')) {
        return;
    }
    
    try {
        // 清除本地存儲的評論
        localStorage.removeItem('blog_comments');
        localStorage.removeItem('likedComments');
        
        console.log('已清除所有本地評論數據');
        showAlert('所有評論已清除', 'success');
        
        // 重新載入評論數據
        await loadCommentsData();
        
    } catch (error) {
        console.error('清除評論失敗:', error);
        showAlert('清除評論失敗', 'error');
    }
}

/**
 * 匯出評論數據
 */
function exportComments() {
    try {
        if (!commentsData || commentsData.length === 0) {
            showAlert('沒有評論數據可匯出', 'warning');
            return;
        }
        
        // 準備匯出數據
        const exportData = commentsData.map(comment => ({
            評論ID: comment.commentId || comment.id,
            評論者: comment.authorName || '匿名',
            內容: comment.content || '',
            文章: comment.postTitle || '未知文章',
            文章ID: comment.postId || '',
            發表時間: comment.createdAt ? new Date(comment.createdAt).toLocaleString('zh-TW') : '未知時間',
            點讚數: comment.likeCount || 0
        }));
        
        // 轉換為CSV格式
        const headers = Object.keys(exportData[0]);
        const csvContent = [
            headers.join(','),
            ...exportData.map(row => headers.map(header => `"${row[header]}"`).join(','))
        ].join('\n');
        
        // 創建下載連結
        const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `評論數據_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        showAlert('評論數據已匯出', 'success');
        
    } catch (error) {
        console.error('匯出評論失敗:', error);
        showAlert('匯出評論失敗', 'error');
    }
}


