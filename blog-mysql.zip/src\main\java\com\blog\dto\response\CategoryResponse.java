package com.blog.dto.response;

import java.time.LocalDateTime;

/**
 * 分類響應 DTO
 */
public class CategoryResponse {
    
    private Integer categoryId;
    private String name;
    private String description;
    private String slug;
    private String color;
    private Boolean isActive;
    private LocalDateTime createdAt;
    private Long postCount;
    
    public CategoryResponse() {}
    
    // Getters and Setters
    public Integer getCategoryId() {
        return categoryId;
    }
    
    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getSlug() {
        return slug;
    }
    
    public void setSlug(String slug) {
        this.slug = slug;
    }
    
    public String getColor() {
        return color;
    }
    
    public void setColor(String color) {
        this.color = color;
    }
    
    public Boolean getIsActive() {
        return isActive;
    }
    
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public Long getPostCount() {
        return postCount;
    }
    
    public void setPostCount(Long postCount) {
        this.postCount = postCount;
    }
} 