/**
 * 統一的頁面導航管理器
 * 提供上一頁、下一頁、頁面歷史管理功能
 */

class NavigationManager {
    constructor() {
        this.history = [];
        this.currentIndex = -1;
        this.maxHistory = 50; // 最多保存50個歷史記錄
        
        this.init();
    }
    
    init() {
        // 記錄當前頁面為第一個歷史記錄
        this.addToHistory(window.location.href, document.title);
        
        // 監聽瀏覽器後退/前進按鈕
        window.addEventListener('popstate', (event) => {
            this.handlePopState(event);
        });
        
        // 添加鍵盤快捷鍵支持
        document.addEventListener('keydown', (event) => {
            this.handleKeyDown(event);
        });
        
        // 監聽頁面點擊事件，自動記錄導航
        this.bindNavigationEvents();
        
        // 創建導航UI
        this.createNavigationUI();
        
        console.log('NavigationManager 初始化完成');
    }
    
    /**
     * 添加頁面到歷史記錄
     */
    addToHistory(url, title = '') {
        const historyItem = {
            url: url,
            title: title || document.title,
            timestamp: Date.now(),
            scrollPosition: window.scrollY
        };
        
        // 如果當前不在歷史記錄的末尾，移除後面的記錄
        if (this.currentIndex < this.history.length - 1) {
            this.history = this.history.slice(0, this.currentIndex + 1);
        }
        
        // 添加新記錄
        this.history.push(historyItem);
        this.currentIndex = this.history.length - 1;
        
        // 限制歷史記錄長度
        if (this.history.length > this.maxHistory) {
            this.history = this.history.slice(-this.maxHistory);
            this.currentIndex = this.history.length - 1;
        }
        
        this.updateNavigationUI();
        
        console.log('添加歷史記錄:', historyItem);
    }
    
    /**
     * 導航到指定頁面
     */
    navigateTo(url, title = '', addToHistory = true) {
        console.log('導航到:', url);
        
        if (addToHistory) {
            // 保存當前滾動位置
            if (this.history[this.currentIndex]) {
                this.history[this.currentIndex].scrollPosition = window.scrollY;
            }
            
            // 使用 pushState 更新瀏覽器歷史
            window.history.pushState({ navigationIndex: this.currentIndex + 1 }, title, url);
            
            // 添加到內部歷史
            this.addToHistory(url, title);
        }
        
        // 更新頁面標題
        if (title) {
            document.title = title;
        }
    }
    
    /**
     * 回到上一頁
     */
    goBack() {
        if (this.canGoBack()) {
            this.currentIndex--;
            const previousPage = this.history[this.currentIndex];
            
            console.log('回到上一頁:', previousPage);
            
            // 更新URL但不添加到歷史記錄
            window.history.pushState(
                { navigationIndex: this.currentIndex }, 
                previousPage.title, 
                previousPage.url
            );
            
            // 根據URL類型進行不同的處理
            this.loadPage(previousPage);
            
            this.updateNavigationUI();
        } else {
            console.log('無法回到上一頁');
        }
    }
    
    /**
     * 前往下一頁
     */
    goForward() {
        if (this.canGoForward()) {
            this.currentIndex++;
            const nextPage = this.history[this.currentIndex];
            
            console.log('前往下一頁:', nextPage);
            
            // 更新URL但不添加到歷史記錄
            window.history.pushState(
                { navigationIndex: this.currentIndex }, 
                nextPage.title, 
                nextPage.url
            );
            
            // 根據URL類型進行不同的處理
            this.loadPage(nextPage);
            
            this.updateNavigationUI();
        } else {
            console.log('無法前往下一頁');
        }
    }
    
    /**
     * 檢查是否可以回到上一頁
     */
    canGoBack() {
        return this.currentIndex > 0;
    }
    
    /**
     * 檢查是否可以前往下一頁
     */
    canGoForward() {
        return this.currentIndex < this.history.length - 1;
    }
    
    /**
     * 載入指定頁面
     */
    loadPage(pageInfo) {
        const url = new URL(pageInfo.url);
        const pathname = url.pathname;
        const params = new URLSearchParams(url.search);
        
        // 根據路徑載入不同頁面 - 使用簡潔的路由
        if (pathname.includes('index.html') || pathname === '/' || pathname === '/home') {
            this.loadHomePage(params);
        } else if (pathname.includes('my-posts.html') || pathname === '/my-posts') {
            this.loadMyPostsPage();
        } else if (pathname.includes('write.html') || pathname === '/write') {
            this.loadWritePage();
        } else if (pathname.includes('login.html') || pathname === '/login') {
            this.loadLoginPage();
        } else if (pathname.includes('register.html') || pathname === '/register') {
            this.loadRegisterPage();
        } else if (pathname.includes('admin.html') || pathname === '/admin') {
            this.loadAdminPage();
        } else {
            // 如果是同頁面內的不同狀態，重新載入頁面
            window.location.href = pageInfo.url;
        }
        
        // 恢復滾動位置
        setTimeout(() => {
            if (pageInfo.scrollPosition) {
                window.scrollTo(0, pageInfo.scrollPosition);
            }
        }, 100);
    }
    
    /**
     * 載入首頁
     */
    loadHomePage(params) {
        const page = params.get('page');
        
        if (page === 'my-posts' && window.BlogApp) {
            window.BlogApp.loadMyPosts();
        } else if (window.BlogApp) {
            window.BlogApp.loadPosts();
        } else {
            window.location.href = 'index.html';
        }
    }
    
    /**
     * 載入其他頁面
     */
    loadMyPostsPage() {
        window.location.href = 'my-posts.html';
    }
    
    loadWritePage() {
        window.location.href = 'write.html';
    }
    
    loadLoginPage() {
        window.location.href = 'login.html';
    }
    
    loadRegisterPage() {
        window.location.href = 'register.html';
    }
    
    loadAdminPage() {
        window.location.href = 'admin.html';
    }
    
    /**
     * 處理瀏覽器後退/前進事件
     */
    handlePopState(event) {
        if (event.state && typeof event.state.navigationIndex === 'number') {
            this.currentIndex = event.state.navigationIndex;
            this.updateNavigationUI();
        }
    }
    
    /**
     * 處理鍵盤快捷鍵
     */
    handleKeyDown(event) {
        // Alt + 左箭頭：回到上一頁
        if (event.altKey && event.key === 'ArrowLeft') {
            event.preventDefault();
            this.goBack();
        }
        
        // Alt + 右箭頭：前往下一頁
        if (event.altKey && event.key === 'ArrowRight') {
            event.preventDefault();
            this.goForward();
        }
        
        // Ctrl/Cmd + H：顯示歷史記錄
        if ((event.ctrlKey || event.metaKey) && event.key === 'h') {
            event.preventDefault();
            this.toggleHistoryPanel();
        }
    }
    
    /**
     * 綁定導航事件
     */
    bindNavigationEvents() {
        // 監聽所有連結點擊
        document.addEventListener('click', (event) => {
            const link = event.target.closest('a[href]');
            if (link && !link.href.startsWith('javascript:') && !link.hasAttribute('download')) {
                const href = link.href;
                const title = link.textContent.trim() || link.title;
                
                // 如果是外部連結，不處理
                if (!href.startsWith(window.location.origin)) {
                    return;
                }
                
                // 如果是#錨點，不處理
                if (href.includes('#') && href.split('#')[0] === window.location.href.split('#')[0]) {
                    return;
                }
                
                // 記錄導航
                setTimeout(() => {
                    this.addToHistory(href, title);
                }, 100);
            }
        });
    }
    
    /**
     * 創建導航UI
     */
    createNavigationUI() {
        // 創建浮動導航按鈕
        const navContainer = document.createElement('div');
        navContainer.id = 'navigation-controls';
        navContainer.className = 'navigation-controls';
        navContainer.innerHTML = `
            <div class="nav-buttons">
                <button id="nav-back-btn" class="nav-btn" title="上一頁 (Alt + ←)">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button id="nav-forward-btn" class="nav-btn" title="下一頁 (Alt + →)">
                    <i class="fas fa-chevron-right"></i>
                </button>
                <button id="nav-history-btn" class="nav-btn" title="歷史記錄 (Ctrl/Cmd + H)">
                    <i class="fas fa-history"></i>
                </button>
            </div>
            <div id="nav-history-panel" class="nav-history-panel" style="display: none;">
                <div class="nav-history-header">
                    <h6>瀏覽歷史</h6>
                    <button id="nav-history-close" class="nav-close-btn">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div id="nav-history-list" class="nav-history-list">
                    <!-- 歷史記錄列表 -->
                </div>
            </div>
        `;
        
        document.body.appendChild(navContainer);
        
        // 綁定按鈕事件
        document.getElementById('nav-back-btn').addEventListener('click', () => this.goBack());
        document.getElementById('nav-forward-btn').addEventListener('click', () => this.goForward());
        document.getElementById('nav-history-btn').addEventListener('click', () => this.toggleHistoryPanel());
        document.getElementById('nav-history-close').addEventListener('click', () => this.hideHistoryPanel());
        
        // 添加CSS樣式
        this.addNavigationStyles();
        
        this.updateNavigationUI();
    }
    
    /**
     * 更新導航UI狀態
     */
    updateNavigationUI() {
        const backBtn = document.getElementById('nav-back-btn');
        const forwardBtn = document.getElementById('nav-forward-btn');
        
        if (backBtn) {
            backBtn.disabled = !this.canGoBack();
            backBtn.classList.toggle('disabled', !this.canGoBack());
        }
        
        if (forwardBtn) {
            forwardBtn.disabled = !this.canGoForward();
            forwardBtn.classList.toggle('disabled', !this.canGoForward());
        }
    }
    
    /**
     * 切換歷史記錄面板
     */
    toggleHistoryPanel() {
        const panel = document.getElementById('nav-history-panel');
        if (panel.style.display === 'none') {
            this.showHistoryPanel();
        } else {
            this.hideHistoryPanel();
        }
    }
    
    /**
     * 顯示歷史記錄面板
     */
    showHistoryPanel() {
        const panel = document.getElementById('nav-history-panel');
        const historyList = document.getElementById('nav-history-list');
        
        // 生成歷史記錄HTML
        const historyHTML = this.history.map((item, index) => {
            const isActive = index === this.currentIndex;
            const timeStr = new Date(item.timestamp).toLocaleString('zh-TW');
            
            return `
                <div class="nav-history-item ${isActive ? 'active' : ''}" data-index="${index}">
                    <div class="history-title">${item.title || '未命名頁面'}</div>
                    <div class="history-url">${item.url}</div>
                    <div class="history-time">${timeStr}</div>
                </div>
            `;
        }).reverse().join(''); // 反轉以顯示最新的在上面
        
        historyList.innerHTML = historyHTML;
        
        // 綁定歷史記錄點擊事件
        historyList.addEventListener('click', (event) => {
            const item = event.target.closest('.nav-history-item');
            if (item) {
                const index = parseInt(item.dataset.index);
                this.navigateToHistoryIndex(index);
                this.hideHistoryPanel();
            }
        });
        
        panel.style.display = 'block';
    }
    
    /**
     * 隱藏歷史記錄面板
     */
    hideHistoryPanel() {
        const panel = document.getElementById('nav-history-panel');
        panel.style.display = 'none';
    }
    
    /**
     * 導航到指定的歷史記錄索引
     */
    navigateToHistoryIndex(index) {
        if (index >= 0 && index < this.history.length) {
            this.currentIndex = index;
            const targetPage = this.history[index];
            
            window.history.pushState(
                { navigationIndex: index }, 
                targetPage.title, 
                targetPage.url
            );
            
            this.loadPage(targetPage);
            this.updateNavigationUI();
        }
    }
    
    /**
     * 添加導航樣式
     */
    addNavigationStyles() {
        const styles = `
            <style>
                .navigation-controls {
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    z-index: 1000;
                }
                
                .nav-buttons {
                    display: flex;
                    gap: 5px;
                    margin-bottom: 10px;
                }
                
                .nav-btn {
                    width: 45px;
                    height: 45px;
                    border: none;
                    border-radius: 50%;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: all 0.3s ease;
                    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
                }
                
                .nav-btn:hover:not(.disabled) {
                    transform: translateY(-2px);
                    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
                }
                
                .nav-btn.disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                    background: #ccc;
                }
                
                .nav-history-panel {
                    position: absolute;
                    bottom: 60px;
                    right: 0;
                    width: 350px;
                    max-height: 400px;
                    background: white;
                    border-radius: 10px;
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
                    overflow: hidden;
                }
                
                .nav-history-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 15px;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                }
                
                .nav-history-header h6 {
                    margin: 0;
                    font-weight: 600;
                }
                
                .nav-close-btn {
                    background: none;
                    border: none;
                    color: white;
                    cursor: pointer;
                    padding: 5px;
                    border-radius: 3px;
                }
                
                .nav-close-btn:hover {
                    background: rgba(255, 255, 255, 0.2);
                }
                
                .nav-history-list {
                    max-height: 320px;
                    overflow-y: auto;
                }
                
                .nav-history-item {
                    padding: 12px 15px;
                    border-bottom: 1px solid #eee;
                    cursor: pointer;
                    transition: background-color 0.2s ease;
                }
                
                .nav-history-item:hover {
                    background-color: #f8f9fa;
                }
                
                .nav-history-item.active {
                    background-color: #e3f2fd;
                    border-left: 4px solid #2196f3;
                }
                
                .history-title {
                    font-weight: 600;
                    color: #333;
                    margin-bottom: 5px;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
                
                .history-url {
                    font-size: 12px;
                    color: #666;
                    margin-bottom: 3px;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
                
                .history-time {
                    font-size: 11px;
                    color: #999;
                }
                
                /* 響應式設計 */
                @media (max-width: 768px) {
                    .navigation-controls {
                        bottom: 15px;
                        right: 15px;
                    }
                    
                    .nav-btn {
                        width: 40px;
                        height: 40px;
                    }
                    
                    .nav-history-panel {
                        width: 300px;
                    }
                }
                
                @media (max-width: 480px) {
                    .nav-history-panel {
                        width: calc(100vw - 30px);
                        right: -15px;
                    }
                }
            </style>
        `;
        
        document.head.insertAdjacentHTML('beforeend', styles);
    }
    
    /**
     * 獲取當前頁面信息
     */
    getCurrentPageInfo() {
        return this.history[this.currentIndex] || null;
    }
    
    /**
     * 清除歷史記錄
     */
    clearHistory() {
        this.history = [];
        this.currentIndex = -1;
        this.addToHistory(window.location.href, document.title);
        this.updateNavigationUI();
    }
}

// 全域實例
window.NavigationManager = NavigationManager;

// 頁面載入完成後自動初始化
document.addEventListener('DOMContentLoaded', () => {
    if (!window.navigationManager) {
        window.navigationManager = new NavigationManager();
    }
});

// 提供全域快捷方法
window.goBack = () => {
    if (window.navigationManager) {
        window.navigationManager.goBack();
    }
};

window.goForward = () => {
    if (window.navigationManager) {
        window.navigationManager.goForward();
    }
};
