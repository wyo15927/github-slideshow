package com.blog.controller;

import com.blog.dto.response.CommentResponse;
import com.blog.dto.response.UserResponse;
import com.blog.entity.Comment;
import com.blog.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Comment REST API Controller
 */
@RestController
@RequestMapping("/api/comments")
@CrossOrigin(origins = "*")
public class CommentController {

    @Autowired
    private CommentService commentService;

    /**
     * Get all comments (for admin)
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> getAllComments(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
            Page<Comment> commentPage = commentService.findAllComments(pageable);
            
            List<CommentResponse> commentResponses = commentPage.getContent().stream()
                .map(this::convertToCommentResponse)
                .collect(Collectors.toList());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", commentResponses);
            response.put("total", commentPage.getTotalElements());
            response.put("page", page);
            response.put("size", size);
            response.put("totalPages", commentPage.getTotalPages());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * Get recent comments
     */
    @GetMapping("/recent")
    public ResponseEntity<Map<String, Object>> getRecentComments(
            @RequestParam(defaultValue = "5") int limit) {
        try {
            List<Comment> comments = commentService.findLatestComments(limit);
            List<CommentResponse> commentResponses = comments.stream()
                .map(this::convertToCommentResponse)
                .collect(Collectors.toList());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", commentResponses);
            response.put("total", commentResponses.size());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * Get comments by post ID
     */
    @GetMapping("/post/{postId}")
    public ResponseEntity<Map<String, Object>> getCommentsByPost(
            @PathVariable Integer postId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        try {
            List<Comment> comments = commentService.findApprovedCommentsByPost(postId);

            List<CommentResponse> commentResponses = comments.stream()
                .map(this::convertToCommentResponse)
                .collect(Collectors.toList());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", commentResponses);
            response.put("total", commentResponses.size());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * Create new comment
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> createComment(
            @RequestBody Map<String, Object> commentRequest) {
        try {
            Integer postId = (Integer) commentRequest.get("postId");
            String authorName = (String) commentRequest.get("authorName");
            String authorEmail = (String) commentRequest.get("authorEmail");
            String content = (String) commentRequest.get("content");

            Comment comment = new Comment(authorName, authorEmail, content, null);
            Comment savedComment = commentService.createComment(comment, postId);
            CommentResponse response = convertToCommentResponse(savedComment);

            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("data", response);
            result.put("message", "Comment created successfully");

            return ResponseEntity.status(HttpStatus.CREATED).body(result);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * Update comment
     */
    @PutMapping("/{commentId}")
    public ResponseEntity<Map<String, Object>> updateComment(
            @PathVariable Integer commentId,
            @RequestBody Map<String, Object> commentRequest) {
        try {
            String content = (String) commentRequest.get("content");
            
            // Get existing comment
            Comment existingComment = commentService.findById(commentId)
                .orElseThrow(() -> new RuntimeException("Comment not found"));
            
            // Update content
            existingComment.setContent(content);
            Comment updatedComment = commentService.updateComment(commentId, existingComment);
            CommentResponse response = convertToCommentResponse(updatedComment);

            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("data", response);
            result.put("message", "Comment updated successfully");

            return ResponseEntity.ok(result);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * Approve comment
     */
    @PutMapping("/{commentId}/approve")
    public ResponseEntity<Map<String, Object>> approveComment(@PathVariable Integer commentId) {
        try {
            commentService.approveComment(commentId);

            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("message", "Comment approved successfully");

            return ResponseEntity.ok(result);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * Reject comment
     */
    @PutMapping("/{commentId}/reject")
    public ResponseEntity<Map<String, Object>> rejectComment(@PathVariable Integer commentId) {
        try {
            commentService.rejectComment(commentId);

            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("message", "Comment rejected successfully");

            return ResponseEntity.ok(result);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * Delete comment
     */
    @DeleteMapping("/{commentId}")
    public ResponseEntity<Map<String, Object>> deleteComment(@PathVariable Integer commentId) {
        try {
            commentService.deleteComment(commentId);

            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("message", "Comment deleted successfully");

            return ResponseEntity.ok(result);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 按讚評論
     */
    @PostMapping("/{commentId}/like")
    public ResponseEntity<Map<String, Object>> likeComment(@PathVariable Integer commentId) {
        try {
            Comment comment = commentService.likeComment(commentId);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("message", "Comment liked successfully");
            result.put("data", Map.of(
                "commentId", comment.getCommentId(),
                "likeCount", comment.getLikeCount()
            ));

            return ResponseEntity.ok(result);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 取消按讚評論
     */
    @DeleteMapping("/{commentId}/like")
    public ResponseEntity<Map<String, Object>> unlikeComment(@PathVariable Integer commentId) {
        try {
            Comment comment = commentService.unlikeComment(commentId);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("message", "Comment unliked successfully");
            result.put("data", Map.of(
                "commentId", comment.getCommentId(),
                "likeCount", comment.getLikeCount()
            ));

            return ResponseEntity.ok(result);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    // Private conversion methods

    /**
     * Convert Comment entity to CommentResponse DTO
     */
    private CommentResponse convertToCommentResponse(Comment comment) {
        CommentResponse response = new CommentResponse();
        response.setCommentId(comment.getCommentId());
        response.setContent(comment.getContent());
        response.setStatus(comment.getStatus().name());
        // 🆕 使用實際的 likeCount 值
        response.setLikeCount(comment.getLikeCount() != null ? comment.getLikeCount() : 0);
        response.setCreatedAt(comment.getCreatedAt());
        response.setUpdatedAt(comment.getUpdatedAt());

        // Set author info (using authorName and authorEmail from Comment entity)
        if (comment.getAuthorName() != null) {
            com.blog.dto.response.UserResponse author = new com.blog.dto.response.UserResponse();
            author.setUserId(0); // Comment entity doesn't have User association
            author.setUsername(comment.getAuthorName());
            author.setDisplayName(comment.getAuthorName());
            author.setAvatar("images/placeholders/avatar-default.svg");
            response.setAuthor(author);
        }

        // 🆕 安全處理 Post 訪問（避免懶加載錯誤）
        try {
            if (comment.getPost() != null) {
                response.setPostId(comment.getPost().getPostId());
                response.setPostTitle(comment.getPost().getTitle());
                response.setPostSlug(comment.getPost().getSlug());
            }
        } catch (org.hibernate.LazyInitializationException e) {
            // 如果 Post 未加載，跳過（前端不需要這些信息來更新評論）
            System.err.println("Warning: Post not loaded for comment " + comment.getCommentId());
        }

        // 🆕 安全處理 ParentComment 訪問
        try {
            if (comment.getParentComment() != null) {
                response.setParentCommentId(comment.getParentComment().getCommentId());
            }
        } catch (org.hibernate.LazyInitializationException e) {
            // 如果 ParentComment 未加載，跳過
            System.err.println("Warning: ParentComment not loaded for comment " + comment.getCommentId());
        }

        return response;
    }

    /**
     * Create error response
     */
    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        return response;
    }
}
