/**
 * 關於我區塊管理器
 * 根據登入狀態動態顯示用戶資訊
 */

class AboutMeWidget {
    constructor() {
        this.container = null;
        this.defaultData = {
            displayName: '部落格作者',
            profession: '技術愛好者 & 分享者',
            bio: '分享技術心得與生活感想，希望能對大家有所幫助。',
            avatar: 'images/placeholders/avatar-default.svg',
            website: '',
            location: '',
            socialLinks: [
                { platform: 'github', icon: 'fab fa-github', url: '#' },
                { platform: 'linkedin', icon: 'fab fa-linkedin', url: '#' },
                { platform: 'twitter', icon: 'fab fa-twitter', url: '#' }
            ]
        };
    }

    // 初始化關於我區塊
    async init() {
        this.container = document.querySelector('.card-body.text-center');
        if (!this.container) {
            console.warn('找不到關於我區塊容器');
            return;
        }

        console.log('初始化關於我區塊');
        await this.updateAboutMeSection();
    }

    // 更新關於我區塊
    async updateAboutMeSection() {
        try {
            let userData = this.defaultData;

            // 如果用戶已登入，嘗試獲取用戶資料
            if (window.AuthManager && window.AuthManager.isLoggedIn()) {
                console.log('用戶已登入，載入個人資料');
                const currentUser = await this.getCurrentUserData();
                if (currentUser) {
                    userData = this.mergeUserData(currentUser);
                }
            } else {
                console.log('用戶未登入，使用預設資料');
            }

            // 渲染關於我區塊
            this.renderAboutMe(userData);

        } catch (error) {
            console.error('更新關於我區塊失敗:', error);
            // 發生錯誤時使用預設資料
            this.renderAboutMe(this.defaultData);
        }
    }

    // 獲取當前用戶資料
    async getCurrentUserData() {
        try {
            // 首先嘗試從API獲取
            const response = await this.fetchUserProfileFromAPI();
            if (response) {
                console.log('從API獲取用戶資料成功:', response);
                return response;
            }
        } catch (apiError) {
            console.log('API獲取失敗，嘗試本地資料:', apiError.message);
        }

        // API失敗時從本地存儲獲取
        return this.getUserDataFromLocal();
    }

    // 從API獲取用戶資料
    async fetchUserProfileFromAPI() {
        try {
            // 使用 BlogAPI.user.getCurrentProfile() 方法
            if (window.BlogAPI && window.BlogAPI.user) {
                const result = await window.BlogAPI.user.getCurrentProfile();
                if (result && result.data) {
                    return result.data;
                }
            }
            return null;
        } catch (error) {
            console.error('API獲取用戶資料失敗:', error);
            return null;
        }
    }

    // 從本地存儲獲取用戶資料
    getUserDataFromLocal() {
        try {
            const localUser = localStorage.getItem('user');
            const sessionUser = sessionStorage.getItem('user');
            const userData = localUser || sessionUser;
            
            if (userData) {
                const parsed = JSON.parse(userData);
                console.log('從本地存儲獲取用戶資料:', parsed);
                return parsed;
            }
            
            // 如果沒有完整的用戶資料，從token解析基本資訊
            const token = window.AuthManager ? window.AuthManager.getToken() : null;
            if (token && token.includes(':')) {
                const username = token.split(':')[0];
                return {
                    username: username,
                    displayName: username,
                    profession: '部落格作者',
                    bio: '歡迎來到我的部落格！',
                    avatar: 'images/placeholders/avatar-default.svg'
                };
            }
            
            return null;
        } catch (error) {
            console.error('解析本地用戶資料失敗:', error);
            return null;
        }
    }

    // 合併用戶資料和預設資料
    mergeUserData(userData) {
        return {
            displayName: userData.displayName || userData.username || this.defaultData.displayName,
            profession: userData.profession || this.defaultData.profession,
            bio: userData.bio || this.defaultData.bio,
            avatar: userData.avatar || this.defaultData.avatar,
            website: userData.website || this.defaultData.website,
            location: userData.location || this.defaultData.location,
            username: userData.username,
            socialLinks: this.defaultData.socialLinks // 社交連結保持預設
        };
    }

    // 渲染關於我區塊
    renderAboutMe(userData) {
        if (!this.container) return;

        console.log('渲染關於我區塊，使用資料:', userData);

        // 社交連結功能已關閉
        const socialLinksHtml = '';

        // 構建位置資訊（如果有）
        const locationHtml = userData.location ? 
            `<p class="text-muted small mb-2">
                <i class="fas fa-map-marker-alt me-1"></i>${userData.location}
            </p>` : '';

        // 網站連結功能已關閉
        const websiteHtml = '';

        // 構建完整HTML
        const html = `
            <img src="${userData.avatar}" alt="我的頭像" class="rounded-circle mb-3" width="100" height="100" style="object-fit: cover;">
            <h6 class="card-title">${userData.displayName}</h6>
            <p class="text-primary small mb-2">${userData.profession}</p>
            ${locationHtml}
            <p class="card-text text-muted small mb-3">${userData.bio}</p>
            ${websiteHtml}
            <div class="d-flex justify-content-center gap-2">
                ${socialLinksHtml}
                ${window.AuthManager && window.AuthManager.isLoggedIn() && userData.username ? 
                    `<a href="profile-settings.html" class="btn btn-outline-success btn-sm" title="編輯個人資料">
                        <i class="fas fa-edit"></i>
                    </a>` : ''
                }
            </div>
        `;

        this.container.innerHTML = html;
        console.log('關於我區塊渲染完成');
    }

    // 監聽登入狀態變化
    onAuthStateChanged() {
        console.log('認證狀態變化，更新關於我區塊');
        this.updateAboutMeSection();
    }
}

// 創建全局實例
window.aboutMeWidget = new AboutMeWidget();

// 監聽認證狀態變化事件
window.addEventListener('authStateChanged', () => {
    if (window.aboutMeWidget) {
        window.aboutMeWidget.onAuthStateChanged();
    }
});

// 監聽用戶資料更新事件
window.addEventListener('userProfileUpdated', (event) => {
    if (window.aboutMeWidget) {
        console.log('收到用戶資料更新事件:', event.detail);
        window.aboutMeWidget.updateAboutMeSection();
    }
});
