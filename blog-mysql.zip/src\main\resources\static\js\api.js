/**
 * API 通訊模組
 * 處理與後端 Spring Boot API 的所有通訊
 */

// API 基礎配置
const API_CONFIG = {
    // 直接連接到後端端口8080
    BASE_URL: `${window.location.protocol}//${window.location.hostname}:8080/api`,
    TIMEOUT: 10000,
    DEFAULT_HEADERS: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
};

// 認證狀態管理 - 使用全局 AuthManager 實例
// AuthManager 類別定義在 auth-manager.js 中

// HTTP 請求工具類
class ApiClient {
    constructor() {
        this.baseURL = API_CONFIG.BASE_URL;
        this.timeout = API_CONFIG.TIMEOUT;
    }
    
    async request(method, endpoint, data = null, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const headers = {
            ...API_CONFIG.DEFAULT_HEADERS,
            ...(window.AuthManager ? window.AuthManager.getAuthHeaders() : {}),
            ...options.headers
        };
        
        const config = {
            method: method.toUpperCase(),
            headers,
            ...options
        };
        
        // 添加超時控制（兼容性更好的方式）
        let timeoutId;
        if (this.timeout > 0) {
            const controller = new AbortController();
            config.signal = controller.signal;
            timeoutId = setTimeout(() => controller.abort(), this.timeout);
        }
        
        if (data && ['POST', 'PUT', 'PATCH'].includes(config.method)) {
            if (data instanceof FormData) {
                delete headers['Content-Type']; // 讓瀏覽器自動設定
            } else {
                config.body = JSON.stringify(data);
            }
        }
        
        try {
            const response = await fetch(url, config);
            // 清理超時計時器
            if (timeoutId) {
                clearTimeout(timeoutId);
            }
            return await this.handleResponse(response);
        } catch (error) {
            // 清理超時計時器
            if (timeoutId) {
                clearTimeout(timeoutId);
            }
            throw this.handleError(error);
        }
    }
    
    async handleResponse(response) {
        const contentType = response.headers.get('content-type');
        let data;
        
        if (contentType && contentType.includes('application/json')) {
            data = await response.json();
        } else {
            data = await response.text();
        }
        
        if (!response.ok) {
            throw new ApiError(data.message || '請求失敗', response.status, data);
        }
        
        return data;
    }
    
    handleError(error) {
        if (error.name === 'AbortError') {
            return new ApiError('請求超時', 408);
        }
        
        if (error instanceof ApiError) {
            return error;
        }
        
        return new ApiError(error.message || '網路錯誤', 0);
    }
    
    // 清理超時計時器
    clearTimeout(timeoutId) {
        if (timeoutId) {
            clearTimeout(timeoutId);
        }
    }
    
    // HTTP 方法快捷方式
    get(endpoint, options = {}) {
        return this.request('GET', endpoint, null, options);
    }
    
    post(endpoint, data, options = {}) {
        return this.request('POST', endpoint, data, options);
    }
    
    put(endpoint, data, options = {}) {
        return this.request('PUT', endpoint, data, options);
    }
    
    patch(endpoint, data, options = {}) {
        return this.request('PATCH', endpoint, data, options);
    }
    
    delete(endpoint, options = {}) {
        return this.request('DELETE', endpoint, null, options);
    }
}

// 自訂錯誤類別
class ApiError extends Error {
    constructor(message, status = 0, data = null) {
        super(message);
        this.name = 'ApiError';
        this.status = status;
        this.data = data;
    }
}

// 建立 API 客戶端實例
const apiClient = new ApiClient();

// API 服務模組
const BlogAPI = {
    // 文章相關 API
    posts: {
        // 獲取文章列表
        async getList(params = {}) {
            const searchParams = new URLSearchParams();
            Object.entries(params).forEach(([key, value]) => {
                if (value !== null && value !== undefined && value !== '') {
                    searchParams.append(key, value);
                }
            });
            
            const endpoint = searchParams.toString() 
                ? `/posts?${searchParams.toString()}`
                : '/posts';
            
            return apiClient.get(endpoint);
        },
        
        // 獲取單篇文章
        async getById(id) {
            return apiClient.get(`/posts/${id}`);
        },
        
        // 根據路徑獲取文章
        async getBySlug(slug) {
            return apiClient.get(`/posts/slug/${slug}`);
        },
        
        // 搜尋文章
        async search(keyword, params = {}) {
            const searchParams = new URLSearchParams({ keyword, ...params });
            return apiClient.get(`/posts/search?${searchParams.toString()}`);
        },
        
        // 獲取精選文章
        async getFeatured() {
            return apiClient.get('/posts/featured');
        },
        

        
        // 獲取最新文章
        async getLatest(limit = 5) {
            return apiClient.get(`/posts/latest?limit=${limit}`);
        },
        
        // 增加瀏覽次數
        async incrementViews(id) {
            return apiClient.post(`/posts/${id}/views`);
        },
        
        // 按讚文章
        async like(id) {
            return apiClient.post(`/posts/${id}/like`);
        },

        // 取消按讚文章
        async unlike(id) {
            return apiClient.delete(`/posts/${id}/like`);
        },
        
        // 創建文章
        async create(postData, authorId) {
            const url = `/posts?authorId=${authorId}`;
            return apiClient.post(url, postData);
        },
        
        // 更新文章
        async update(id, postData) {
            return apiClient.put(`/posts/${id}`, postData);
        },
        
        // 刪除文章
        async delete(id) {
            return apiClient.delete(`/posts/${id}`);
        }
    },
    
    // 分類相關 API
    categories: {
        // 獲取所有分類
        async getAll() {
            return apiClient.get('/categories');
        },
        
        // 獲取分類詳情
        async getById(id) {
            return apiClient.get(`/categories/${id}`);
        },
        
        // 根據分類獲取文章
        async getPosts(id, params = {}) {
            const searchParams = new URLSearchParams(params);
            return apiClient.get(`/categories/${id}/posts?${searchParams.toString()}`);
        },
        
        // 🆕 創建分類
        async create(categoryData) {
            return apiClient.post('/categories', categoryData);
        },
        
        // 🆕 更新分類
        async update(id, categoryData) {
            return apiClient.put(`/categories/${id}`, categoryData);
        },
        
        // 🆕 刪除分類
        async delete(id) {
            return apiClient.delete(`/categories/${id}`);
        }
    },
    
    // 標籤相關 API
    tags: {
        // 獲取所有標籤
        async getAll() {
            return apiClient.get('/tags');
        },
        
        // 獲取標籤詳情
        async getById(id) {
            return apiClient.get(`/tags/${id}`);
        },
        
        // 根據標籤獲取文章
        async getPosts(id, params = {}) {
            const searchParams = new URLSearchParams(params);
            return apiClient.get(`/tags/${id}/posts?${searchParams.toString()}`);
        },
        
        // 獲取熱門標籤
        async getPopular(limit = 20) {
            return apiClient.get(`/tags/popular?limit=${limit}`);
        },
        
        // 🆕 創建標籤
        async create(tagData) {
            return apiClient.post('/tags', tagData);
        },
        
        // 🆕 更新標籤
        async update(id, tagData) {
            return apiClient.put(`/tags/${id}`, tagData);
        },
        
        // 🆕 刪除標籤
        async delete(id) {
            return apiClient.delete(`/tags/${id}`);
        }
    },
    
    // 評論相關 API
    comments: {
        // 獲取最近評論
        getRecent: (limit = 5) => apiClient.get(`/comments/recent?limit=${limit}`),
        
        // 獲取文章評論
        getByPost: (postId) => apiClient.get(`/comments/post/${postId}`),
        
        // 獲取所有評論
        getAll: () => apiClient.get('/comments'),
        
        // 創建評論
        create: (data) => apiClient.post('/comments', data),
        
        // 更新評論
        update: (id, data) => apiClient.put(`/comments/${id}`, data),
        
        // 刪除評論
        delete: (id) => apiClient.delete(`/comments/${id}`),
        
        // 審核評論
        approve: (id) => apiClient.put(`/comments/${id}/approve`),
        
        // 拒絕評論
        reject: (id) => apiClient.put(`/comments/${id}/reject`),
        
        // 點讚評論
        like: (id) => apiClient.post(`/comments/${id}/like`),
        
        // 取消點讚評論
        unlike: (id) => apiClient.delete(`/comments/${id}/like`)
    },
    
    // 認證相關 API
    auth: {
        // 登入
        async login(credentials) {
            const response = await apiClient.post('/auth/login', credentials);
            if (response.token) {
                if (window.AuthManager) {
                window.AuthManager.setToken(response.token);
            }
            }
            return response;
        },
        
        // 註冊
        async register(userData) {
            return apiClient.post('/auth/register', userData);
        },
        
        // 登出
        async logout() {
            try {
                await apiClient.post('/auth/logout');
            } finally {
                if (window.AuthManager) {
                    window.AuthManager.removeToken();
                }
            }
        },
        
        // 驗證 token
        async validateToken() {
            if (!window.AuthManager || !window.AuthManager.isLoggedIn()) {
                return false;
            }
            
            try {
                await apiClient.get('/auth/validate');
                return true;
            } catch (error) {
                if (window.AuthManager) {
                    window.AuthManager.removeToken();
                }
                return false;
            }
        },
        
        // 獲取當前用戶資訊
        async getCurrentUser() {
            return apiClient.get('/user/profile');
        }
    },
    
    // 檔案上傳 API
    media: {
        // 上傳檔案
        async upload(file, metadata = {}) {
            const formData = new FormData();
            formData.append('file', file);
            
            Object.entries(metadata).forEach(([key, value]) => {
                formData.append(key, value);
            });
            
            return apiClient.post('/media/upload', formData);
        },
        
        // 獲取檔案列表
        async getList(params = {}) {
            const searchParams = new URLSearchParams(params);
            return apiClient.get(`/media?${searchParams.toString()}`);
        }
    },
    
    // 用戶個人資料相關 API
    user: {
        // 獲取當前用戶資料
        async getCurrentProfile() {
            return apiClient.get('/user/profile');
        },
        
        // 更新當前用戶資料
        async updateProfile(profileData) {
            return apiClient.put('/user/profile', profileData);
        },
        
        // 獲取指定用戶的公開資料
        async getPublicProfile(username) {
            return apiClient.get(`/user/profile/${username}`);
        },
        
        // 獲取所有用戶列表（公開資料）
        async getAllUsers(params = {}) {
            const searchParams = new URLSearchParams();
            Object.entries(params).forEach(([key, value]) => {
                if (value !== null && value !== undefined && value !== '') {
                    searchParams.append(key, value);
                }
            });
            
            const endpoint = searchParams.toString() 
                ? `/user/users?${searchParams.toString()}`
                : '/user/users';
            
            return apiClient.get(endpoint);
        }
    },
    
    // 網站設定 API
    settings: {
        // 獲取公開設定
        async getPublic() {
            return apiClient.get('/settings/public');
        }
    }
};

// 全域錯誤處理
window.addEventListener('unhandledrejection', (event) => {
    if (event.reason instanceof ApiError) {
        console.error('API Error:', event.reason);
        
        // 根據錯誤狀態碼處理
        switch (event.reason.status) {
            case 401:
                // 未授權，清除 token 並重新導向登入頁面
                if (window.AuthManager) {
                    window.AuthManager.removeToken();
                }
                if (window.location.pathname !== '/login') {
                    window.location.href = '/login';
                }
                break;
            case 403:
                // 權限不足
                console.warn('Access denied');
                break;
            case 404:
                // 資源不存在
                console.warn('Resource not found');
                break;
            case 500:
                // 伺服器錯誤
                console.error('Server error');
                break;
        }
    }
});

// 暴露 API 到全域
window.BlogAPI = BlogAPI;
window.ApiError = ApiError; 
