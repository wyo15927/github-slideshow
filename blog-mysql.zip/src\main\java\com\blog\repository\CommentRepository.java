package com.blog.repository;

import com.blog.entity.Comment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * 評論資料存取介面
 */
@Repository
public interface CommentRepository extends JpaRepository<Comment, Integer> {
    
    /**
     * 根據 ID 查找評論（預加載 Post）
     */
    @Query("SELECT c FROM Comment c LEFT JOIN FETCH c.post WHERE c.commentId = :commentId")
    Optional<Comment> findByIdWithPost(@Param("commentId") Integer commentId);
    
    /**
     * 根據文章查找評論
     */
    Page<Comment> findByPostPostId(Integer postId, Pageable pageable);
    
    /**
     * 根據文章和狀態查找評論
     */
    @Query("SELECT c FROM Comment c WHERE c.post.postId = :postId AND c.status = :status ORDER BY c.createdAt ASC")
    List<Comment> findByPostAndStatus(@Param("postId") Integer postId, @Param("status") String status);
    
    /**
     * 根據文章查找所有評論（不過濾狀態）
     */
    @Query("SELECT c FROM Comment c LEFT JOIN FETCH c.post WHERE c.post.postId = :postId ORDER BY c.createdAt ASC")
    List<Comment> findApprovedCommentsByPost(@Param("postId") Integer postId);
    
    /**
     * 根據父評論查找回覆（不過濾狀態）
     */
    @Query("SELECT c FROM Comment c WHERE c.parentComment.commentId = :parentId ORDER BY c.createdAt ASC")
    List<Comment> findRepliesByParentComment(@Param("parentId") Integer parentId);
    
    /**
     * 查找頂層評論（沒有父評論，不過濾狀態）
     */
    @Query("SELECT c FROM Comment c WHERE c.post.postId = :postId AND c.parentComment IS NULL ORDER BY c.createdAt ASC")
    List<Comment> findTopLevelCommentsByPost(@Param("postId") Integer postId);
    
    /**
     * 根據狀態查找評論
     */
    Page<Comment> findByStatus(String status, Pageable pageable);
    
    /**
     * 查找待審核的評論
     */
    @Query("SELECT c FROM Comment c WHERE c.status = 'PENDING' ORDER BY c.createdAt DESC")
    List<Comment> findPendingComments(Pageable pageable);
    
    /**
     * 根據作者郵箱查找評論
     */
    Page<Comment> findByAuthorEmail(String authorEmail, Pageable pageable);
    
    /**
     * 根據作者名稱查找評論
     */
    @Query("SELECT c FROM Comment c WHERE c.authorName LIKE CONCAT('%', :authorName, '%')")
    Page<Comment> findByAuthorNameContaining(@Param("authorName") String authorName, Pageable pageable);
    
    /**
     * 搜尋評論內容
     */
    @Query("SELECT c FROM Comment c WHERE " +
           "(:keyword IS NULL OR " +
           "c.content LIKE CONCAT('%', :keyword, '%') OR " +
           "c.authorName LIKE CONCAT('%', :keyword, '%'))")
    Page<Comment> searchComments(@Param("keyword") String keyword, Pageable pageable);
    
    /**
     * 統計文章的評論數量（不過濾狀態）
     */
    @Query("SELECT COUNT(c) FROM Comment c WHERE c.post.postId = :postId")
    Long countApprovedCommentsByPost(@Param("postId") Integer postId);
    
    /**
     * 查找最新評論（不過濾狀態）
     */
    @Query("SELECT c FROM Comment c ORDER BY c.createdAt DESC")
    List<Comment> findLatestComments(Pageable pageable);
    
    /**
     * 根據 IP 地址查找評論
     */
    Page<Comment> findByAuthorIp(String authorIp, Pageable pageable);
    
    /**
     * 查找指定時間範圍內的評論
     */
    @Query("SELECT c FROM Comment c WHERE c.createdAt BETWEEN :startDate AND :endDate ORDER BY c.createdAt DESC")
    List<Comment> findCommentsByDateRange(@Param("startDate") LocalDateTime startDate, 
                                          @Param("endDate") LocalDateTime endDate);
    
    /**
     * 查找所有評論（包含關聯的 Post 實體）
     */
    @Query("SELECT c FROM Comment c LEFT JOIN FETCH c.post ORDER BY c.createdAt DESC")
    List<Comment> findAllWithPost();
    
    /**
     * 查找最新評論（包含關聯的 Post 實體，不過濾狀態）
     */
    @Query("SELECT c FROM Comment c LEFT JOIN FETCH c.post ORDER BY c.createdAt DESC")
    List<Comment> findLatestCommentsWithPost(Pageable pageable);
    
    /**
     * 統計各狀態的評論數量
     */
    @Query("SELECT c.status, COUNT(c) FROM Comment c GROUP BY c.status")
    List<Object[]> countCommentsByStatus();
    
    /**
     * 查找需要通知的評論（不過濾狀態）
     */
    @Query("SELECT c FROM Comment c WHERE c.isNotified = false")
    List<Comment> findCommentsToNotify();
} 