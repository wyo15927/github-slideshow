package com.blog.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

/**
 * 媒體檔案實體類別
 * 對應資料庫 Media 表格
 */
@Entity
@Table(name = "Media")
@EntityListeners(AuditingEntityListener.class)
public class Media {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MediaId")
    private Integer mediaId;
    
    @NotBlank(message = "原始檔案名稱不能為空")
    @Size(max = 255, message = "原始檔案名稱不能超過255個字元")
    @Column(name = "OriginalName", nullable = false)
    private String originalName;
    
    @NotBlank(message = "檔案名稱不能為空")
    @Size(max = 255, message = "檔案名稱不能超過255個字元")
    @Column(name = "FileName", nullable = false)
    private String fileName;
    
    @NotBlank(message = "檔案路徑不能為空")
    @Size(max = 500, message = "檔案路徑不能超過500個字元")
    @Column(name = "FilePath", nullable = false, length = 500)
    private String filePath;
    
    @NotBlank(message = "檔案類型不能為空")
    @Size(max = 50, message = "檔案類型不能超過50個字元")
    @Column(name = "FileType", nullable = false, length = 50)
    private String fileType;
    
    @NotNull(message = "檔案大小不能為空")
    @Column(name = "FileSize", nullable = false)
    private Long fileSize;
    
    @Column(name = "Width")
    private Integer width;
    
    @Column(name = "Height")
    private Integer height;
    
    @Size(max = 200, message = "替代文字不能超過200個字元")
    @Column(name = "AltText", length = 200)
    private String altText;
    
    @Size(max = 500, message = "圖片說明不能超過500個字元")
    @Column(name = "Caption", length = 500)
    private String caption;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "UploadedBy")
    private User uploadedBy;
    
    @CreatedDate
    @Column(name = "CreatedAt", updatable = false)
    private LocalDateTime createdAt;
    
    // 預設建構子
    public Media() {}
    
    // 建構子
    public Media(String originalName, String fileName, String filePath, String fileType, Long fileSize) {
        this.originalName = originalName;
        this.fileName = fileName;
        this.filePath = filePath;
        this.fileType = fileType;
        this.fileSize = fileSize;
    }
    
    // Getters and Setters
    public Integer getMediaId() { return mediaId; }
    public void setMediaId(Integer mediaId) { this.mediaId = mediaId; }
    
    public String getOriginalName() { return originalName; }
    public void setOriginalName(String originalName) { this.originalName = originalName; }
    
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    
    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }
    
    public String getFileType() { return fileType; }
    public void setFileType(String fileType) { this.fileType = fileType; }
    
    public Long getFileSize() { return fileSize; }
    public void setFileSize(Long fileSize) { this.fileSize = fileSize; }
    
    public Integer getWidth() { return width; }
    public void setWidth(Integer width) { this.width = width; }
    
    public Integer getHeight() { return height; }
    public void setHeight(Integer height) { this.height = height; }
    
    public String getAltText() { return altText; }
    public void setAltText(String altText) { this.altText = altText; }
    
    public String getCaption() { return caption; }
    public void setCaption(String caption) { this.caption = caption; }
    
    public User getUploadedBy() { return uploadedBy; }
    public void setUploadedBy(User uploadedBy) { this.uploadedBy = uploadedBy; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
} 