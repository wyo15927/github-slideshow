package com.blog.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 分類實體類別
 * 對應資料庫 Categories 表格
 */
@Entity
@Table(name = "Categories")
@EntityListeners(AuditingEntityListener.class)
public class Category {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CategoryId")
    private Integer categoryId;
    
    @NotBlank(message = "分類名稱不能為空")
    @Size(max = 100, message = "分類名稱不能超過100個字元")
    @Column(name = "Name", unique = true, nullable = false, length = 100)
    private String name;
    
    @Size(max = 500, message = "分類描述不能超過500個字元")
    @Column(name = "Description", length = 500)
    private String description;
    
    @NotBlank(message = "分類路徑不能為空")
    @Size(max = 100, message = "分類路徑不能超過100個字元")
    @Column(name = "Slug", unique = true, nullable = false, length = 100)
    private String slug;
    
    @Size(max = 7, message = "顏色代碼格式不正確")
    @Column(name = "Color", length = 7)
    private String color = "#007bff";
    
    @Column(name = "IsActive")
    private Boolean isActive = true;
    
    @CreatedDate
    @Column(name = "CreatedAt", updatable = false)
    private LocalDateTime createdAt;
    
    @LastModifiedDate
    @Column(name = "UpdatedAt")
    private LocalDateTime updatedAt;
    
    // 關聯關係
    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Post> posts;
    
    // 預設建構子
    public Category() {}
    
    // 建構子
    public Category(String name, String slug) {
        this.name = name;
        this.slug = slug;
    }
    
    // Getters and Setters
    public Integer getCategoryId() { return categoryId; }
    public void setCategoryId(Integer categoryId) { this.categoryId = categoryId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getSlug() { return slug; }
    public void setSlug(String slug) { this.slug = slug; }
    
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    
    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    
    public List<Post> getPosts() { return posts; }
    public void setPosts(List<Post> posts) { this.posts = posts; }
} 