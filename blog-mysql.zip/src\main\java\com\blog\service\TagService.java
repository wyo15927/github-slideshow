package com.blog.service;

import com.blog.entity.Tag;
import com.blog.repository.TagRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * 標籤業務邏輯服務
 */
@Service
@Transactional
public class TagService {
    
    @Autowired
    private TagRepository tagRepository;
    
    /**
     * 查找所有標籤
     */
    @Transactional(readOnly = true)
    public List<Tag> findAllTags() {
        return tagRepository.findAll();
    }
    
    /**
     * 根據ID查找標籤
     */
    @Transactional(readOnly = true)
    public Optional<Tag> findById(Integer tagId) {
        return tagRepository.findById(tagId);
    }
    
    /**
     * 根據路徑查找標籤
     */
    @Transactional(readOnly = true)
    public Optional<Tag> findBySlug(String slug) {
        return tagRepository.findBySlug(slug);
    }
    
    /**
     * 根據名稱查找標籤
     */
    @Transactional(readOnly = true)
    public Optional<Tag> findByName(String name) {
        return tagRepository.findByName(name);
    }
    
    /**
     * 根據名稱列表查找標籤
     */
    @Transactional(readOnly = true)
    public List<Tag> findByNames(List<String> names) {
        return tagRepository.findByNameIn(names);
    }
    
    /**
     * 創建新標籤
     */
    public Tag createTag(Tag tag) {
        // 驗證標籤名稱唯一性
        if (tagRepository.existsByName(tag.getName())) {
            throw new RuntimeException("標籤名稱已存在");
        }
        
        // 如果沒有設定路徑，生成一個
        if (tag.getSlug() == null || tag.getSlug().isEmpty()) {
            tag.setSlug(generateSlug(tag.getName()));
        }
        
        // 確保路徑唯一性
        tag.setSlug(ensureUniqueSlug(tag.getSlug()));
        
        return tagRepository.save(tag);
    }
    
    /**
     * 創建或查找標籤 (如果不存在則創建)
     */
    public Tag createOrFindTag(String tagName) {
        return tagRepository.findByName(tagName)
            .orElseGet(() -> {
                Tag newTag = new Tag();
                newTag.setName(tagName);
                newTag.setSlug(generateSlug(tagName));
                newTag.setSlug(ensureUniqueSlug(newTag.getSlug()));
                return tagRepository.save(newTag);
            });
    }
    
    /**
     * 批量創建或查找標籤
     */
    public List<Tag> createOrFindTags(List<String> tagNames) {
        return tagNames.stream()
            .map(this::createOrFindTag)
            .toList();
    }
    
    /**
     * 更新標籤
     */
    public Tag updateTag(Integer tagId, Tag updatedTag) {
        Tag existingTag = tagRepository.findById(tagId)
            .orElseThrow(() -> new RuntimeException("標籤不存在"));
        
        // 檢查名稱唯一性（排除當前標籤）
        if (!existingTag.getName().equals(updatedTag.getName()) &&
            tagRepository.existsByName(updatedTag.getName())) {
            throw new RuntimeException("標籤名稱已存在");
        }
        
        // 更新欄位
        existingTag.setName(updatedTag.getName());
        existingTag.setDescription(updatedTag.getDescription());
        existingTag.setColor(updatedTag.getColor());
        
        // 如果路徑為空，重新生成
        if (updatedTag.getSlug() == null || updatedTag.getSlug().isEmpty()) {
            existingTag.setSlug(generateSlug(updatedTag.getName()));
        } else {
            existingTag.setSlug(updatedTag.getSlug());
        }
        
        // 確保路徑唯一性（排除當前標籤）
        existingTag.setSlug(ensureUniqueSlug(existingTag.getSlug(), tagId));
        
        return tagRepository.save(existingTag);
    }
    
    /**
     * 刪除標籤
     */
    public void deleteTag(Integer tagId) {
        Tag tag = tagRepository.findById(tagId)
            .orElseThrow(() -> new RuntimeException("標籤不存在"));
        
        // 檢查標籤使用次數
        if (tag.getUsageCount() > 0) {
            throw new RuntimeException("此標籤還在使用中，有 " + tag.getUsageCount() + " 篇文章使用此標籤");
        }
        
        tagRepository.delete(tag);
    }
    
    /**
     * 搜尋標籤
     */
    @Transactional(readOnly = true)
    public Page<Tag> searchTags(String keyword, Pageable pageable) {
        return tagRepository.searchTags(keyword, pageable);
    }
    
    /**
     * 查找熱門標籤
     */
    @Transactional(readOnly = true)
    public List<Tag> findPopularTags(int limit) {
        Pageable pageable = PageRequest.of(0, limit);
        return tagRepository.findPopularTags(pageable);
    }
    
    /**
     * 查找最新標籤
     */
    @Transactional(readOnly = true)
    public List<Tag> findLatestTags(int limit) {
        Pageable pageable = PageRequest.of(0, limit);
        return tagRepository.findLatestTags(pageable);
    }
    
    /**
     * 根據使用次數範圍查找標籤
     */
    @Transactional(readOnly = true)
    public List<Tag> findTagsByUsageRange(Integer minUsage, Integer maxUsage) {
        return tagRepository.findTagsByUsageRange(minUsage, maxUsage);
    }
    
    /**
     * 查找指定文章的標籤
     */
    @Transactional(readOnly = true)
    public List<Tag> findTagsByPostId(Integer postId) {
        return tagRepository.findTagsByPostId(postId);
    }
    
    /**
     * 查找相關標籤
     */
    @Transactional(readOnly = true)
    public List<Tag> findRelatedTags(Integer tagId, int limit) {
        Pageable pageable = PageRequest.of(0, limit);
        return tagRepository.findRelatedTags(tagId, pageable);
    }
    
    // 私有輔助方法
    
    /**
     * 生成標籤路徑
     */
    private String generateSlug(String name) {
        return name.toLowerCase()
                .replaceAll("[^a-z0-9\\u4e00-\\u9fff\\s-]", "") // 保留中文、英文、數字、空格和連字符
                .replaceAll("\\s+", "-") // 空格替換為連字符
                .replaceAll("-+", "-") // 多個連字符合併為一個
                .replaceAll("^-|-$", ""); // 移除開頭和結尾的連字符
    }
    
    /**
     * 確保路徑唯一性
     */
    private String ensureUniqueSlug(String baseSlug) {
        return ensureUniqueSlug(baseSlug, null);
    }
    
    /**
     * 確保路徑唯一性（排除指定ID）
     */
    private String ensureUniqueSlug(String baseSlug, Integer excludeId) {
        String slug = baseSlug;
        int counter = 1;
        
        while (tagRepository.existsBySlug(slug)) {
            // 如果是更新操作，檢查是否為當前標籤本身
            if (excludeId != null) {
                Optional<Tag> existing = tagRepository.findBySlug(slug);
                if (existing.isPresent() && existing.get().getTagId().equals(excludeId)) {
                    break;
                }
            }
            
            slug = baseSlug + "-" + counter;
            counter++;
        }
        
        return slug;
    }

    /**
     * 獲取所有標籤 (分頁)
     */
    @Transactional(readOnly = true)
    public Page<Tag> findAll(Pageable pageable) {
        return tagRepository.findAll(pageable);
    }

    /**
     * 根據文章 ID 查找標籤
     */
    @Transactional(readOnly = true)
    public List<Tag> findTagsByPost(Integer postId) {
        return tagRepository.findTagsByPostId(postId);
    }

    /**
     * 計算總標籤數量
     */
    public long countAll() {
        return tagRepository.count();
    }

    /**
     * 計算已使用的標籤數量
     */
    public long countUsedTags() {
        return tagRepository.countByUsageCountGreaterThan(0);
    }

    /**
     * 保存標籤（新增或更新）
     */
    public Tag save(Tag tag) {
        if (tag.getTagId() == null) {
            // 新增
            return createTag(tag);
        } else {
            // 更新
            return updateTag(tag.getTagId(), tag);
        }
    }

    /**
     * 根據ID刪除標籤
     */
    public void deleteById(Integer tagId) {
        deleteTag(tagId);
    }
} 