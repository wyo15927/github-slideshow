package com.blog.repository;

import com.blog.entity.Media;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * 媒體檔案資料存取介面
 */
@Repository
public interface MediaRepository extends JpaRepository<Media, Integer> {
    
    /**
     * 根據檔案名稱查找媒體檔案
     */
    Optional<Media> findByFileName(String fileName);
    
    /**
     * 檢查檔案名稱是否存在
     */
    boolean existsByFileName(String fileName);
    
    /**
     * 根據原始檔案名稱查找
     */
    List<Media> findByOriginalName(String originalName);
    
    /**
     * 根據檔案類型查找媒體檔案
     */
    Page<Media> findByFileType(String fileType, Pageable pageable);
    
    /**
     * 根據檔案類型前綴查找 (例如 'image/')
     */
    @Query("SELECT m FROM Media m WHERE m.fileType LIKE CONCAT(:typePrefix, '%')")
    Page<Media> findByFileTypeStartingWith(@Param("typePrefix") String typePrefix, Pageable pageable);
    
    /**
     * 根據上傳者查找媒體檔案
     */
    Page<Media> findByUploadedByUserId(Integer userId, Pageable pageable);
    
    /**
     * 根據檔案大小範圍查找
     */
    @Query("SELECT m FROM Media m WHERE m.fileSize BETWEEN :minSize AND :maxSize")
    Page<Media> findByFileSizeRange(@Param("minSize") Long minSize, 
                                    @Param("maxSize") Long maxSize, 
                                    Pageable pageable);
    
    /**
     * 查找圖片檔案 (有寬度和高度)
     */
    @Query("SELECT m FROM Media m WHERE m.width IS NOT NULL AND m.height IS NOT NULL")
    Page<Media> findImageFiles(Pageable pageable);
    
    /**
     * 根據圖片尺寸範圍查找
     */
    @Query("SELECT m FROM Media m WHERE " +
           "m.width BETWEEN :minWidth AND :maxWidth AND " +
           "m.height BETWEEN :minHeight AND :maxHeight")
    List<Media> findByImageSizeRange(@Param("minWidth") Integer minWidth,
                                     @Param("maxWidth") Integer maxWidth,
                                     @Param("minHeight") Integer minHeight,
                                     @Param("maxHeight") Integer maxHeight);
    
    /**
     * 搜尋媒體檔案 (根據檔案名稱、原始名稱或替代文字)
     */
    @Query("SELECT m FROM Media m WHERE " +
           "(:keyword IS NULL OR " +
           "m.fileName LIKE CONCAT('%', :keyword, '%') OR " +
           "m.originalName LIKE CONCAT('%', :keyword, '%') OR " +
           "m.altText LIKE CONCAT('%', :keyword, '%') OR " +
           "m.caption LIKE CONCAT('%', :keyword, '%'))")
    Page<Media> searchMediaFiles(@Param("keyword") String keyword, Pageable pageable);
    
    /**
     * 查找最新上傳的媒體檔案
     */
    @Query("SELECT m FROM Media m ORDER BY m.createdAt DESC")
    List<Media> findLatestMedia(Pageable pageable);
    
    /**
     * 查找指定時間範圍內上傳的媒體檔案
     */
    @Query("SELECT m FROM Media m WHERE m.createdAt BETWEEN :startDate AND :endDate ORDER BY m.createdAt DESC")
    List<Media> findMediaByDateRange(@Param("startDate") LocalDateTime startDate,
                                     @Param("endDate") LocalDateTime endDate);
    
    /**
     * 統計不同檔案類型的數量
     */
    @Query("SELECT m.fileType, COUNT(m) FROM Media m GROUP BY m.fileType ORDER BY COUNT(m) DESC")
    List<Object[]> countMediaByFileType();
    
    /**
     * 計算總檔案大小
     */
    @Query("SELECT SUM(m.fileSize) FROM Media m")
    Long calculateTotalFileSize();
    
    /**
     * 根據上傳者計算檔案大小
     */
    @Query("SELECT SUM(m.fileSize) FROM Media m WHERE m.uploadedBy.userId = :userId")
    Long calculateFileSizeByUser(@Param("userId") Integer userId);
    
    /**
     * 查找大檔案 (超過指定大小)
     */
    @Query("SELECT m FROM Media m WHERE m.fileSize > :sizeLimit ORDER BY m.fileSize DESC")
    List<Media> findLargeFiles(@Param("sizeLimit") Long sizeLimit, Pageable pageable);
    
    /**
     * 查找未使用的媒體檔案 (沒有在文章中使用)
     */
    @Query("SELECT m FROM Media m WHERE m.filePath NOT IN " +
           "(SELECT p.featuredImage FROM Post p WHERE p.featuredImage IS NOT NULL)")
    List<Media> findUnusedMediaFiles();
} 