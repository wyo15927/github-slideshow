package com.blog.entity;

/**
 * 評論狀態枚舉
 */
public enum CommentStatus {
    PENDING,   // 待審核
    APPROVED,  // 已核准
    REJECTED,  // 已拒絕
    SPAM       // 垃圾訊息
} 