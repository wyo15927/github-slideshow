package com.blog.controller;

import com.blog.dto.response.CategoryResponse;
import com.blog.entity.Category;
import com.blog.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 分類 REST API 控制器
 */
@RestController
@RequestMapping("/api/categories")
@CrossOrigin(origins = "*")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    /**
     * 獲取所有活躍分類
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> getAllActiveCategories() {
        try {
            List<Category> categories = categoryService.findActiveCategories();
            List<CategoryResponse> categoryResponses = categories.stream()
                .map(this::convertToCategoryResponse)
                .collect(Collectors.toList());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", categoryResponses);
            response.put("total", categoryResponses.size());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 根據 ID 獲取分類
     */
    @GetMapping("/{categoryId}")
    public ResponseEntity<CategoryResponse> getCategoryById(@PathVariable Integer categoryId) {
        Optional<Category> category = categoryService.findById(categoryId);
        if (category.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        CategoryResponse response = convertToCategoryResponse(category.get());
        return ResponseEntity.ok(response);
    }

    /**
     * 根據 slug 獲取分類
     */
    @GetMapping("/slug/{slug}")
    public ResponseEntity<CategoryResponse> getCategoryBySlug(@PathVariable String slug) {
        Optional<Category> category = categoryService.findBySlug(slug);
        if (category.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        CategoryResponse response = convertToCategoryResponse(category.get());
        return ResponseEntity.ok(response);
    }

    /**
     * 搜索分類
     */
    @GetMapping("/search")
    public ResponseEntity<Map<String, Object>> searchCategories(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "name") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {

        try {
            Sort sort = sortDir.equalsIgnoreCase("desc") ? 
                Sort.by(sortBy).descending() : 
                Sort.by(sortBy).ascending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Category> categoryPage = categoryService.searchCategories(keyword, pageable);

            List<CategoryResponse> categoryResponses = categoryPage.getContent().stream()
                .map(this::convertToCategoryResponse)
                .collect(Collectors.toList());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", categoryResponses);
            response.put("page", page);
            response.put("size", size);
            response.put("totalElements", categoryPage.getTotalElements());
            response.put("totalPages", categoryPage.getTotalPages());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 獲取分類統計資訊
     */
    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getCategoryStats() {
        try {
            long totalCategories = categoryService.countAll();
            long activeCategories = categoryService.countActive();

            Map<String, Object> stats = new HashMap<>();
            stats.put("totalCategories", totalCategories);
            stats.put("activeCategories", activeCategories);
            stats.put("inactiveCategories", totalCategories - activeCategories);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", stats);

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 創建新分類
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> createCategory(@RequestBody Category category) {
        try {
            Category savedCategory = categoryService.save(category);
            CategoryResponse response = convertToCategoryResponse(savedCategory);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("data", response);
            result.put("message", "分類創建成功");
            
            return ResponseEntity.ok(result);
            
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 更新分類
     */
    @PutMapping("/{categoryId}")
    public ResponseEntity<Map<String, Object>> updateCategory(
            @PathVariable Integer categoryId, 
            @RequestBody Category category) {
        try {
            Optional<Category> existingCategory = categoryService.findById(categoryId);
            if (existingCategory.isEmpty()) {
                return ResponseEntity.notFound().build();
            }
            
            // 更新分類資訊
            Category categoryToUpdate = existingCategory.get();
            categoryToUpdate.setName(category.getName());
            categoryToUpdate.setSlug(category.getSlug());
            categoryToUpdate.setDescription(category.getDescription());
            categoryToUpdate.setColor(category.getColor());
            categoryToUpdate.setIsActive(category.getIsActive());
            
            Category updatedCategory = categoryService.save(categoryToUpdate);
            CategoryResponse response = convertToCategoryResponse(updatedCategory);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("data", response);
            result.put("message", "分類更新成功");
            
            return ResponseEntity.ok(result);
            
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    /**
     * 刪除分類
     */
    @DeleteMapping("/{categoryId}")
    public ResponseEntity<Map<String, Object>> deleteCategory(@PathVariable Integer categoryId) {
        try {
            Optional<Category> category = categoryService.findById(categoryId);
            if (category.isEmpty()) {
                return ResponseEntity.notFound().build();
            }
            
            categoryService.deleteById(categoryId);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("message", "分類刪除成功");
            
            return ResponseEntity.ok(result);
            
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }

    // 私有輔助方法

    private CategoryResponse convertToCategoryResponse(Category category) {
        CategoryResponse response = new CategoryResponse();
        response.setCategoryId(category.getCategoryId());
        response.setName(category.getName());
        response.setDescription(category.getDescription());
        response.setSlug(category.getSlug());
        response.setColor(category.getColor());
        response.setIsActive(category.getIsActive());
        response.setCreatedAt(category.getCreatedAt());
        
        // 設置文章數量
        Long postCount = categoryService.countPostsByCategory(category.getCategoryId());
        response.setPostCount(postCount);

        return response;
    }

    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        return response;
    }
} 