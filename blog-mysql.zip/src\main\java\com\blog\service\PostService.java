package com.blog.service;

import com.blog.entity.Post;
import com.blog.entity.PostStatus;
import com.blog.entity.User;
import com.blog.entity.Category;
import com.blog.entity.Tag;
import com.blog.repository.PostRepository;
import com.blog.repository.UserRepository;
import com.blog.repository.CategoryRepository;
import com.blog.repository.TagRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * 文章業務邏輯服務
 */
@Service
@Transactional
public class PostService {
    
    @Autowired
    private PostRepository postRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private CategoryRepository categoryRepository;
    
    @Autowired
    private TagRepository tagRepository;
    
    /**
     * 查找所有已發布的文章
     */
    @Transactional(readOnly = true)
    public Page<Post> findPublishedPosts(int page, int size, String sortBy) {
        Pageable pageable = createPageable(page, size, sortBy);
        return postRepository.findPublishedPosts(LocalDateTime.now(), pageable);
    }
    
    /**
     * 根據ID查找文章
     */
    @Transactional(readOnly = true)
    public Optional<Post> findById(Integer postId) {
        return postRepository.findByIdWithAssociations(postId);
    }
    
    /**
     * 根據路徑查找文章
     */
    @Transactional(readOnly = true)
    public Optional<Post> findBySlug(String slug) {
        return postRepository.findBySlug(slug);
    }
    
    /**
     * 創建新文章
     */
    public Post createPost(Post post, Integer authorId) {
        return createPost(post, authorId, null, null);
    }
    
    
/**
 * 創建新文章（帶分類和標籤）
 */
public Post createPost(Post post, Integer authorId, Integer categoryId, List<String> tagNames) {
    // 查找作者
    User author = userRepository.findById(authorId)
        .orElseThrow(() -> new RuntimeException("User not found with ID: " + authorId));
    
    post.setAuthor(author);
    
    // 設置分類 - 修復：允許分類為空
    if (categoryId != null) {
        Optional<Category> categoryOpt = categoryRepository.findById(categoryId);
        if (categoryOpt.isPresent()) {
            post.setCategory(categoryOpt.get());
        } else {
            // 分類不存在時不拋出異常，而是記錄警告並繼續
            System.out.println("Warning: Category not found with ID: " + categoryId);
        }
    }
    
    // 如果沒有設定路徑，生成一個
    if (post.getSlug() == null || post.getSlug().isEmpty()) {
        post.setSlug(generateSlug(post.getTitle()));
    }
    
    // 確保路徑唯一
    post.setSlug(ensureUniqueSlug(post.getSlug()));
    
    // 設置創建和更新時間
    LocalDateTime now = LocalDateTime.now();
    post.setCreatedAt(now);
    post.setUpdatedAt(now);
    
    // 如果狀態是發布，設置發布時間
    if (post.getStatus() == PostStatus.PUBLISHED) {
        post.setPublishedAt(now);
    }
    
    // 保存文章
    Post savedPost = postRepository.save(post);
    
    // 處理標籤關聯
    if (tagNames != null && !tagNames.isEmpty()) {
        handlePostTags(savedPost, tagNames);
    }
    
    return savedPost;
}

    /**
     * 更新文章（帶分類和標籤）
     */
    public Post updatePost(Integer postId, Post updatedPost, Integer categoryId, List<String> tagNames) {
        Post existingPost = postRepository.findById(postId)
            .orElseThrow(() -> new RuntimeException("文章不存在"));
        
        // 更新基本欄位
        existingPost.setTitle(updatedPost.getTitle());
        existingPost.setContent(updatedPost.getContent());
        existingPost.setExcerpt(updatedPost.getExcerpt());
        existingPost.setFeaturedImage(updatedPost.getFeaturedImage());
        existingPost.setStatus(updatedPost.getStatus());
        existingPost.setIsCommentEnabled(updatedPost.getIsCommentEnabled());
        existingPost.setIsFeatured(updatedPost.getIsFeatured());
        existingPost.setMetaTitle(updatedPost.getMetaTitle());
        existingPost.setMetaDescription(updatedPost.getMetaDescription());
        existingPost.setMetaKeywords(updatedPost.getMetaKeywords());
        
        // ✅ 更新分類
        if (categoryId != null) {
            Optional<Category> categoryOpt = categoryRepository.findById(categoryId);
            if (categoryOpt.isPresent()) {
                existingPost.setCategory(categoryOpt.get());
            } else {
                System.out.println("Warning: Category not found with ID: " + categoryId);
            }
        } else {
            // 如果 categoryId 為 null，清除分類
            existingPost.setCategory(null);
        }
        
        // 如果狀態改為發布，設定發布時間
        if (updatedPost.getStatus().name().equals("PUBLISHED") && existingPost.getPublishedAt() == null) {
            existingPost.setPublishedAt(LocalDateTime.now());
        }
        
        existingPost.setUpdatedAt(LocalDateTime.now());
        
        // 保存文章
        Post savedPost = postRepository.save(existingPost);
        
        // ✅ 處理標籤關聯
        if (tagNames != null) {
            handlePostTags(savedPost, tagNames);
        }
        
        return savedPost;
    }
    
    /**
     * 更新文章（不帶分類和標籤，保留舊方法以兼容）
     */
    public Post updatePost(Integer postId, Post updatedPost) {
        return updatePost(postId, updatedPost, null, null);
    }
    
    /**
     * 發布文章
     */
    public Post publishPost(Integer postId) {
        Post post = postRepository.findById(postId)
            .orElseThrow(() -> new RuntimeException("文章不存在"));
        
        post.setStatus(PostStatus.PUBLISHED);
        post.setPublishedAt(LocalDateTime.now());
        
        return postRepository.save(post);
    }
    
    /**
     * 刪除文章
     */
    public void deletePost(Integer postId) {
        if (!postRepository.existsById(postId)) {
            throw new RuntimeException("文章不存在");
        }
        postRepository.deleteById(postId);
    }
    
    /**
     * 增加文章瀏覽次數
     */
    public void incrementViewCount(Integer postId) {
        postRepository.incrementViewCount(postId);
    }
    
    /**
     * 增加文章按讚次數
     */
    public void incrementLikeCount(Integer postId) {
        postRepository.incrementLikeCount(postId);
    }

    /**
     * 減少文章按讚次數
     */
    public void decrementLikeCount(Integer postId) {
        postRepository.decrementLikeCount(postId);
    }
    
    /**
     * 根據分類查找已發布文章
     */
    @Transactional(readOnly = true)
    public Page<Post> findPublishedPostsByCategory(Integer categoryId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "publishedAt"));
        return postRepository.findPublishedPostsByCategory(categoryId, LocalDateTime.now(), pageable);
    }
    
    /**
     * 根據標籤查找已發布文章
     */
    @Transactional(readOnly = true)
    public Page<Post> findPublishedPostsByTag(Integer tagId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "publishedAt"));
        return postRepository.findPublishedPostsByTag(tagId, LocalDateTime.now(), pageable);
    }
    
    /**
     * 搜尋已發布文章
     */
    @Transactional(readOnly = true)
    public Page<Post> searchPublishedPosts(String keyword, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "publishedAt"));
        return postRepository.searchPublishedPosts(keyword, LocalDateTime.now(), pageable);
    }
    
    /**
     * 查找精選文章
     */
    @Transactional(readOnly = true)
    public List<Post> findFeaturedPosts(int limit) {
        Pageable pageable = PageRequest.of(0, limit);
        return postRepository.findFeaturedPosts(LocalDateTime.now(), pageable);
    }
    
    /**
     * 查找最新文章
     */
    @Transactional(readOnly = true)
    public List<Post> findLatestPosts(int limit) {
        Pageable pageable = PageRequest.of(0, limit);
        return postRepository.findLatestPosts(LocalDateTime.now(), pageable);
    }
    

    
    /**
     * 查找相關文章
     */
    @Transactional(readOnly = true)
    public List<Post> findRelatedPosts(Integer postId, int limit) {
        Post post = findById(postId).orElse(null);
        if (post == null || post.getCategory() == null) {
            return List.of();
        }
        
        Pageable pageable = PageRequest.of(0, limit);
        return postRepository.findRelatedPosts(
            post.getCategory().getCategoryId(), 
            postId, 
            LocalDateTime.now(), 
            pageable
        );
    }
    
    /**
     * 根據作者查找文章
     */
    @Transactional(readOnly = true)
    public Page<Post> findPostsByAuthor(Integer authorId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return postRepository.findByAuthorUserId(authorId, pageable);
    }
    
    /**
     * 根據作者用戶名查找已發布的文章
     */
    @Transactional(readOnly = true)
    public Page<Post> findPublishedPostsByAuthorUsername(String username, int page, int size, String sortBy) {
        Pageable pageable = createPageable(page, size, sortBy);
        return postRepository.findPublishedPostsByAuthorUsername(username, LocalDateTime.now(), pageable);
    }
    
    /**
     * 根據分類名稱或slug查找已發布文章
     */
    @Transactional(readOnly = true)
    public Page<Post> findPublishedPostsByCategoryNameOrSlug(String categoryNameOrSlug, int page, int size, String sortBy) {
        Pageable pageable = createPageable(page, size, sortBy);
        return postRepository.findPublishedPostsByCategoryNameOrSlug(categoryNameOrSlug, LocalDateTime.now(), pageable);
    }
    
    // 私有輔助方法
    
    /**
     * 創建分頁對象
     */
    private Pageable createPageable(int page, int size, String sortBy) {
        Sort.Direction direction = Sort.Direction.DESC;
        String property;
        
        switch (sortBy.toLowerCase()) {
            case "latest":
                property = "publishedAt";
                break;

            case "likes":
                property = "likeCount";
                break;
            case "title":
                property = "title";
                direction = Sort.Direction.ASC;
                break;
            default:
                property = "publishedAt";
        }
        
        return PageRequest.of(page, size, Sort.by(direction, property));
    }
    
    /**
     * 生成文章路徑
     */
    private String generateSlug(String title) {
        return title.toLowerCase()
                .replaceAll("[^a-z0-9\\u4e00-\\u9fff\\s-]", "") // 保留中文、英文、數字、空格和連字符
                .replaceAll("\\s+", "-") // 空格替換為連字符
                .replaceAll("-+", "-") // 多個連字符合併為一個
                .replaceAll("^-|-$", ""); // 移除開頭和結尾的連字符
    }
    
    /**
     * 確保路徑唯一性
     */
    private String ensureUniqueSlug(String baseSlug) {
        String slug = baseSlug;
        int counter = 1;
        
        while (postRepository.existsBySlug(slug)) {
            slug = baseSlug + "-" + counter;
            counter++;
        }
        
        return slug;
    }
    
    /**
     * 處理文章標籤關聯
     */
    private void handlePostTags(Post post, List<String> tagNames) {
        List<Tag> tags = new ArrayList<>();
        
        for (String tagName : tagNames) {
            // 查找或創建標籤
            Tag tag = tagRepository.findByName(tagName)
                .orElseGet(() -> {
                    Tag newTag = new Tag();
                    newTag.setName(tagName);
                    newTag.setSlug(generateSlug(tagName));
                    return tagRepository.save(newTag);
                });
            
            tags.add(tag);
        }
        
        // 設置文章標籤
        post.setTags(tags);
        postRepository.save(post);
    }
} 