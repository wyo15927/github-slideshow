package com.blog.controller;

import com.blog.dto.request.LoginRequest;
import com.blog.dto.request.RegisterRequest;
import com.blog.dto.response.UserResponse;
import com.blog.entity.User;
import com.blog.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Authentication REST API Controller
 */
@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {
    
    @Autowired
    private UserService userService;
    
    /**
     * User Login
     */
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@Valid @RequestBody LoginRequest request) {
        try {
            System.out.println("Login attempt - Username: " + request.getUsername());
            
            // Check if user exists
            Optional<User> userExists = userService.findByUsername(request.getUsername());
            if (userExists.isEmpty()) {
                System.out.println("User not found: " + request.getUsername());
                return ResponseEntity.badRequest()
                    .body(createErrorResponse("使用者不存在"));
            }
            
            System.out.println("Found user: " + userExists.get().getUsername() + ", Role: " + userExists.get().getRole());
            
            Optional<User> userOpt = userService.authenticate(request.getUsername(), request.getPassword());
            
            if (userOpt.isEmpty()) {
                System.out.println("Password verification failed");
                return ResponseEntity.badRequest()
                    .body(createErrorResponse("密碼錯誤"));
            }
            
            User user = userOpt.get();
            UserResponse userResponse = convertToUserResponse(user);
            
            // TODO: Generate JWT Token
            // Temporary simple token format: username:timestamp
            String token = user.getUsername() + ":" + System.currentTimeMillis();
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Login successful");
            response.put("token", token);
            response.put("user", userResponse);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(createErrorResponse(e.getMessage()));
        }
    }
    
    /**
     * User Logout
     */
    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout() {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "Logout successful");
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get Current User Information
     */
    @GetMapping("/me")
    public ResponseEntity<UserResponse> getCurrentUser(HttpServletRequest request) {
        try {
            // Get token from Authorization header
            String authHeader = request.getHeader("Authorization");
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.status(401).body(null);
            }
            
            String token = authHeader.substring(7); // Remove "Bearer " prefix
            
            // Here we should parse JWT token to get user information
            // Temporarily using a simple method: extract username from token
            // In production environment, should use JWT parsing library
            
            // Simple token validation (temporary solution)
            if (token == null || token.isEmpty()) {
                return ResponseEntity.status(401).body(null);
            }
            
            // Extract username from token (assume token format is "username:timestamp")
            String[] tokenParts = token.split(":");
            if (tokenParts.length < 1) {
                return ResponseEntity.status(401).body(null);
            }
            
            String username = tokenParts[0];
            
            // Find user
            Optional<User> user = userService.findByUsername(username);
            if (user.isEmpty()) {
                return ResponseEntity.notFound().build();
            }
            
            UserResponse response = convertToUserResponse(user.get());
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }
    
    // Private helper methods
    
    private UserResponse convertToUserResponse(User user) {
        UserResponse response = new UserResponse();
        response.setUserId(user.getUserId());
        response.setUsername(user.getUsername());
        response.setEmail(user.getEmail());
        response.setDisplayName(user.getDisplayName());
        response.setAvatar(user.getAvatar());
        response.setProfession(user.getProfession());
        response.setBio(user.getBio());
        response.setLocation(user.getLocation());
        response.setWebsite(user.getWebsite());
        response.setRole(user.getRole().name());
        response.setIsActive(user.getIsActive());
        response.setCreatedAt(user.getCreatedAt());
        response.setLastLoginAt(user.getLastLoginAt());
        
        return response;
    }
    
    /**
     * User Registration
     */
    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@Valid @RequestBody RegisterRequest request) {
        try {
            System.out.println("Registration request - Username: " + request.getUsername() + ", Email: " + request.getEmail());
            
            // Validate password confirmation
            if (!request.getPassword().equals(request.getConfirmPassword())) {
                System.out.println("Password confirmation failed");
                return ResponseEntity.badRequest().body(createErrorResponse("Password confirmation mismatch"));
            }
            
            // Register user
            User user = userService.registerUser(
                request.getUsername(),
                request.getEmail(),
                request.getPassword(),
                request.getDisplayName()
            );
            
            System.out.println("Registration successful - User ID: " + user.getUserId());
            
            // Create success response
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Registration successful! Welcome to our blog platform");
            response.put("user", convertToUserResponse(user));
            
            return ResponseEntity.ok(response);
            
        } catch (RuntimeException e) {
            System.out.println("Registration failed: " + e.getMessage());
            return ResponseEntity.badRequest().body(createErrorResponse(e.getMessage()));
        } catch (Exception e) {
            System.out.println("Unexpected error during registration: " + e.getMessage());
            return ResponseEntity.status(500).body(createErrorResponse("Registration failed, please try again later"));
        }
    }
    
    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        return response;
    }
} 