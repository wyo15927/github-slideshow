/**
 * 部落格應用主程序
 * 處理文章載入、導航、用戶認證等功能
 */

class BlogAppClass {
    constructor() {
        this.currentPostId = null;
        // 不在建構函式中立即初始化，等待 DOM 載入完成
    }
    
    init() {
        this.onDOMReady();
        this.initSearchForm();
    }
    
    // 初始化搜索表單
    initSearchForm() {
        const searchForm = document.getElementById('search-form');
        if (searchForm) {
            searchForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const searchInput = document.getElementById('search-input');
                const keyword = searchInput.value.trim();
                if (keyword) {
                    this.searchPosts(keyword);
                }
            });
        }
    }
    
    // DOM 載入完成後初始化
    onDOMReady() {
        console.log('BlogAppClass.onDOMReady 開始執行');
        
        // 載入系統設定
        this.loadSystemSettings();
        
        // 監聽系統設定變更事件
        window.addEventListener('systemSettingsChanged', (event) => {
            this.loadSystemSettings();
        });
        
        // 檢查 URL 參數
        const urlParams = new URLSearchParams(window.location.search);
        const author = urlParams.get('author');
        const authorPosts = urlParams.get('authorPosts');
        const postSlug = urlParams.get('post');
        const page = urlParams.get('page');
        
        console.log('URL 參數:', { author, authorPosts, postSlug, page });
        
        if (postSlug) {
            console.log('載入文章詳情:', postSlug);
            setTimeout(() => this.viewPost(postSlug), 100);
        } else if (authorPosts) {
            console.log('載入作者文章列表:', authorPosts);
            setTimeout(() => this.loadAuthorPosts(authorPosts), 100);
        } else if (author) {
            console.log('載入作者資料:', author);
            setTimeout(() => this.viewAuthorProfile(author), 100);
        } else if (page === 'home') {
            // 強制顯示首頁
            console.log('強制顯示首頁');
            setTimeout(() => this.loadPosts(), 100);
        } else if (page === 'my-posts') {
            // 強制顯示個人頁面
            console.log('強制顯示個人頁面');
            setTimeout(() => this.loadMyPosts(), 100);
        } else {
            // ✅ 默認始終顯示首頁（所有文章）
            console.log('默認載入首頁（所有文章）');
            setTimeout(() => this.loadPosts(), 100);
        }
        
        // 載入側邊欄資料（異步載入，不阻塞主要內容）
        setTimeout(() => this.loadSidebarData(), 200);
        
        // 初始化關於我區塊
        setTimeout(() => {
            if (window.aboutMeWidget) {
                window.aboutMeWidget.init();
            }
        }, 300);
        
        // 延遲初始化認證狀態，確保用戶信息已載入
        setTimeout(() => {
            console.log('延遲執行認證狀態初始化');
            this.initializeAuth();
        }, 500);
        
        // 額外檢查 AuthManager 是否準備好
        setTimeout(() => {
            console.log('檢查 AuthManager 準備狀態:', {
                exists: !!window.AuthManager,
                isInitialized: window.AuthManager ? window.AuthManager.isInitialized : 'N/A'
            });
        }, 1000);
        
        console.log('BlogAppClass.onDOMReady 執行完成');
    }
    
    // 載入系統設定
    loadSystemSettings() {
        try {
            // 從 localStorage 讀取系統設定
            const settings = JSON.parse(localStorage.getItem('systemSettings')) || {};
            
            // 更新頁面標題
            const siteTitle = settings.siteTitle || '我的個人部落格';
            document.title = siteTitle;
            
            // 更新導航列品牌名稱
            const navbarBrand = document.querySelector('.navbar-brand');
            if (navbarBrand) {
                const icon = navbarBrand.querySelector('i');
                navbarBrand.innerHTML = '';
                if (icon) navbarBrand.appendChild(icon);
                navbarBrand.appendChild(document.createTextNode(siteTitle));
            }
            
            // 更新 meta 描述
            const siteDescription = settings.siteDescription || '分享技術心得與生活感想';
            const metaDescription = document.querySelector('meta[name="description"]');
            if (metaDescription) {
                metaDescription.setAttribute('content', siteDescription);
            }
            
            // 更新 Open Graph 標題和描述
            const ogTitle = document.querySelector('meta[property="og:title"]');
            if (ogTitle) {
                ogTitle.setAttribute('content', siteTitle);
            }
            
            const ogDescription = document.querySelector('meta[property="og:description"]');
            if (ogDescription) {
                ogDescription.setAttribute('content', siteDescription);
            }
            
            // 更新 Twitter 標題和描述
            const twitterTitle = document.querySelector('meta[property="twitter:title"]');
            if (twitterTitle) {
                twitterTitle.setAttribute('content', siteTitle);
            }
            
            const twitterDescription = document.querySelector('meta[property="twitter:description"]');
            if (twitterDescription) {
                twitterDescription.setAttribute('content', siteDescription);
            }
            
        } catch (error) {
            console.error('載入系統設定失敗:', error);
        }
    }
    
    // 檢查是否為管理員用戶（僅限 admin 帳號）
    isAdminUser() {
        const userInfo = this.getCurrentUserInfo();
        console.log('檢查管理員權限，用戶信息:', userInfo);
        const isAdmin = userInfo?.username === 'admin';
        console.log('是否為管理員:', isAdmin);
        return isAdmin;
    }

    // 檢查用戶是否可以編輯文章
    canEditPost(post) {
        try {
            // 檢查是否已登入
            if (!window.AuthManager || !window.AuthManager.isLoggedIn()) {
                console.log('❌ 用戶未登入，無編輯權限');
                return false;
            }

            const userInfo = this.getCurrentUserInfo();
            if (!userInfo || !userInfo.username) {
                console.log('❌ 無法獲取用戶信息，無編輯權限');
                return false;
            }

            // 管理員可以編輯所有文章
            if (userInfo.username === 'admin' || userInfo.role === 'ADMIN') {
                console.log('✅ 管理員用戶，有編輯權限');
                return true;
            }

            // 檢查是否是文章作者
            const postAuthor = post.author?.username || post.authorName || post.author;
            const canEdit = userInfo.username === postAuthor;
            
            console.log('🔍 檢查編輯權限:', {
                currentUser: userInfo.username,
                userRole: userInfo.role,
                postAuthor: postAuthor,
                postData: post,
                canEdit: canEdit
            });
            
            if (!canEdit) {
                console.log('❌ 非文章作者，無編輯權限');
            }
            
            return canEdit;
        } catch (error) {
            console.error('❌ 檢查編輯權限失敗:', error);
            return false;
        }
    }
    
    // 初始化認證狀態
    initializeAuth() {
        console.log('=== 初始化認證狀態 ===');
        const isLoggedIn = window.AuthManager ? window.AuthManager.isLoggedIn() : false;
        console.log('登入狀態:', isLoggedIn);
        
        // 隱藏/顯示登入註冊連結
        const loginLink = document.getElementById('login-link');
        const registerLink = document.getElementById('register-link');
        const userDivider = document.getElementById('user-divider');
        const myPostsLink = document.getElementById('my-posts-link');
        const profileSettingsLink = document.getElementById('profile-settings-link');
        const writeArticleLink = document.getElementById('write-link');
        const adminLink = document.getElementById('admin-link');
        const adminDivider = document.getElementById('admin-divider');
        const logoutLink = document.getElementById('logout-link');
        
        console.log('DOM 元素檢查:', {
            writeArticleLink: !!writeArticleLink,
            adminLink: !!adminLink,
            adminDivider: !!adminDivider,
            loginLink: !!loginLink,
            myPostsLink: !!myPostsLink
        });
        
        if (isLoggedIn) {
            // 已登入用戶
            if (loginLink) loginLink.style.display = 'none';
            if (registerLink) registerLink.style.display = 'none';
            if (userDivider) userDivider.style.display = 'block';
            if (myPostsLink) myPostsLink.style.display = 'block';
            if (profileSettingsLink) profileSettingsLink.style.display = 'block';
            
            // 所有登入用戶都可以撰寫文章
            if (writeArticleLink) writeArticleLink.style.display = 'block';
            
            // 檢查是否為管理員（僅限 admin 帳號）
            if (this.isAdminUser()) {
                console.log('顯示管理員功能 - 管理後台');
                // 管理員額外顯示管理後台
                if (adminLink) adminLink.style.display = 'block';
                if (adminDivider) adminDivider.style.display = 'block';
            } else {
                console.log('隱藏管理後台功能');
                // 一般用戶隱藏管理後台
                if (adminLink) adminLink.style.display = 'none';
                if (adminDivider) adminDivider.style.display = 'none';
            }
            
            if (logoutLink) {
                logoutLink.style.display = 'block';
                // 綁定登出事件
                this.bindLogoutEvent(logoutLink);
            }
        } else {
            // 未登入用戶
            console.log('未登入用戶，顯示登入/註冊按鈕');
            if (loginLink) {
                loginLink.style.display = 'block';
                console.log('✅ 顯示登入按鈕');
            } else {
                console.error('❌ 找不到登入按鈕元素');
            }
            if (registerLink) {
                registerLink.style.display = 'block';
                console.log('✅ 顯示註冊按鈕');
            } else {
                console.error('❌ 找不到註冊按鈕元素');
            }
            if (userDivider) userDivider.style.display = 'none';
            if (myPostsLink) myPostsLink.style.display = 'none';
            if (profileSettingsLink) profileSettingsLink.style.display = 'none';
            if (writeArticleLink) writeArticleLink.style.display = 'none';
            if (adminLink) adminLink.style.display = 'none';
            if (adminDivider) adminDivider.style.display = 'none';
            if (logoutLink) logoutLink.style.display = 'none';
        }
        
        console.log('=== 認證狀態初始化完成 ===');
        
        // 觸發認證狀態變化事件
        window.dispatchEvent(new CustomEvent('authStateChanged', {
            detail: { isLoggedIn: isLoggedIn }
        }));
    }
    
    // 重新檢查權限（可用於登入後或權限變更後）
    refreshPermissions() {
        console.log('=== 手動重新檢查權限 ===');
        // 確保用戶信息是最新的
        const userInfo = this.getCurrentUserInfo();
        console.log('手動檢查時的用戶信息:', userInfo);
        this.initializeAuth();
    }
    
    // 載入文章列表
    async loadPosts() {
        try {
            console.log('=== 開始載入文章 ===');
            
            // 先確保容器存在
            const postsContainer = document.querySelector('#posts-container');
            const loadingElement = document.querySelector('#loading');
            
            console.log('文章容器:', postsContainer);
            console.log('載入元素:', loadingElement);
            
            if (!postsContainer) {
                console.error('找不到 posts-container 元素！');
                return;
            }
            
            // 清空容器並顯示載入狀態
            postsContainer.innerHTML = '';
            if (loadingElement) {
                loadingElement.style.display = 'block';
            }
            
            // 檢查是否已登入，如果已登入則顯示首頁標題和切換按鈕
            const isLoggedIn = window.AuthManager.isLoggedIn();
            console.log('登入狀態:', isLoggedIn);
            if (isLoggedIn) {
                // 重新檢查權限，確保管理員功能正確顯示
                console.log('首頁載入時重新檢查權限');
                this.initializeAuth();
                this.showHomePageHeader();
            } else {
                // 未登入用戶，清空容器準備顯示文章
                console.log('未登入用戶，清空文章容器');
                postsContainer.innerHTML = '';
            }
            
            // 載入文章數據（DataLoader 會自動處理 API 失敗並返回 mock 數據）
            console.log('從 DataLoader 載入文章...');
            const posts = await DataLoader.loadPosts(1, true);
            console.log('載入完成，文章數量:', posts?.length);
            console.log('文章數據:', posts);
            
            // 隱藏載入狀態
            if (loadingElement) {
                console.log('隱藏並移除載入元素');
                loadingElement.style.display = 'none';
                setTimeout(() => {
                    if (loadingElement.parentNode) {
                        loadingElement.remove();
                    }
                }, 100);
            }
            
            // 渲染文章
            console.log('開始渲染文章...');
            this.renderPosts(posts);
            console.log('=== 文章載入完成 ===');
            
        } catch (error) {
            console.error('載入文章完全失敗:', error);
            Utils.showToast('載入文章失敗，請稍後再試', 'danger');
            
            // 確保在錯誤時也隱藏 loading
            const loadingElement = document.querySelector('#loading');
            if (loadingElement) {
                loadingElement.style.display = 'none';
            }
            
            // 顯示錯誤信息
            const postsContainer = document.querySelector('#posts-container');
            if (postsContainer) {
                postsContainer.innerHTML = `
                    <div class="col-12 text-center py-5">
                        <div class="text-danger">
                            <i class="fas fa-exclamation-triangle fa-3x mb-3"></i>
                            <h4>載入失敗</h4>
                            <p>無法載入文章，請檢查網絡連接或稍後再試</p>
                            <button class="btn btn-primary" onclick="BlogApp.loadPosts()">
                                <i class="fas fa-redo me-1"></i>重新載入
                            </button>
                        </div>
                    </div>
                `;
            }
        }
    }
    
    // 搜索文章
    async searchPosts(keyword) {
        try {
            console.log('=== 開始搜索文章 ===', keyword);
            
            // 先確保容器存在
            const postsContainer = document.querySelector('#posts-container');
            const loadingElement = document.querySelector('#loading');
            
            if (!postsContainer) {
                console.error('找不到 posts-container 元素！');
                return;
            }
            
            // 清空容器並顯示載入狀態
            postsContainer.innerHTML = '';
            if (loadingElement) {
                loadingElement.style.display = 'block';
            }
            
            // 添加搜索結果標題
            const searchHeader = `
                <div class="col-12 mb-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h2 class="fw-bold mb-2">
                                <i class="fas fa-search me-2 text-primary"></i>搜索結果
                            </h2>
                            <p class="text-muted mb-0">關鍵字：「${keyword}」</p>
                        </div>
                        <div>
                            <button class="btn btn-outline-primary" onclick="document.getElementById('search-input').value=''; BlogApp.loadPosts();">
                                <i class="fas fa-times me-1"></i>清除搜索
                            </button>
                        </div>
                    </div>
                </div>
            `;
            postsContainer.innerHTML = searchHeader;
            
            // 調用搜索 API
            console.log('調用搜索 API...');
            const response = await BlogAPI.posts.search(keyword);
            const posts = response.content || response.data || response || [];
            console.log('搜索完成，文章數量:', posts?.length);
            
            // 隱藏載入狀態
            if (loadingElement) {
                loadingElement.style.display = 'none';
                setTimeout(() => {
                    if (loadingElement.parentNode) {
                        loadingElement.remove();
                    }
                }, 100);
            }
            
            // 渲染搜索結果
            if (!posts || posts.length === 0) {
                postsContainer.insertAdjacentHTML('beforeend', `
                    <div class="col-12 text-center py-5">
                        <div class="text-muted">
                            <i class="fas fa-search fa-3x mb-3"></i>
                            <h4>未找到相關文章</h4>
                            <p>沒有找到包含「${keyword}」的文章</p>
                            <button class="btn btn-primary" onclick="document.getElementById('search-input').value=''; BlogApp.loadPosts();">
                                <i class="fas fa-home me-1"></i>返回首頁
                            </button>
                        </div>
                    </div>
                `);
            } else {
                const postsHtml = posts.map(post => Renderers.renderPostCard(post)).join('');
                postsContainer.insertAdjacentHTML('beforeend', postsHtml);
                
                // 顯示搜索統計
                const statsHtml = `
                    <div class="col-12 mt-3 text-center">
                        <p class="text-muted">共找到 ${posts.length} 篇相關文章</p>
                    </div>
                `;
                postsContainer.insertAdjacentHTML('beforeend', statsHtml);
            }
            
            console.log('=== 搜索完成 ===');
            
        } catch (error) {
            console.error('搜索文章失敗:', error);
            Utils.showToast('搜索失敗，請稍後再試', 'danger');
            
            // 確保在錯誤時也隱藏 loading
            const loadingElement = document.querySelector('#loading');
            if (loadingElement) {
                loadingElement.style.display = 'none';
            }
            
            // 顯示錯誤信息
            const postsContainer = document.querySelector('#posts-container');
            if (postsContainer) {
                postsContainer.innerHTML = `
                    <div class="col-12 text-center py-5">
                        <div class="text-danger">
                            <i class="fas fa-exclamation-triangle fa-3x mb-3"></i>
                            <h4>搜索失敗</h4>
                            <p>無法完成搜索，請檢查網絡連接或稍後再試</p>
                            <button class="btn btn-primary" onclick="BlogApp.loadPosts()">
                                <i class="fas fa-home me-1"></i>返回首頁
                            </button>
                        </div>
                    </div>
                `;
            }
        }
    }
    
    // 渲染文章列表
    renderPosts(posts) {
        console.log('=== 開始渲染文章 ===');
        console.log('文章數量:', posts?.length);
        console.log('文章內容:', posts);
        
        const postsContainer = document.querySelector('#posts-container');
        const loadingElement = document.querySelector('#loading');
        
        console.log('Posts container:', postsContainer);
        console.log('Loading element:', loadingElement);
        
        if (!postsContainer) {
            console.error('找不到 posts-container 元素');
            return;
        }
        
        // 隱藏 loading 元素
        if (loadingElement) {
            console.log('隱藏 loading 元素');
            loadingElement.style.display = 'none';
            setTimeout(() => {
                if (loadingElement.parentNode) {
                    loadingElement.remove();
                }
            }, 100);
        }
        
        if (!posts || posts.length === 0) {
            console.log('沒有文章可顯示');
            // 檢查是否已經有標題（個人頁面或首頁標題）
            const existingHeader = postsContainer.querySelector('.col-12.mb-4');
            if (existingHeader) {
                // 保留標題，只添加無文章信息
                postsContainer.insertAdjacentHTML('beforeend', `
                    <div class="col-12 text-center py-5">
                        <div class="text-muted">
                            <i class="fas fa-newspaper fa-3x mb-3"></i>
                            <h4>暫無文章</h4>
                            <p>目前沒有可顯示的文章</p>
                        </div>
                    </div>
                `);
            } else {
                // 沒有標題，顯示完整的無文章頁面
                postsContainer.innerHTML = `
                    <div class="col-12 text-center py-5">
                        <div class="text-muted">
                            <i class="fas fa-newspaper fa-3x mb-3"></i>
                            <h4>暫無文章</h4>
                            <p>目前沒有可顯示的文章</p>
                        </div>
                    </div>
                `;
            }
            return;
        }
        
        console.log('開始生成文章 HTML');
        const postsHtml = posts.map(post => {
            console.log('渲染文章:', post.title);
            return Renderers.renderPostCard(post);
        }).join('');
        
        console.log('文章 HTML 生成完成，長度:', postsHtml.length);
        console.log('生成的 HTML 預覽:', postsHtml.substring(0, 200) + '...');
        
        // 檢查是否已經有標題（個人頁面或首頁標題）
        console.log('檢查現有標題，當前容器內容:', postsContainer.innerHTML);
        const existingHeader = postsContainer.querySelector('.col-12.mb-4');
        console.log('找到的標題元素:', existingHeader);
        if (existingHeader) {
            console.log('保留現有標題，將文章添加到 row 容器中');
            // 保留標題，直接將文章添加到 row 容器的後面
            postsContainer.insertAdjacentHTML('beforeend', postsHtml);
        } else {
            console.log('沒有現有標題，直接顯示文章');
            // 沒有標題，直接顯示文章
            // posts-container 現在本身就是 row，直接添加文章
            postsContainer.innerHTML = postsHtml;
        }
        
        console.log('文章渲染完成，容器內容:', postsContainer.innerHTML.length);
        
        // 調試並強制顯示文章卡片
        const articleElements = postsContainer.querySelectorAll('.post-card');
        console.log('找到的文章元素數量:', articleElements.length);
        
        if (articleElements.length > 0) {
            const firstArticle = articleElements[0];
            console.log('第一個文章元素:', firstArticle);
            console.log('第一個文章元素的可見性:', {
                display: window.getComputedStyle(firstArticle).display,
                visibility: window.getComputedStyle(firstArticle).visibility,
                opacity: window.getComputedStyle(firstArticle).opacity,
                height: window.getComputedStyle(firstArticle).height,
                width: window.getComputedStyle(firstArticle).width
            });
        }
        
        // 強制顯示所有文章卡片（修正透明度問題）
        console.log('強制顯示文章，找到文章數量:', articleElements.length);
        articleElements.forEach((article, index) => {
            console.log(`設置第 ${index + 1} 個文章可見`);
            article.style.opacity = '1';
            article.style.transform = 'translateY(0)';
            article.style.visibility = 'visible';
            article.style.display = 'flex';
        });
        
        console.log('=== 渲染完成 ===');
        
        // 顯示成功消息
        Utils.showToast(`成功載入 ${posts.length} 篇文章`, 'success');
    }
    
    // 載入所有文章
    async loadAllPosts() {
        await this.loadPosts();
    }
    
    // 載入指定作者的文章列表
    async loadAuthorPosts(username) {
        try {
            console.log('載入作者文章列表:', username);
            
            const mainContent = document.querySelector('#posts-container');
            if (!mainContent) {
                console.error('找不到 posts-container 元素');
                return;
            }
            
            // 隱藏首頁的 loading 元素
            const loadingElement = document.querySelector('#loading');
            if (loadingElement) {
                loadingElement.style.display = 'none';
            }
            
            // 顯示載入中
            mainContent.innerHTML = `
                <div class="col-12">
                    <div class="card">
                        <div class="card-body text-center py-5">
                            <div class="spinner-border text-primary mb-3" role="status">
                                <span class="visually-hidden">載入中...</span>
                            </div>
                            <h5>正在載入 ${username} 的文章...</h5>
                            <p class="text-muted">請稍候</p>
                        </div>
                    </div>
                </div>
            `;
            
            // 載入該作者的文章
            const posts = await DataLoader.loadPosts(1, true, { author: username });
            console.log(`載入作者 ${username} 的文章:`, posts);
            
            if (posts && posts.length > 0) {
                // 顯示作者文章頁面標題
                const authorDisplayName = username === 'alice' ? 'Alice Wang' :
                                        username === 'bob' ? 'Bob Chen' :
                                        username === 'carol' ? 'Carol Liu' :
                                        username === 'david' ? 'David Lee' :
                                        username;
                
                const headerHtml = `
                    <div class="col-12">
                        <div class="card mb-4">
                            <div class="card-header bg-primary text-white">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h2 class="h4 mb-1">
                                            <i class="fas fa-user me-2"></i>${authorDisplayName} 的文章
                                        </h2>
                                        <p class="mb-0">共 ${posts.length} 篇文章</p>
                                    </div>
                                    <div>
                                        <button class="btn btn-outline-light me-2" onclick="BlogApp.loadAllPosts()">
                                            <i class="fas fa-home me-1"></i>返回首頁
                                        </button>
                                        <button class="btn btn-outline-light" onclick="BlogApp.viewAuthorProfile('${username}')">
                                            <i class="fas fa-user me-1"></i>作者資料
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                
                // 設置標題並保持 row 類
                mainContent.innerHTML = headerHtml;
                
                // 確保容器保持 row 類
                if (!mainContent.classList.contains('row')) {
                    mainContent.classList.add('row');
                }
                
                // 渲染文章列表（使用與 renderPosts 相同的模式）
                const postsHtml = posts.map(post => {
                    return Renderers.renderPostCard(post);
                }).join('');
                
                mainContent.insertAdjacentHTML('beforeend', postsHtml);
                
                Utils.showToast(`成功載入 ${posts.length} 篇文章`, 'success');
            } else {
                // 沒有文章
                mainContent.innerHTML = `
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body text-center py-5">
                                <i class="fas fa-file-alt fa-3x text-muted mb-3"></i>
                                <h4>暫無文章</h4>
                                <p class="text-muted">${username} 還沒有發布任何文章</p>
                                <button class="btn btn-primary" onclick="BlogApp.loadAllPosts()">
                                    <i class="fas fa-home me-1"></i>返回首頁
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            }
            
        } catch (error) {
            console.error('載入作者文章失敗:', error);
            Utils.showToast('載入作者文章失敗，請稍後再試', 'danger');
            
            // 顯示錯誤頁面
            const mainContent = document.querySelector('#posts-container');
            if (mainContent) {
                mainContent.innerHTML = `
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body text-center py-5">
                                <i class="fas fa-exclamation-triangle fa-3x text-danger mb-3"></i>
                                <h4>載入失敗</h4>
                                <p class="text-muted">無法載入作者文章，請稍後再試</p>
                                <button class="btn btn-primary" onclick="BlogApp.loadAllPosts()">
                                    <i class="fas fa-home me-1"></i>返回首頁
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            }
        }
    }
    
    // 載入關於頁面
    loadAboutPage() {
        try {
            console.log('載入關於頁面');
            
            const mainContent = document.querySelector('#posts-container');
            if (!mainContent) {
                console.error('找不到 posts-container 元素');
                return;
            }
            
            const aboutHtml = `
                <div class="col-12">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h1 class="h3 mb-0">
                                <i class="fas fa-info-circle me-2"></i>關於我們
                            </h1>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4 text-center mb-4">
                                    <img src="images/placeholders/avatar-default.svg" class="rounded-circle img-fluid mb-3" 
                                         style="width: 200px; height: 200px;" alt="部落格作者">
                                    <h4>部落格作者</h4>
                                    <p class="text-muted">技術愛好者 & 分享者</p>
                                </div>
                                <div class="col-md-8">
                                    <h5><i class="fas fa-user me-2"></i>關於我</h5>
                                    <p>歡迎來到我的個人部落格！我是一名熱愛技術的開發者，專注於分享程式設計心得、技術教學和生活感想。</p>
                                    
                                    <h5><i class="fas fa-code me-2"></i>系統開發技術</h5>
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <ul>
                                                <li>前端開發：HTML5, CSS3, JavaScript</li>
                                                <li>前端框架：Bootstrap 5</li>
                                            </ul>
                                        </div>
                                        <div class="col-md-6">
                                            <ul>
                                                <li>後端開發：Java 17, Spring Boot 3.2</li>
                                                <li>資料庫：Microsoft SQL Server</li>
                                                <li>其他工具：Git, RESTful API, Maven</li>
                                            </ul>
                                        </div>
                                    </div>
                                    
                                    <h5><i class="fas fa-heart me-2"></i>部落格理念</h5>
                                    <p>我相信知識分享能讓技術社群更加強大。通過這個部落格，我希望能夠：</p>
                                    <ul>
                                        <li>分享實用的程式設計技巧和最佳實踐</li>
                                        <li>記錄學習新技術的心得和過程</li>
                                        <li>與其他開發者交流想法和經驗</li>
                                        <li>幫助初學者解決常見的技術問題</li>
                                    </ul>
                                    
                                    <h5><i class="fas fa-envelope me-2"></i>聯絡方式</h5>
                                    <p>如果您有任何問題或想要交流，歡迎聯絡我。</p>
                                    <!-- 聯絡按鈕功能已關閉 -->
                                </div>
                            </div>
                        </div>
                        <div class="card-footer bg-light text-center">
                            <div class="d-flex gap-2 justify-content-center">
                                <button class="btn btn-primary" onclick="BlogApp.loadAllPosts()">
                                    <i class="fas fa-arrow-left me-1"></i>返回文章列表
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            mainContent.innerHTML = aboutHtml;
            mainContent.scrollIntoView({ behavior: 'smooth' });
            
            Utils.showToast('關於頁面載入成功', 'info');
            
        } catch (error) {
            console.error('載入關於頁面失敗:', error);
            Utils.showToast('載入關於頁面失敗，請稍後再試', 'danger');
        }
    }
    
    // 載入所有分類頁面
    loadAllCategories() {
        try {
            console.log('載入所有分類頁面');
            
            const mainContent = document.querySelector('#posts-container');
            if (!mainContent) {
                console.error('找不到 posts-container 元素');
                return;
            }
            
            const categoriesHtml = `
                <div class="col-12">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h1 class="h3 mb-0">
                                <i class="fas fa-folder me-2"></i>所有分類
                            </h1>
                        </div>
                        <div class="card-body">
                            <p class="text-muted mb-4">瀏覽部落格的所有文章分類</p>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <div class="card h-100">
                                        <div class="card-body text-center">
                                            <i class="fas fa-code fa-3x text-primary mb-3"></i>
                                            <h5>前端開發</h5>
                                            <p class="text-muted">JavaScript, React, Vue 等前端技術</p>
                                            <button class="btn btn-outline-primary" onclick="BlogApp.filterByCategory('frontend')">
                                                查看文章 <i class="fas fa-arrow-right"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="card h-100">
                                        <div class="card-body text-center">
                                            <i class="fas fa-server fa-3x text-success mb-3"></i>
                                            <h5>後端開發</h5>
                                            <p class="text-muted">Java, Spring Boot, API 設計</p>
                                            <button class="btn btn-outline-success" onclick="BlogApp.filterByCategory('backend')">
                                                查看文章 <i class="fas fa-arrow-right"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="card h-100">
                                        <div class="card-body text-center">
                                            <i class="fas fa-database fa-3x text-info mb-3"></i>
                                            <h5>資料庫</h5>
                                            <p class="text-muted">MySQL, PostgreSQL, 資料庫設計</p>
                                            <button class="btn btn-outline-info" onclick="BlogApp.filterByCategory('database')">
                                                查看文章 <i class="fas fa-arrow-right"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="card h-100">
                                        <div class="card-body text-center">
                                            <i class="fas fa-cloud fa-3x text-warning mb-3"></i>
                                            <h5>雲端運算</h5>
                                            <p class="text-muted">AWS, Azure, Docker, Kubernetes</p>
                                            <button class="btn btn-outline-warning" onclick="BlogApp.filterByCategory('cloud')">
                                                查看文章 <i class="fas fa-arrow-right"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="card h-100">
                                        <div class="card-body text-center">
                                            <i class="fas fa-briefcase fa-3x text-danger mb-3"></i>
                                            <h5>職業發展</h5>
                                            <p class="text-muted">職涯規劃, 技能提升, 面試經驗</p>
                                            <button class="btn btn-outline-danger" onclick="BlogApp.filterByCategory('career')">
                                                查看文章 <i class="fas fa-arrow-right"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="card h-100">
                                        <div class="card-body text-center">
                                            <i class="fas fa-palette fa-3x text-secondary mb-3"></i>
                                            <h5>設計</h5>
                                            <p class="text-muted">UI/UX 設計, 產品設計思維</p>
                                            <button class="btn btn-outline-secondary" onclick="BlogApp.filterByCategory('design')">
                                                查看文章 <i class="fas fa-arrow-right"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer bg-light text-center">
                            <button class="btn btn-primary" onclick="BlogApp.loadAllPosts()">
                                <i class="fas fa-arrow-left me-1"></i>返回文章列表
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            mainContent.innerHTML = categoriesHtml;
            mainContent.scrollIntoView({ behavior: 'smooth' });
            
            Utils.showToast('分類頁面載入成功', 'info');
            
        } catch (error) {
            console.error('載入分類頁面失敗:', error);
            Utils.showToast('載入分類頁面失敗，請稍後再試', 'danger');
        }
    }
    
    // 載入所有標籤頁面
    loadAllTags() {
        try {
            console.log('載入所有標籤頁面');
            
            const mainContent = document.querySelector('#posts-container');
            if (!mainContent) {
                console.error('找不到 posts-container 元素');
                return;
            }
            
            const tagsHtml = `
                <div class="col-12">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h1 class="h3 mb-0">
                                <i class="fas fa-tags me-2"></i>所有標籤
                            </h1>
                        </div>
                        <div class="card-body">
                            <p class="text-muted mb-4">瀏覽部落格的所有文章標籤</p>
                            <div class="tags-cloud text-center">
                                <a href="#" onclick="BlogApp.filterByTag('javascript'); return false;" class="badge bg-primary me-2 mb-2 p-2" style="font-size: 1.1em;">JavaScript</a>
                                <a href="#" onclick="BlogApp.filterByTag('react'); return false;" class="badge bg-info me-2 mb-2 p-2" style="font-size: 1em;">React</a>
                                <a href="#" onclick="BlogApp.filterByTag('vue'); return false;" class="badge bg-success me-2 mb-2 p-2" style="font-size: 0.9em;">Vue</a>
                                <a href="#" onclick="BlogApp.filterByTag('java'); return false;" class="badge bg-warning me-2 mb-2 p-2" style="font-size: 1.2em;">Java</a>
                                <a href="#" onclick="BlogApp.filterByTag('spring-boot'); return false;" class="badge bg-danger me-2 mb-2 p-2" style="font-size: 1em;">Spring Boot</a>
                                <a href="#" onclick="BlogApp.filterByTag('sql'); return false;" class="badge bg-secondary me-2 mb-2 p-2" style="font-size: 0.8em;">SQL</a>
                                <a href="#" onclick="BlogApp.filterByTag('docker'); return false;" class="badge bg-dark me-2 mb-2 p-2" style="font-size: 1em;">Docker</a>
                                <a href="#" onclick="BlogApp.filterByTag('kubernetes'); return false;" class="badge bg-primary me-2 mb-2 p-2" style="font-size: 0.9em;">Kubernetes</a>
                                <a href="#" onclick="BlogApp.filterByTag('aws'); return false;" class="badge bg-info me-2 mb-2 p-2" style="font-size: 1.1em;">AWS</a>
                                <a href="#" onclick="BlogApp.filterByTag('azure'); return false;" class="badge bg-success me-2 mb-2 p-2" style="font-size: 0.8em;">Azure</a>
                                <a href="#" onclick="BlogApp.filterByTag('python'); return false;" class="badge bg-warning me-2 mb-2 p-2" style="font-size: 1em;">Python</a>
                                <a href="#" onclick="BlogApp.filterByTag('nodejs'); return false;" class="badge bg-danger me-2 mb-2 p-2" style="font-size: 0.9em;">Node.js</a>
                                <a href="#" onclick="BlogApp.filterByTag('typescript'); return false;" class="badge bg-secondary me-2 mb-2 p-2" style="font-size: 1em;">TypeScript</a>
                                <a href="#" onclick="BlogApp.filterByTag('css'); return false;" class="badge bg-dark me-2 mb-2 p-2" style="font-size: 0.8em;">CSS</a>
                                <a href="#" onclick="BlogApp.filterByTag('html'); return false;" class="badge bg-primary me-2 mb-2 p-2" style="font-size: 0.8em;">HTML</a>
                                <a href="#" onclick="BlogApp.filterByTag('git'); return false;" class="badge bg-info me-2 mb-2 p-2" style="font-size: 1em;">Git</a>
                                <a href="#" onclick="BlogApp.filterByTag('linux'); return false;" class="badge bg-success me-2 mb-2 p-2" style="font-size: 0.9em;">Linux</a>
                                <a href="#" onclick="BlogApp.filterByTag('api'); return false;" class="badge bg-warning me-2 mb-2 p-2" style="font-size: 1.1em;">API</a>
                                <a href="#" onclick="BlogApp.filterByTag('testing'); return false;" class="badge bg-danger me-2 mb-2 p-2" style="font-size: 0.8em;">Testing</a>
                                <a href="#" onclick="BlogApp.filterByTag('career'); return false;" class="badge bg-secondary me-2 mb-2 p-2" style="font-size: 1em;">Career</a>
                            </div>
                            <hr class="my-4">
                            <div class="text-center">
                                <h6 class="text-muted">標籤說明</h6>
                                <p class="small text-muted">標籤大小反映文章數量，點擊標籤可查看相關文章</p>
                            </div>
                        </div>
                        <div class="card-footer bg-light text-center">
                            <button class="btn btn-primary" onclick="BlogApp.loadAllPosts()">
                                <i class="fas fa-arrow-left me-1"></i>返回文章列表
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            mainContent.innerHTML = tagsHtml;
            mainContent.scrollIntoView({ behavior: 'smooth' });
            
            Utils.showToast('標籤頁面載入成功', 'info');
            
        } catch (error) {
            console.error('載入標籤頁面失敗:', error);
            Utils.showToast('載入標籤頁面失敗，請稍後再試', 'danger');
        }
    }
    
    // 載入我的文章（個人頁面）
    async loadMyPosts() {
        try {
            // 檢查是否已登入
                    if (!window.AuthManager.isLoggedIn()) {
            Utils.showToast('請先登入', 'warning');
            this.loadPosts(); // 未登入時顯示首頁
            return;
        }
            
            // 獲取當前用戶信息
            const userInfo = this.getCurrentUserInfo();
            console.log('當前用戶信息:', userInfo);
            
            if (!userInfo || !userInfo.username) {
                Utils.showToast('無法獲取用戶信息', 'error');
                this.loadPosts();
                return;
            }
            
            console.log('準備載入用戶文章，用戶名:', userInfo.username);
            
            // 用戶信息載入後，重新檢查權限
            console.log('用戶信息已載入，重新檢查權限');
            this.initializeAuth();
            
            // 顯示個人頁面標題和切換按鈕
            this.showPersonalPageHeader();
            
            // 確保 loading 元素存在且可見
            const loadingElement = document.querySelector('#loading');
            if (loadingElement && loadingElement.style.display !== 'none') {
                // 如果 loading 元素可見，保持顯示直到載入完成
                const posts = await DataLoader.loadPosts(1, true, { author: userInfo.username });
                console.log('載入到的文章:', posts);
                this.renderPosts(posts);
            } else {
                // 如果沒有 loading 元素或已隱藏，直接載入並渲染
                const posts = await DataLoader.loadPosts(1, true, { author: userInfo.username });
                console.log('載入到的文章:', posts);
                this.renderPosts(posts);
            }
            
        } catch (error) {
            console.error('載入我的文章失敗:', error);
            Utils.showToast('載入我的文章失敗，請稍後再試', 'danger');
            this.loadPosts(); // 失敗時顯示首頁
            
            // 確保在錯誤時也隱藏 loading
            const loadingElement = document.querySelector('#loading');
            if (loadingElement) {
                $(loadingElement).fadeOut(300, function() {
                    $(this).remove();
                });
            }
        }
    }
    
    // 顯示個人頁面標題和切換按鈕
    showPersonalPageHeader() {
        const mainContent = document.querySelector('#posts-container');
        if (!mainContent) {
            console.log('showPersonalPageHeader: 找不到 posts-container');
            return;
        }
        
        const userInfo = this.getCurrentUserInfo();
        const displayName = userInfo?.displayName || userInfo?.username || '我的';
        
        console.log('showPersonalPageHeader: 設置個人頁面標題');
        const headerHtml = `
            <div class="col-12 mb-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="fw-bold mb-2">
                            <i class="fas fa-user-circle me-2 text-primary"></i>${displayName}的文章
                        </h2>
                        <p class="text-muted mb-0">這裡是您發布的所有文章</p>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary" onclick="BlogApp.switchToMyPosts()" disabled>
                            <i class="fas fa-user me-1"></i>我的文章
                        </button>
                        <button class="btn btn-outline-primary" onclick="BlogApp.switchToHome()">
                            <i class="fas fa-home me-1"></i>首頁
                        </button>
                    </div>
                </div>
            </div>
            <!-- 文章將在後續載入時添加到這個 row 容器中 -->
        `;
        
        mainContent.innerHTML = headerHtml;
        console.log('showPersonalPageHeader: 個人頁面標題設置完成');
    }
    
    // 顯示首頁標題和切換按鈕
    showHomePageHeader() {
        const mainContent = document.querySelector('#posts-container');
        if (!mainContent) {
            console.log('showHomePageHeader: 找不到 posts-container');
            return;
        }
        
        console.log('showHomePageHeader: 設置首頁標題');
        const headerHtml = `
            <div class="col-12 mb-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="fw-bold mb-2">
                            <i class="fas fa-newspaper me-2 text-primary"></i>最新文章
                        </h2>
                        <p class="text-muted mb-0">發現來自所有作者的精彩內容</p>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-outline-primary" onclick="BlogApp.switchToMyPosts()">
                            <i class="fas fa-user me-1"></i>我的文章
                        </button>
                        <button class="btn btn-primary" onclick="BlogApp.switchToHome()" disabled>
                            <i class="fas fa-home me-1"></i>首頁
                        </button>
                    </div>
                </div>
            </div>
            <!-- 文章將在後續載入時添加到這個 row 容器中 -->
        `;
        
        mainContent.innerHTML = headerHtml;
        console.log('showHomePageHeader: 標題設置完成');
    }
    
    // 切換到首頁
    switchToHome() {
        // 更新 URL 參數
        const url = new URL(window.location);
        url.searchParams.set('page', 'home');
        
        // 使用導航管理器
        if (window.navigationManager) {
            window.navigationManager.navigateTo(url.href, '首頁 - 所有文章');
        } else {
            window.history.pushState({}, '', url);
        }
        
        // 載入首頁內容
        this.loadPosts();
    }
    
    // 切換到個人頁面
    switchToMyPosts() {
        // 更新 URL 參數
        const url = new URL(window.location);
        url.searchParams.set('page', 'my-posts');
        
        // 使用導航管理器
        if (window.navigationManager) {
            window.navigationManager.navigateTo(url.href, '我的文章');
        } else {
            window.history.pushState({}, '', url);
        }
        
        // 載入個人頁面內容
        this.loadMyPosts();
    }
    
    // 獲取當前用戶信息
    getCurrentUserInfo() {
        try {
            console.log('=== getCurrentUserInfo 調試 ===');
            
                    // 首先檢查是否已登入
        if (!window.AuthManager.isLoggedIn()) {
            console.log('用戶未登入');
            return null;
        }
            
            // 從 localStorage 或 sessionStorage 獲取用戶信息
            const localUser = localStorage.getItem('user');
            const sessionUser = sessionStorage.getItem('user');
            
            console.log('localStorage user:', localUser);
            console.log('sessionStorage user:', sessionUser);
            
            const userInfo = localUser || sessionUser;
            if (userInfo) {
                const parsed = JSON.parse(userInfo);
                console.log('解析後的用戶信息:', parsed);
                return parsed;
            }
            
            // 如果沒有用戶信息，嘗試從 token 解析
            const token = window.AuthManager.getToken();
            console.log('Token:', token);
            if (token && token.includes(':')) {
                const username = token.split(':')[0];
                const fallbackUser = { username: username };
                console.log('從 token 解析的用戶信息:', fallbackUser);
                return fallbackUser;
            }
            
            console.log('沒有找到用戶信息');
            return null;
        } catch (error) {
            console.error('獲取當前用戶信息失敗:', error);
            return null;
        }
    }
    
    // 載入側邊欄資料
    async loadSidebarData() {
        try {
            const results = await Promise.allSettled([
                BlogAPI.categories.getAll(),
                BlogAPI.tags.getAll()
            ]);
            
            // 處理分類數據
            if (results[0].status === 'fulfilled') {
                console.log('Categories data:', results[0].value);
                const categories = results[0].value?.data || results[0].value || [];
                Renderers.renderCategories(categories);
            }
            
            // 處理標籤數據
            if (results[1].status === 'fulfilled') {
                console.log('Tags data:', results[1].value);
                const tags = results[1].value?.data || results[1].value || [];
                Renderers.renderTagsCloud(tags);
            }
            
            // 載入最新評論
            await this.loadRecentComments();
            
        } catch (error) {
            console.error('載入側邊欄資料失敗:', error);
            // 顯示默認數據
            Renderers.renderCategories([]);
            Renderers.renderTagsCloud([]);
            Renderers.renderRecentComments([]);
        }
    }
    
    // 載入最新評論
    async loadRecentComments() {
        try {
            // 從本地存儲載入評論數據
            const localComments = localStorage.getItem('blog_comments');
            let allComments = [];
            
            if (localComments) {
                const parsed = JSON.parse(localComments);
                console.log('載入評論數據用於側邊欄:', parsed);
                
                // 獲取所有文章資料用於映射標題
                let posts = [];
                try {
                    const postsResponse = await BlogAPI.posts.getList();
                    console.log('API 返回的文章資料:', postsResponse);
                    
                    // 處理不同的 API 響應格式
                    if (Array.isArray(postsResponse)) {
                        posts = postsResponse;
                    } else if (postsResponse && Array.isArray(postsResponse.data)) {
                        posts = postsResponse.data;
                    } else if (postsResponse && Array.isArray(postsResponse.content)) {
                        posts = postsResponse.content;
                    } else {
                        console.warn('無法解析文章資料，使用空陣列:', postsResponse);
                        posts = [];
                    }
                } catch (apiError) {
                    console.warn('獲取文章資料失敗，將使用備用映射:', apiError);
                    posts = [];
                }
                
                // 創建 postId 到文章資料的映射
                const postMap = new Map();
                if (Array.isArray(posts)) {
                    posts.forEach(post => {
                        // 支援多種 ID 格式
                        if (post.postId) postMap.set(String(post.postId), post);
                        if (post.slug) postMap.set(post.slug, post);
                        if (post.title) {
                            // 也支援通過標題匹配
                            postMap.set(post.title.toLowerCase().replace(/\s+/g, '-'), post);
                        }
                    });
                }
                
                // 將所有文章的評論合併並添加真實文章標題
                Object.entries(parsed).forEach(([postId, comments]) => {
                    if (Array.isArray(comments)) {
                        comments.forEach(comment => {
                            const post = postMap.get(String(postId)) || postMap.get(postId);
                            let postTitle, postSlug;
                            
                            if (post) {
                                // 從 API 獲取的真實資料
                                postTitle = post.title;
                                postSlug = post.slug;
                            } else {
                                // 備用映射
                                postTitle = this.getPostTitleForComment(postId);
                                postSlug = this.getPostSlugForComment(postId);
                            }
                            
                            allComments.push({
                                ...comment,
                                postId: postId,
                                postTitle: postTitle,
                                postSlug: postSlug
                            });
                        });
                    }
                });
            }
            
            // 如果沒有本地評論，嘗試從 API 獲取
            if (allComments.length === 0) {
                try {
                    const response = await BlogAPI.comments.getRecent(5);
                    allComments = response?.data || response || [];
                } catch (apiError) {
                    console.log('API 獲取最新評論失敗，使用空數據:', apiError.message);
                }
            }
            
            // 按時間排序並取最新的5條
            allComments.sort((a, b) => {
                const dateA = new Date(a.createdAt || 0);
                const dateB = new Date(b.createdAt || 0);
                return dateB - dateA;
            });
            
            const recentComments = allComments.slice(0, 5);
            console.log('最新5條評論:', recentComments);
            
            // 渲染評論
            Renderers.renderRecentComments(recentComments);
            
        } catch (error) {
            console.error('載入最新評論失敗:', error);
            Renderers.renderRecentComments([]);
        }
    }
    
    // 備用映射方法（僅在 API 失敗時使用）
    getPostTitleForComment(postId) {
        // 這是備用映射，通常不會使用到，因為我們現在動態獲取標題
        const titleMap = {
            '1': '程式設計入門指南',
            '2': 'JavaScript 基礎教學',
            '3': 'React 開發技巧',
            '4': 'Spring Boot 實戰',
            '5': '資料庫設計原則',
            'test2': '測試文章 2',
            'test-3': '測試文章 3',
            'test5': '測試文章 5',
            'test7': '測試文章 7',
            'alice-frontend-tips': 'Alice 的前端技巧分享'
        };
        
        return titleMap[postId] || `文章 ${postId}`;
    }
    
    // 備用映射方法（僅在 API 失敗時使用）
    getPostSlugForComment(postId) {
        // 這是備用映射，通常不會使用到，因為我們現在動態獲取 slug
        const slugMap = {
            '1': 'programming-guide',
            '2': 'javascript-basics',
            '3': 'react-tips',
            '4': 'spring-boot-practice',
            '5': 'database-design',
            'test2': 'test2',
            'test-3': 'test-3',
            'test5': 'test5',
            'test7': 'test7',
            'alice-frontend-tips': 'alice-frontend-tips'
        };
        
        return slugMap[postId] || postId;
    }
    
    // 查看文章詳情
    async viewPost(slug) {
        try {
            // 🎯 首先滾動到文章區域
            const mainContentSection = document.querySelector('.main-content');
            if (mainContentSection) {
                mainContentSection.scrollIntoView({ 
                    behavior: 'smooth', 
                    block: 'start' 
                });
            }
            
            const post = await BlogAPI.posts.getBySlug(slug);
            if (!post) {
                throw new Error('文章不存在');
            }
            
            const mainContent = document.querySelector('#posts-container');
            if (mainContent) {
                const html = `
                    <article class="post-detail">
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h1 class="h2 mb-2">${post.title || '無標題'}</h1>
                                        <div class="post-meta">
                                            <span class="me-3">
                                                <i class="fas fa-user me-1"></i>
                                                <a href="#" onclick="BlogApp.viewAuthorProfile('${post.author?.username || post.author || 'unknown'}'); return false;" class="text-white text-decoration-none">
                                                    ${post.author?.displayName || post.author?.username || post.author || '未知作者'}
                                                </a>
                                            </span>
                                            <span class="me-3">
                                                <i class="fas fa-calendar me-1"></i>
                                                ${Utils.formatDate(post.publishedAt || post.createdAt)}
                                            </span>
                                            <span class="me-3">
                                                <i class="fas fa-folder me-1"></i>
                                                <a href="#" onclick="BlogApp.filterByCategory('${post.category?.slug || post.category || 'uncategorized'}'); return false;" class="text-white text-decoration-none">
                                                    ${post.category?.name || post.category || '未分類'}
                                                </a>
                                            </span>
                                            <span class="me-3">
                                                <i class="fas fa-eye me-1"></i>
                                                ${post.viewCount || 0} 次瀏覽
                                            </span>
                                            <span class="me-3">
                                                <i class="fas fa-heart me-1"></i>
                                                <span class="like-count-display">${post.likeCount || 0}</span> 個讚
                                            </span>
                                        </div>
                                    </div>
                                    <div class="post-actions">
                                        <!-- 分享功能已關閉 -->
                                        ${this.canEditPost(post) ? `
                                            <button class="btn btn-outline-warning btn-sm me-2" onclick="BlogApp.editPost('${post.slug}')" title="編輯文章">
                                                <i class="fas fa-edit me-1"></i>編輯
                                            </button>
                                            <button class="btn btn-outline-danger btn-sm me-2" onclick="BlogApp.deletePost('${post.id || post.postId || post.slug}')" title="刪除文章">
                                                <i class="fas fa-trash me-1"></i>刪除
                                            </button>
                                        ` : ''}
                                        ${this.isAdminUser() ? `
                                            <button class="btn btn-outline-warning btn-sm" onclick="window.open('admin.html', '_blank')" title="返回後台">
                                                <i class="fas fa-cog me-1"></i>後台管理
                                            </button>
                                        ` : ''}
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="post-content">
                                    ${post.content || post.excerpt || '文章內容載入中...'}
                                </div>
                                
                                ${post.tags && Array.isArray(post.tags) && post.tags.length > 0 ? `
                                    <div class="post-tags mt-4">
                                        <h6><i class="fas fa-tags me-2"></i>標籤</h6>
                                        <div class="tags-list">
                                            ${post.tags.map(tag => `
                                                <a href="#" onclick="BlogApp.filterByTag('${tag.slug || tag}'); return false;" class="badge bg-secondary text-decoration-none me-2">
                                                    ${tag.name || tag}
                                                </a>
                                            `).join('')}
                                        </div>
                                    </div>
                                ` : ''}
                            </div>
                            <div class="card-footer bg-light">
                                <div class="row">
                                    <div class="col-12 text-center">
                                        <small class="text-muted">
                                            <i class="fas fa-user me-1"></i>
                                            <a href="#" onclick="BlogApp.viewAuthorProfile('${post.author?.username || post.author || 'unknown'}'); return false;" class="text-decoration-none">
                                                查看 ${post.author?.displayName || post.author?.username || post.author || '未知作者'} 的更多文章
                                            </a>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>
                    
                    <!-- 評論區域 -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="mb-0">
                                        <i class="fas fa-comments me-2"></i>評論區
                                        <span class="badge bg-primary ms-2" id="comment-count">0</span>
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <!-- 發表評論表單 -->
                                    <div class="comment-form mb-4" id="comment-form">
                                        <!-- 由 CommentManager 動態生成 -->
                                    </div>
                                    
                                    <!-- 評論列表 -->
                                    <div class="comments-list" id="comments-list">
                                        <div class="text-center text-muted">
                                            <i class="fas fa-comments fa-2x mb-2"></i>
                                            <p>暫無評論，來發表第一條評論吧！</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                mainContent.innerHTML = html;
                mainContent.scrollIntoView({ behavior: 'smooth' });
                
                // 記錄到導航歷史
                if (window.navigationManager) {
                    const title = `${post.title} - 文章詳情`;
                    window.navigationManager.addToHistory(window.location.href, title);
                }
                
                // 初始化評論系統
                if (window.commentManager) {
                    console.log('🔧 初始化評論系統，文章數據:', post);
                    console.log('🔧 文章ID字段:', {id: post.id, postId: post.postId, slug: post.slug});
                    
                    // 優先使用 postId，然後是 id，最後是 slug
                    let postId = post.postId || post.id || post.slug;
                    console.log('🔧 選擇的文章ID:', postId, '類型:', typeof postId);
                    
                    // 確保是數字
                    const numericPostId = parseInt(postId);
                    if (!isNaN(numericPostId)) {
                        console.log('✅ 使用數字ID:', numericPostId);
                        window.commentManager.setCurrentPostId(numericPostId);
                        window.commentManager.loadPostComments(numericPostId);
                    } else {
                        console.error('❌ 無法獲取有效的文章ID');
                        console.log('❌ 可用的ID字段:', {
                            id: post.id,
                            postId: post.postId,
                            slug: post.slug
                        });
                    }
                } else {
                    console.error('❌ CommentManager 未找到');
                }
                
                // 檢查並設置點讚按鈕狀態
                const hasLiked = this.checkPostLikeStatus(post.slug);
                if (hasLiked) {
                    const allLikeButtons = document.querySelectorAll(`[id*="like-btn"][id*="${post.slug}"]`);
                    allLikeButtons.forEach(btn => {
                        btn.classList.remove('btn-outline-light', 'btn-outline-primary');
                        btn.classList.add('btn-success', 'liked');
                        btn.innerHTML = `<i class="fas fa-heart me-1"></i>已讚`;
                        btn.onclick = null; // 移除點擊事件
                        btn.disabled = false;
                    });
                }
                
                // 設置當前文章ID並載入評論
                console.log('文章數據:', post);
                console.log('文章ID字段:', { id: post.id, postId: post.postId, slug: post.slug });
                
                // 使用 postId 作為主要標識符，如果沒有則組合 author_slug 確保唯一性
                let postIdentifier;
                if (post.postId) {
                    postIdentifier = post.postId;
                } else {
                    // 對於沒有postId的情況，使用作者+slug組合確保唯一性
                    const author = post.author?.username || post.author || 'unknown';
                    const slug = post.slug || post.id || 'unknown-post';
                    postIdentifier = `${author}_${slug}`;
                }
                
                if (postIdentifier) {
                    commentManager.setCurrentPostId(postIdentifier);
                    commentManager.loadPostComments(postIdentifier);
                } else {
                    console.error('無法獲取文章標識符');
                }
            }
            
            Utils.showToast('文章載入成功', 'success');
        } catch (error) {
            console.error('載入文章失敗:', error);
            Utils.showToast('載入文章失敗，請稍後再試', 'danger');
        }
    }
    
    // 查看作者資料
    async viewAuthorProfile(username) {
        try {
            console.log('開始載入作者資料:', username);
            
            // 首先嘗試從API獲取真實用戶資料
            let authorData = await this.fetchAuthorData(username);
            
            // 如果沒有獲取到真實資料，使用模擬資料
            if (!authorData) {
                console.log('使用模擬作者資料');
                authorData = this.getMockAuthorData(username);
            }
            
            console.log('作者資料載入完成:', authorData);
            this.renderAuthorProfile(authorData, username);
            
            // 顯示成功消息
            Utils.showToast(`查看作者 ${authorData.displayName} 的資料`, 'info');
            
        } catch (error) {
            console.error('載入作者資料失敗:', error);
            
            // 即使出錯也要隱藏載入動畫
            const loadingElement = document.querySelector('#loading');
            if (loadingElement) {
                loadingElement.style.display = 'none';
            }
            
            // 使用模擬資料作為備用方案
            const authorData = this.getMockAuthorData(username);
            this.renderAuthorProfile(authorData, username);
            
            Utils.showToast('載入作者資料失敗，顯示模擬資料', 'warning');
        }
    }
    
    // 獲取作者資料
    async fetchAuthorData(username) {
        try {
            // 檢查是否為當前登入用戶
            const currentUser = this.getCurrentUserInfo();
            if (currentUser && currentUser.username === username) {
                console.log('查看當前用戶自己的資料');
                // 嘗試從API獲取最新資料
                try {
                    const response = await BlogAPI.user.getCurrentProfile();
                    if (response && response.data) {
                        return this.formatAuthorData(response.data, true);
                    }
                } catch (apiError) {
                    console.log('API獲取失敗，使用本地資料:', apiError);
                }
                
                // API失敗時使用本地資料
                return this.formatAuthorData(currentUser, true);
            }
            
            // 嘗試獲取其他用戶的公開資料
            try {
                const response = await BlogAPI.user.getPublicProfile(username);
                if (response && response.data) {
                    return this.formatAuthorData(response.data, false);
                }
            } catch (apiError) {
                console.log('獲取其他用戶資料失敗:', apiError);
            }
            
            return null;
            
        } catch (error) {
            console.error('獲取作者資料失敗:', error);
            return null;
        }
    }
    
    // 格式化作者資料
    formatAuthorData(userData, isCurrentUser = false) {
        return {
            username: userData.username,
            displayName: userData.displayName || userData.username,
            avatar: userData.avatar || 'images/placeholders/avatar-default.svg',
            profession: userData.profession || '部落格作者',
            bio: userData.bio || '這位作者還沒有介紹自己...',
            location: userData.location || '',
            website: userData.website || '',
            postCount: Math.floor(Math.random() * 10) + 1, // 暫時使用隨機數，之後可以從API獲取
            totalViews: Math.floor(Math.random() * 1000) + 100,
            totalLikes: Math.floor(Math.random() * 100) + 10,
            joinDate: userData.createdAt ? Utils.formatDate(userData.createdAt) : '2024-01-15',
            lastActive: userData.lastLoginAt ? Utils.formatDate(userData.lastLoginAt) : '最近',
            specialties: this.getSpecialtiesFromProfession(userData.profession),
            isCurrentUser: isCurrentUser
        };
    }
    
    // 根據職業推斷專長領域
    getSpecialtiesFromProfession(profession) {
        if (!profession) return ['Programming'];
        
        const professionLower = profession.toLowerCase();
        if (professionLower.includes('前端') || professionLower.includes('frontend')) {
            return ['Frontend', 'JavaScript', 'React'];
        } else if (professionLower.includes('後端') || professionLower.includes('backend')) {
            return ['Backend', 'Architecture', 'Database'];
        } else if (professionLower.includes('全端') || professionLower.includes('fullstack')) {
            return ['Full-stack', 'Frontend', 'Backend'];
        } else if (professionLower.includes('設計') || professionLower.includes('design')) {
            return ['Design', 'UX/UI', 'Product'];
        } else if (professionLower.includes('資料') || professionLower.includes('data')) {
            return ['Data Science', 'Analytics', 'ML'];
        } else {
            return ['Programming', 'Technology'];
        }
    }
    
    // 獲取模擬作者資料（備用方案）
    getMockAuthorData(username) {
        return {
            username: username,
            displayName: username === 'alice' ? 'Alice Wang' :
                       username === 'bob' ? 'Bob Chen' :
                       username === 'carol' ? 'Carol Liu' :
                       username === 'david' ? 'David Lee' :
                       username,
            avatar: 'images/placeholders/avatar-default.svg',
            profession: username === 'alice' ? '前端開發專家' :
                       username === 'bob' ? '資深軟體工程師' :
                       username === 'carol' ? 'UX/UI 設計師' :
                       username === 'david' ? '後端架構師' :
                       '部落格作者',
            bio: username === 'alice' ? '前端開發專家，專注於 React 和現代 JavaScript 技術。熱愛分享技術心得和最佳實踐。' :
                 username === 'bob' ? '資深軟體工程師，擁有豐富的全端開發經驗。喜歡分享職業發展和技術成長心得。' :
                 username === 'carol' ? 'UX/UI 設計師，專注於用戶體驗設計和產品思維。致力於創造美觀且實用的設計。' :
                 username === 'david' ? '後端架構師，專精於分散式系統和微服務架構設計。喜歡討論系統設計和性能優化。' :
                 '這位作者還沒有介紹自己...',
            location: '',
            website: '',
            postCount: Math.floor(Math.random() * 10) + 1,
            totalViews: Math.floor(Math.random() * 1000) + 100,
            totalLikes: Math.floor(Math.random() * 100) + 10,
            joinDate: '2024-01-15',
            lastActive: '2025-08-16',
            specialties: username === 'alice' ? ['Frontend', 'React', 'JavaScript'] :
                        username === 'bob' ? ['Full-stack', 'Career', 'Programming'] :
                        username === 'carol' ? ['Design', 'UX/UI', 'Product'] :
                        username === 'david' ? ['Backend', 'Architecture', 'Performance'] :
                        ['Programming'],
            isCurrentUser: false
        };
    }
    
    // 渲染作者資料頁面
    renderAuthorProfile(authorData, username) {
            // 隱藏載入動畫
            const loadingElement = document.querySelector('#loading');
            if (loadingElement) {
                loadingElement.style.display = 'none';
            }
            
            const mainContent = document.querySelector('#posts-container');
            if (mainContent) {
                const html = `
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header bg-primary text-white">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h1 class="h3 mb-0">
                                            <i class="fas fa-user-circle me-2"></i>作者資料
                                        </h1>
                                        <div class="d-flex gap-2">
                                            <button class="btn btn-outline-light" onclick="BlogApp.viewAuthorPosts('${username}')">
                                                <i class="fas fa-newspaper me-1"></i>查看文章
                                            </button>
                                            <button class="btn btn-outline-light" onclick="BlogApp.loadAllPosts()">
                                                <i class="fas fa-arrow-left me-1"></i>返回文章列表
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-3 text-center">
                                            <img src="${authorData.avatar}" class="rounded-circle img-fluid mb-3" 
                                                 style="width: 150px; height: 150px; object-fit: cover;" alt="${authorData.displayName}">
                                            <h4>${authorData.displayName}</h4>
                                            <p class="text-muted">@${authorData.username}</p>
                                            ${authorData.profession ? `<p class="text-primary small"><i class="fas fa-briefcase me-1"></i>${authorData.profession}</p>` : ''}
                                            ${authorData.location ? `<p class="text-muted small"><i class="fas fa-map-marker-alt me-1"></i>${authorData.location}</p>` : ''}
                                            <div class="author-stats">
                                                <div class="row text-center">
                                                    <div class="col-4">
                                                        <div class="stat-item">
                                                            <h5 style="color: #000;">${authorData.postCount}</h5>
                                                            <small>文章</small>
                                                        </div>
                                                    </div>
                                                    <div class="col-4">
                                                        <div class="stat-item">
                                                            <h5 style="color: #000;">${authorData.totalViews}</h5>
                                                            <small>瀏覽</small>
                                                        </div>
                                                    </div>
                                                    <div class="col-4">
                                                        <div class="stat-item">
                                                            <h5 style="color: #000;">${authorData.totalLikes}</h5>
                                                            <small>喜歡</small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="author-bio mb-4">
                                                <h5><i class="fas fa-user me-2"></i>個人簡介</h5>
                                                <p>${authorData.bio}</p>
                                            </div>
                                            
                                            ${authorData.website ? `
                                                <div class="author-website mb-4">
                                                    <h6><i class="fas fa-link me-2"></i>個人網站</h6>
                                                    <p><a href="${authorData.website}" target="_blank" rel="noopener" class="text-decoration-none">${authorData.website}</a></p>
                                                </div>
                                            ` : ''}
                                            
                                            <div class="author-specialties mb-4">
                                                <h5><i class="fas fa-star me-2"></i>專長領域</h5>
                                                <div class="specialties-tags">
                                                    ${authorData.specialties.map(specialty => 
                                                        `<span class="badge bg-info me-2">${specialty}</span>`
                                                    ).join('')}
                                                </div>
                                            </div>
                                            
                                            <div class="author-info">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h6><i class="fas fa-calendar me-2"></i>加入時間</h6>
                                                        <p>${authorData.joinDate}</p>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <h6><i class="fas fa-clock me-2"></i>最後活躍</h6>
                                                        <p>${authorData.lastActive}</p>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            ${authorData.isCurrentUser ? `
                                                <div class="author-actions mt-4">
                                                    <a href="profile-settings.html" class="btn btn-primary">
                                                        <i class="fas fa-edit me-1"></i>編輯個人資料
                                                    </a>
                                                </div>
                                            ` : ''}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                
                mainContent.innerHTML = html;
                mainContent.scrollIntoView({ behavior: 'smooth' });
            }
    }
    
    // 載入作者列表頁面
    async loadAuthorsList() {
        try {
            const mainContent = document.querySelector('#posts-container');
            if (mainContent) {
                const html = `
                    <div class="row">
                        <div class="col-12">
                            <h2 class="mb-4">
                                <i class="fas fa-users me-2 text-primary"></i>作者列表
                            </h2>
                            <div class="row">
                                <div class="col-md-6 col-lg-3 mb-4">
                                    <div class="card h-100 text-center">
                                        <div class="card-body">
                                            <img src="images/placeholders/avatar-default.svg" class="rounded-circle mb-3" 
                                                 style="width: 80px; height: 80px;" alt="Alice Wang">
                                            <h5 class="card-title">Alice Wang</h5>
                                            <p class="card-text text-muted">前端開發專家</p>
                                            <div class="d-flex justify-content-center gap-2">
                                                <button class="btn btn-outline-primary btn-sm" onclick="BlogApp.viewAuthorProfile('alice')">
                                                    <i class="fas fa-user me-1"></i>查看資料
                                                </button>
                                                <button class="btn btn-primary btn-sm" onclick="BlogApp.viewAuthorPosts('alice')">
                                                    <i class="fas fa-newspaper me-1"></i>查看文章
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-3 mb-4">
                                    <div class="card h-100 text-center">
                                        <div class="card-body">
                                            <img src="images/placeholders/avatar-default.svg" class="rounded-circle mb-3" 
                                                 style="width: 80px; height: 80px;" alt="Bob Chen">
                                            <h5 class="card-title">Bob Chen</h5>
                                            <p class="card-text text-muted">資深軟體工程師</p>
                                            <div class="d-flex justify-content-center gap-2">
                                                <button class="btn btn-outline-primary btn-sm" onclick="BlogApp.viewAuthorProfile('bob')">
                                                    <i class="fas fa-user me-1"></i>查看資料
                                                </button>
                                                <button class="btn btn-primary btn-sm" onclick="BlogApp.viewAuthorPosts('bob')">
                                                    <i class="fas fa-newspaper me-1"></i>查看文章
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-3 mb-4">
                                    <div class="card h-100 text-center">
                                        <div class="card-body">
                                            <img src="images/placeholders/avatar-default.svg" class="rounded-circle mb-3" 
                                                 style="width: 80px; height: 80px;" alt="Carol Liu">
                                            <h5 class="card-title">Carol Liu</h5>
                                            <p class="card-text text-muted">UX/UI 設計師</p>
                                            <div class="d-flex justify-content-center gap-2">
                                                <button class="btn btn-outline-primary btn-sm" onclick="BlogApp.viewAuthorProfile('carol')">
                                                    <i class="fas fa-user me-1"></i>查看資料
                                                </button>
                                                <button class="btn btn-primary btn-sm" onclick="BlogApp.viewAuthorPosts('carol')">
                                                    <i class="fas fa-newspaper me-1"></i>查看文章
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-3 mb-4">
                                    <div class="card h-100 text-center">
                                        <div class="card-body">
                                            <img src="images/placeholders/avatar-default.svg" class="rounded-circle mb-3" 
                                                 style="width: 80px; height: 80px;" alt="David Lee">
                                            <h5 class="card-title">David Lee</h5>
                                            <p class="card-text text-muted">後端架構師</p>
                                            <div class="d-flex justify-content-center gap-2">
                                                <button class="btn btn-outline-primary btn-sm" onclick="BlogApp.viewAuthorProfile('david')">
                                                    <i class="fas fa-user me-1"></i>查看資料
                                                </button>
                                                <button class="btn btn-primary btn-sm" onclick="BlogApp.viewAuthorPosts('david')">
                                                    <i class="fas fa-newspaper me-1"></i>查看文章
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                
                mainContent.innerHTML = html;
                mainContent.scrollIntoView({ behavior: 'smooth' });
            }
            
            Utils.showToast('作者列表載入成功', 'success');
        } catch (error) {
            console.error('載入作者列表失敗:', error);
            Utils.showToast('載入作者列表失敗，請稍後再試', 'danger');
        }
    }
    
    // 查看指定作者的所有文章
    async viewAuthorPosts(username) {
        try {
            const mainContent = document.querySelector('#posts-container');
            if (!mainContent) return;
            
            // 顯示作者文章頁面標題
            const authorDisplayName = username === 'alice' ? 'Alice Wang' :
                                    username === 'bob' ? 'Bob Chen' :
                                    username === 'carol' ? 'Carol Liu' :
                                    username === 'david' ? 'David Lee' :
                                    username;
            
            const headerHtml = `
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h2 class="fw-bold mb-2">
                                    <i class="fas fa-user-circle me-2 text-primary"></i>${authorDisplayName}的文章
                                </h2>
                                <p class="text-muted mb-0">查看 ${authorDisplayName} 發布的所有文章</p>
                            </div>
                            <div class="d-flex gap-2">
                                <button class="btn btn-outline-primary" onclick="BlogApp.loadAllPosts()">
                                    <i class="fas fa-home me-1"></i>返回首頁
                                </button>
                                <button class="btn btn-outline-secondary" onclick="BlogApp.viewAuthorProfile('${username}')">
                                    <i class="fas fa-user me-1"></i>作者資料
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="articles-container">
                    <!-- 文章將在這裡載入 -->
                </div>
            `;
            
            mainContent.innerHTML = headerHtml;
            
            // 載入該作者的文章
            const posts = await DataLoader.loadPosts(1, true, { author: username });
            console.log(`載入作者 ${username} 的文章:`, posts);
            
            // 渲染文章列表
            this.renderPosts(posts);
            
            // 顯示成功消息
            Utils.showToast(`已載入 ${authorDisplayName} 的文章`, 'success');
            
        } catch (error) {
            console.error('載入作者文章失敗:', error);
            Utils.showToast('載入作者文章失敗，請稍後再試', 'danger');
        }
    }
    
    // 按分類篩選文章
    async filterByCategory(categorySlug) {
        try {
            const mainContent = document.querySelector('#posts-container');
            if (mainContent) {
                // 顯示分類篩選標題
                const categoryName = this.getCategoryDisplayName(categorySlug);
                const headerHtml = `
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h2 class="fw-bold mb-2">
                                        <i class="fas fa-folder-open me-2 text-primary"></i>分類：${categoryName}
                                    </h2>
                                    <p class="text-muted mb-0">查看「${categoryName}」分類下的所有文章</p>
                                </div>
                                <div class="d-flex gap-2">
                                    <button class="btn btn-outline-primary" onclick="BlogApp.loadAllPosts()">
                                        <i class="fas fa-home me-1"></i>返回首頁
                                    </button>
                                    <button class="btn btn-outline-secondary" onclick="BlogApp.loadAuthorsList()">
                                        <i class="fas fa-users me-1"></i>作者列表
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="articles-container">
                        <!-- 文章將在這裡載入 -->
                    </div>
                `;
                
                mainContent.innerHTML = headerHtml;
                
                // 載入該分類的文章
                const posts = await this.loadPostsByCategory(categorySlug);
                console.log(`載入分類 ${categorySlug} 的文章:`, posts);
                
                // 渲染文章列表
                this.renderPosts(posts);
                
                // 顯示成功消息
                Utils.showToast(`已載入「${categoryName}」分類的文章`, 'success');
            }
        } catch (error) {
            console.error('分類篩選失敗:', error);
            Utils.showToast('分類篩選失敗，請稍後再試', 'danger');
        }
    }
    
    // 載入指定分類的文章
    async loadPostsByCategory(categorySlug) {
        try {
            // 嘗試從後端 API 獲取分類文章
            const response = await BlogAPI.posts.getList({ 
                page: 0, 
                size: 20,
                category: categorySlug 
            });
            
            if (response && response.content) {
                return response.content;
            }
            
            // 如果後端不可用，使用前端篩選
            return this.filterPostsByCategory(categorySlug);
            
        } catch (error) {
            console.log('後端分類篩選失敗，使用前端篩選:', error);
            // 使用前端篩選作為備用方案
            return this.filterPostsByCategory(categorySlug);
        }
    }
    
    // 前端分類篩選（備用方案）
    async filterPostsByCategory(categorySlug) {
        try {
            // 從 DataLoader 獲取所有文章
            const allPosts = await DataLoader.loadPosts(1, false);
            
            console.log('所有文章數據:', allPosts);
            console.log('要篩選的分類slug:', categorySlug);
            
            // 按分類篩選文章
            const filteredPosts = allPosts.filter(post => {
                const postCategory = post.category;
                console.log('文章分類信息:', postCategory);
                
                if (!postCategory) {
                    // 如果文章沒有分類，檢查是否查找"未分類"
                    return categorySlug === 'uncategorized' || categorySlug === '未分類';
                }
                
                // 多種匹配方式
                const categorySlugMatch = postCategory.slug === categorySlug;
                const categoryNameMatch = postCategory.name === categorySlug;
                const categoryNameLowerMatch = postCategory.name && 
                    postCategory.name.toLowerCase() === categorySlug.toLowerCase();
                const categoryPartialMatch = postCategory.name && 
                    postCategory.name.includes(categorySlug);
                
                // 檢查是否為中文分類名稱的直接匹配
                const chineseNameMatch = postCategory.name === this.getCategoryDisplayName(categorySlug);
                
                const isMatch = categorySlugMatch || categoryNameMatch || 
                              categoryNameLowerMatch || categoryPartialMatch || 
                              chineseNameMatch;
                
                if (isMatch) {
                    console.log(`文章 "${post.title}" 匹配分類 "${categorySlug}"`);
                }
                
                return isMatch;
            });
            
            console.log(`前端篩選分類 ${categorySlug} 的文章:`, filteredPosts);
            return filteredPosts;
            
        } catch (error) {
            console.error('前端分類篩選失敗:', error);
            return [];
        }
    }
    
    // 獲取分類顯示名稱
    getCategoryDisplayName(categorySlug) {
        const categoryMap = {
            // 主要分類
            'tech-sharing': '技術分享',
            'life-diary': '生活日記',
            'tutorial': '教學文章',
            
            // 中文slug支持
            '技術分享': '技術分享',
            '生活日記': '生活日記',
            '教學文章': '教學文章',
            
            // 備用分類
            'all': '全部',
            'uncategorized': '未分類',
            
            // 舊分類的映射支持（向後兼容）
            'tech-notes': '技術分享',
            'life-notes': '生活日記',
            'study-notes': '教學文章',
            'frontend': '技術分享',
            'backend': '技術分享',
            'programming': '技術分享'
        };
        
        return categoryMap[categorySlug] || categorySlug;
    }
    
    // 按標籤篩選文章
    async filterByTag(tagSlug) {
        try {
            const mainContent = document.querySelector('#posts-container');
            if (mainContent) {
                // 顯示標籤篩選標題
                const tagName = this.getTagDisplayName(tagSlug);
                const headerHtml = `
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h2 class="fw-bold mb-2">
                                        <i class="fas fa-tag me-2 text-primary"></i>標籤：${tagName}
                                    </h2>
                                    <p class="text-muted mb-0">查看標籤「${tagName}」的所有文章</p>
                                </div>
                                <div class="d-flex gap-2">
                                    <button class="btn btn-outline-primary" onclick="BlogApp.loadAllPosts()">
                                        <i class="fas fa-home me-1"></i>返回首頁
                                    </button>
                                    <button class="btn btn-outline-secondary" onclick="BlogApp.loadAuthorsList()">
                                        <i class="fas fa-users me-1"></i>作者列表
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="articles-container">
                        <!-- 文章將在這裡載入 -->
                    </div>
                `;
                
                mainContent.innerHTML = headerHtml;
                
                // 載入該標籤的文章
                const posts = await this.loadPostsByTag(tagSlug);
                console.log(`載入標籤 ${tagSlug} 的文章:`, posts);
                
                // 渲染文章列表
                this.renderPosts(posts);
                
                // 顯示成功消息
                Utils.showToast(`已載入標籤「${tagName}」的文章`, 'success');
            }
        } catch (error) {
            console.error('標籤篩選失敗:', error);
            Utils.showToast('標籤篩選失敗，請稍後再試', 'danger');
        }
    }
    
    // 載入指定標籤的文章
    async loadPostsByTag(tagSlug) {
        try {
            console.log('開始載入標籤文章:', tagSlug);
            // 後端暫不支持標籤篩選，直接使用前端篩選
            return this.filterPostsByTag(tagSlug);
            
        } catch (error) {
            console.error('標籤篩選失敗:', error);
            return [];
        }
    }
    
    // 前端標籤篩選（備用方案）
    async filterPostsByTag(tagSlug) {
        try {
            console.log('前端篩選標籤:', tagSlug);
            
            // 從 DataLoader 獲取所有文章
            const allPosts = await DataLoader.loadPosts(1, true);
            console.log('獲取的所有文章:', allPosts);
            
            // 檢查第一篇文章的標籤結構
            if (allPosts.length > 0) {
                console.log('第一篇文章的標籤結構:', allPosts[0].tags);
            }
            
            // 按標籤篩選文章
            const filteredPosts = allPosts.filter(post => {
                const postTags = post.tags;
                console.log(`檢查文章 "${post.title}" 的標籤:`, postTags);
                
                if (!postTags || !Array.isArray(postTags)) {
                    console.log('文章沒有標籤或標籤不是數組');
                    return false;
                }
                
                // 檢查是否有標籤匹配
                const hasMatch = postTags.some(tag => {
                    const tagSlugMatch = tag.slug === tagSlug;
                    const tagNameMatch = tag.name && 
                        tag.name.toLowerCase().includes(tagSlug.toLowerCase());
                    const directMatch = tag === tagSlug; // 處理字符串格式的標籤
                    const lowerCaseMatch = typeof tag === 'string' && 
                        tag.toLowerCase() === tagSlug.toLowerCase();
                    
                    console.log(`標籤比較:`, {
                        tag,
                        tagSlug,
                        tagSlugMatch,
                        tagNameMatch,
                        directMatch,
                        lowerCaseMatch
                    });
                    
                    return tagSlugMatch || tagNameMatch || directMatch || lowerCaseMatch;
                });
                
                console.log(`文章 "${post.title}" 匹配結果:`, hasMatch);
                return hasMatch;
            });
            
            console.log(`前端篩選標籤 ${tagSlug} 的文章:`, filteredPosts);
            return filteredPosts;
            
        } catch (error) {
            console.error('前端標籤篩選失敗:', error);
            return [];
        }
    }
    
    // 獲取標籤顯示名稱
    getTagDisplayName(tagSlug) {
        const tagMap = {
            'javascript': 'JavaScript',
            'react': 'React',
            'vue': 'Vue',
            'java': 'Java',
            'spring-boot': 'Spring Boot',
            'sql': 'SQL',
            'docker': 'Docker',
            'kubernetes': 'Kubernetes',
            'aws': 'AWS',
            'azure': 'Azure',
            'python': 'Python',
            'nodejs': 'Node.js',
            'typescript': 'TypeScript',
            'css': 'CSS',
            'html': 'HTML',
            'git': 'Git',
            'linux': 'Linux',
            'microservices': '微服務',
            'api': 'API',
            'testing': '測試'
        };
        
        return tagMap[tagSlug] || tagSlug;
    }
    
    // 綁定登出事件
    bindLogoutEvent(logoutLink) {
        // 移除舊的事件監聽器
        logoutLink.removeEventListener('click', this.handleLogout);
        
        // 添加新的事件監聽器
        this.handleLogout = (e) => {
            e.preventDefault();
            this.logout();
        };
        
        logoutLink.addEventListener('click', this.handleLogout);
    }
    
    // 處理登出
    async logout() {
        try {
            // 調用後端登出 API
            await BlogAPI.auth.logout();
            
            // 清除本地認證信息
            window.AuthManager.removeToken();
            
            // 顯示成功消息
            Utils.showToast('登出成功！', 'success');
            
            // 重新初始化認證狀態
            this.initializeAuth();
            
            // 觸發認證狀態變化事件
            window.dispatchEvent(new CustomEvent('authStateChanged', {
                detail: { isLoggedIn: false }
            }));
            
            // 檢查當前是否在文章詳情頁面
            const currentPostId = commentManager?.currentPostId;
            if (currentPostId && window.commentManager) {
                // 如果在文章詳情頁面，重新渲染評論列表
                console.log('登出後重新渲染評論列表');
                try {
                    // 強制重新渲染評論，確保權限檢查生效
                    const storedComments = commentManager.comments.get(currentPostId) || [];
                    commentManager.renderComments(storedComments);
                    console.log('評論重新渲染完成');
                } catch (error) {
                    console.error('重新渲染評論失敗:', error);
                }
            }
            
            // 清除 URL 參數並回到首頁
            const url = new URL(window.location);
            url.searchParams.delete('page');
            
            // 使用導航管理器
            if (window.navigationManager) {
                window.navigationManager.navigateTo(url.href, '首頁');
            } else {
                window.history.pushState({}, '', url);
            }
            
            // 重新載入頁面內容（登出後顯示首頁）
            this.loadPosts();
            
        } catch (error) {
            console.error('登出失敗:', error);
            
            // 即使後端失敗，也要清除本地認證信息
            window.AuthManager.removeToken();
            Utils.showToast('登出成功！', 'success');
            
            // 重新初始化認證狀態
            this.initializeAuth();
            
            // 觸發認證狀態變化事件
            window.dispatchEvent(new CustomEvent('authStateChanged', {
                detail: { isLoggedIn: false }
            }));
            
            // 檢查當前是否在文章詳情頁面
            const currentPostId = commentManager?.currentPostId;
            if (currentPostId && window.commentManager) {
                // 如果在文章詳情頁面，重新渲染評論列表
                console.log('登出後重新渲染評論列表');
                try {
                    // 強制重新渲染評論，確保權限檢查生效
                    const storedComments = commentManager.comments.get(currentPostId) || [];
                    commentManager.renderComments(storedComments);
                    console.log('評論重新渲染完成');
                } catch (error) {
                    console.error('重新渲染評論失敗:', error);
                }
            }
            
            // 清除 URL 參數並回到首頁
            const url = new URL(window.location);
            url.searchParams.delete('page');
            
            // 使用導航管理器
            if (window.navigationManager) {
                window.navigationManager.navigateTo(url.href, '首頁');
            } else {
                window.history.pushState({}, '', url);
            }
            
            // 重新載入頁面內容（登出後顯示首頁）
            this.loadPosts();
        }
    }
    
    // 🔥 點讚文章功能
    async likePost(postId, slug, buttonElement) {
        try {
            // 檢查用戶是否已登入
                    if (!window.AuthManager.isLoggedIn()) {
            Utils.showToast('請先登入才能點讚', 'warning');
            return;
        }
            
            // 檢查是否已經點過讚（使用localStorage記錄）
            const likedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]');
            const currentUser = this.getCurrentUserInfo();
            const userLikeKey = `${currentUser?.username || 'guest'}_${slug}`;
            
            // 判斷是點讚還是取消點讚
            const isAlreadyLiked = likedPosts.includes(userLikeKey);
            
            // 禁用按鈕防止重複點擊
            const allLikeButtons = document.querySelectorAll(`[id*="like-btn"][id*="${slug}"]`);
            allLikeButtons.forEach(btn => {
                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>處理中...';
            });
            
            try {
                let likeCountChange = 0;
                let successMessage = '';
                let newButtonState = {};
                
                if (isAlreadyLiked) {
                    // 取消點讚
                    await BlogAPI.posts.unlike(postId);
                    
                    // 從記錄中移除
                    const updatedLikedPosts = likedPosts.filter(key => key !== userLikeKey);
                    localStorage.setItem('likedPosts', JSON.stringify(updatedLikedPosts));
                    
                    likeCountChange = -1;
                    successMessage = '已取消點讚';
                    newButtonState = {
                        classes: ['btn-outline-light', 'like-button'],
                        removeClasses: ['btn-success', 'liked'],
                        innerHTML: '<i class="fas fa-thumbs-up me-1"></i>喜歡'
                    };
                } else {
                    // 添加點讚
                    await BlogAPI.posts.like(postId);
                    
                    // 記錄點讚狀態
                    likedPosts.push(userLikeKey);
                    localStorage.setItem('likedPosts', JSON.stringify(likedPosts));
                    
                    likeCountChange = 1;
                    successMessage = '點讚成功！';
                    newButtonState = {
                        classes: ['btn-success', 'liked', 'like-button'],
                        removeClasses: ['btn-outline-light', 'btn-outline-primary'],
                        innerHTML: '<i class="fas fa-heart me-1"></i>已讚'
                    };
                }
                
                // 更新UI中的點讚數量
                const likeCountDisplayElements = document.querySelectorAll('.like-count-display');
                likeCountDisplayElements.forEach(element => {
                    const currentCount = parseInt(element.textContent) || 0;
                    const newCount = Math.max(0, currentCount + likeCountChange);
                    element.textContent = newCount;
                });
                
                // 更新按鈕狀態
                allLikeButtons.forEach(btn => {
                    btn.disabled = false;
                    // 移除舊類別
                    if (newButtonState.removeClasses) {
                        btn.classList.remove(...newButtonState.removeClasses);
                    }
                    // 添加新類別
                    btn.classList.add(...newButtonState.classes);
                    btn.innerHTML = newButtonState.innerHTML;
                    // 保持點擊事件以支持再次點擊
                    btn.onclick = () => BlogApp.likePost(postId, slug, btn);
                });
                
                Utils.showToast(successMessage, 'success');
                
            } catch (apiError) {
                console.error('API操作失敗:', apiError);
                
                // API失敗時恢復按鈕狀態
                allLikeButtons.forEach(btn => {
                    btn.disabled = false;
                    if (isAlreadyLiked) {
                        btn.classList.remove('btn-outline-light');
                        btn.classList.add('btn-success', 'liked', 'like-button');
                        btn.innerHTML = `<i class="fas fa-heart me-1"></i>已讚`;
                    } else {
                        btn.classList.remove('btn-success', 'liked');
                        btn.classList.add('btn-outline-light', 'like-button');
                        btn.innerHTML = `<i class="fas fa-thumbs-up me-1"></i>喜歡`;
                    }
                    btn.onclick = () => BlogApp.likePost(postId, slug, btn);
                });
                
                Utils.showToast('操作失敗，請重試', 'error');
            }
            
        } catch (error) {
            console.error('點讚失敗:', error);
            Utils.showToast('點讚失敗，請稍後再試', 'danger');
            
            // 恢復按鈕狀態
            const allLikeButtons = document.querySelectorAll(`[id*="like-btn"][id*="${slug}"]`);
            allLikeButtons.forEach(btn => {
                btn.disabled = false;
                btn.innerHTML = `<i class="fas fa-thumbs-up me-1"></i>喜歡`;
            });
        }
    }
    
    // 檢查文章是否已被當前用戶點讚
    checkPostLikeStatus(slug) {
        const likedPosts = JSON.parse(localStorage.getItem('likedPosts') || '[]');
        const currentUser = this.getCurrentUserInfo();
        const userLikeKey = `${currentUser?.username || 'guest'}_${slug}`;
        return likedPosts.includes(userLikeKey);
    }

    // 編輯文章
    editPost(slug) {
        try {
            console.log('編輯文章:', slug);
            // 跳轉到編輯頁面，傳遞文章 slug
            window.location.href = `write.html?edit=${slug}`;
        } catch (error) {
            console.error('編輯文章失敗:', error);
            Utils.showToast('編輯文章失敗', 'error');
        }
    }

    // 刪除文章
    async deletePost(identifier) {
        try {
            if (!confirm('確定要刪除這篇文章嗎？此操作無法撤銷。')) {
                return;
            }

            console.log('刪除文章標識符:', identifier);
            
            // 獲取當前用戶信息用於調試
            const currentUser = this.getCurrentUserInfo();
            console.log('當前用戶信息:', currentUser);
            
            // 顯示載入狀態
            Utils.showToast('正在刪除文章...', 'info');
            
            // 確定要使用的刪除 ID
            let deleteId = identifier;
            
            // 如果傳入的是 slug，嘗試獲取數字 ID
            if (isNaN(identifier)) {
                console.log('傳入的是 slug，嘗試獲取數字 ID');
                try {
                    const post = await BlogAPI.posts.getBySlug(identifier);
                    deleteId = post.id || post.postId;
                    console.log('從 slug 獲取到文章 ID:', deleteId);
                } catch (error) {
                    console.warn('無法根據 slug 獲取文章詳情:', error);
                    // 如果無法獲取，直接使用 slug
                    deleteId = identifier;
                }
            } else {
                // 如果傳入的是數字，直接使用
                deleteId = parseInt(identifier);
                console.log('使用數字 ID:', deleteId);
            }
            
            // 嘗試調用 API 刪除文章
            try {
                console.log('最終使用的刪除 ID:', deleteId, '類型:', typeof deleteId);
                
                await BlogAPI.posts.delete(deleteId);
                console.log('文章刪除成功');
                Utils.showToast('文章刪除成功', 'success');
                
                // 更新頁尾統計數據
                this.updateFooterStats();
                
                // 刪除成功後跳轉回首頁
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1500);
                
            } catch (apiError) {
                console.warn('API 刪除失敗，檢查錯誤詳情:', apiError);
                console.log('錯誤狀態碼:', apiError.status);
                console.log('錯誤信息:', apiError.message);
                
                // 檢查是否是權限問題
                if (apiError.status === 400) {
                    Utils.showToast('無法刪除文章：可能是權限不足或文章不存在', 'warning');
                    console.log('400 錯誤 - 可能是權限問題或文章不存在');
                } else if (apiError.status === 403) {
                    Utils.showToast('無法刪除文章：沒有權限', 'warning');
                    console.log('403 錯誤 - 權限不足');
                } else if (apiError.status === 404) {
                    Utils.showToast('文章不存在', 'warning');
                    console.log('404 錯誤 - 文章不存在');
                } else if (apiError.status === 401) {
                    Utils.showToast('請先登入', 'warning');
                    console.log('401 錯誤 - 未登入');
                } else {
                    // 其他錯誤，使用模擬模式
                    console.log('使用模擬刪除模式，錯誤狀態碼:', apiError.status);
                    Utils.showToast('文章已刪除（離線模式）', 'success');
                    
                    // 更新頁尾統計數據
                    this.updateFooterStats();
                    
                    // 模擬刪除成功後跳轉回首頁
                    setTimeout(() => {
                        window.location.href = 'index.html';
                    }, 1500);
                }
            }
            
        } catch (error) {
            console.error('刪除文章失敗:', error);
            Utils.showToast('刪除文章失敗，請稍後再試', 'error');
        }
    }

    // 更新頁尾統計數據
    async updateFooterStats() {
        try {
            console.log('更新頁尾統計數據...');
            
            // 獲取文章數據
            const postsResponse = await BlogAPI.posts.getList();
            const posts = postsResponse?.content || postsResponse?.data || [];
            
            // 計算總瀏覽次數
            const totalViews = posts.reduce((sum, post) => sum + (post.viewCount || 0), 0);
            
            // 獲取用戶數據（基於現有的測試用戶）
            const totalUsers = 5; // admin, alice, bob, carol, david
            
            // 更新頁尾統計
            const postsElement = document.getElementById('footer-total-posts');
            const usersElement = document.getElementById('footer-total-users');
            const viewsElement = document.getElementById('footer-total-views');
            
            if (postsElement) postsElement.textContent = posts.length;
            if (usersElement) usersElement.textContent = totalUsers;
            if (viewsElement) viewsElement.textContent = totalViews;
            
            console.log('頁尾統計數據已更新:', {
                posts: posts.length,
                users: totalUsers,
                views: totalViews
            });
            
        } catch (error) {
            console.error('更新頁尾統計數據失敗:', error);
        }
    }
}

// 頁面載入完成後初始化
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOMContentLoaded 事件觸發，開始創建 BlogApp 實例');
    
    // 創建應用實例
    const blogApp = new BlogAppClass();
    console.log('BlogApp 實例創建完成:', blogApp);
    
    // 暴露到全局
    window.BlogApp = blogApp;
    console.log('BlogApp 已暴露到全局');
    
    // 初始化應用
    blogApp.init();
    console.log('BlogApp 初始化完成');
});

