/**
 * 渲染器類
 * 負責渲染各種 UI 組件
 */

const Renderers = {
    // 渲染分類列表
    renderCategories(categories) {
        const categoriesList = document.getElementById('categories-list');
        if (!categoriesList) return;
        
        // 添加「全部」選項
        let html = `
            <a href="#" onclick="BlogApp.loadAllPosts(); return false;" class="category-item">
                <span>全部</span>
                <span class="category-count">
                    <i class="fas fa-list-ul"></i>
                </span>
            </a>
        `;
        
        if (!categories || !Array.isArray(categories) || categories.length === 0) {
            categoriesList.innerHTML = html + '<p class="text-muted mt-2">暫無分類</p>';
            return;
        }
        
        html += categories.map(category => `
            <a href="#" onclick="BlogApp.filterByCategory('${category.slug}'); return false;" class="category-item">
                <span>${category.name}</span>
                <span class="category-count">${category.postCount || 0}</span>
            </a>
        `).join('');
        
        categoriesList.innerHTML = html;
        
        // 更新導航選單
        const categoriesMenu = document.getElementById('categories-menu');
        if (categoriesMenu) {
            let menuHtml = `
                <li><a class="dropdown-item" href="#" onclick="BlogApp.loadAllPosts(); return false;">
                    <i class="fas fa-list-ul me-2"></i>全部
                </a></li>
                <li><hr class="dropdown-divider"></li>
            `;
            
            menuHtml += categories.map(category => `
                <li><a class="dropdown-item" href="#" onclick="BlogApp.filterByCategory('${category.slug}'); return false;">${category.name}</a></li>
            `).join('');
            
            categoriesMenu.innerHTML = menuHtml;
        }
    },
    
    // 渲染標籤雲
    renderTagsCloud(tags) {
        const tagsCloud = document.getElementById('tags-cloud');
        if (!tagsCloud) return;
        
        if (!tags || !Array.isArray(tags) || tags.length === 0) {
            tagsCloud.innerHTML = '<p class="text-muted">暫無標籤</p>';
            return;
        }
        
        // ✅ 顯示所有標籤，包括使用次數為 0 的標籤
        const html = tags.map(tag => {
            const color = Utils.generateColor();
            const usageCount = tag.usageCount || 0;
            return `
                <a href="#" onclick="BlogApp.filterByTag('${tag.slug}'); return false;" 
                   class="badge bg-${color} text-decoration-none me-1 mb-1">
                    ${tag.name} ${usageCount > 0 ? '(' + usageCount + ')' : ''}
                </a>
            `;
        }).join('');
        
        tagsCloud.innerHTML = html;
    },
    
    // 渲染最新評論
    renderRecentComments(comments) {
        const recentComments = document.getElementById('recent-comments');
        if (!recentComments) return;
        
        if (!comments || comments.length === 0) {
            recentComments.innerHTML = `
                <div class="text-center text-muted py-3">
                    <i class="fas fa-comment-slash fa-2x mb-2"></i>
                    <p class="mb-0">暫無評論</p>
                    <small>成為第一個評論的人！</small>
                </div>
            `;
            return;
        }
        
        const html = comments.map(comment => {
            const authorName = comment.author?.displayName || comment.authorName || '匿名用戶';
            const content = Utils.truncateText(comment.content, 80) || '無內容';
            const date = Utils.formatDate(comment.createdAt);
            const postTitle = comment.postTitle || '未知文章';
            const postSlug = comment.postSlug || comment.postId;
            
            return `
                <div class="recent-comment-item">
                    <div class="comment-header">
                        <div class="comment-author">
                            <div class="author-avatar">
                                ${authorName.charAt(0).toUpperCase()}
                            </div>
                            <div class="author-info">
                                <div class="author-name">${authorName}</div>
                                <div class="comment-date">${date}</div>
                            </div>
                        </div>
                    </div>
                    <div class="comment-content">
                        ${content}
                    </div>
                    <div class="comment-post">
                        <span class="post-info">
                            <i class="fas fa-newspaper me-1"></i>
                            ${Utils.truncateText(postTitle, 30)}
                        </span>
                    </div>
                </div>
            `;
        }).join('');
        
        recentComments.innerHTML = html;
    },
    
    // 🎨 渲染現代化文章卡片
    renderPostCard(post) {
        const imageUrl = post.featuredImage || 'images/placeholders/post-default.svg';
        const categoryName = post.category?.name || '未分類';
        const authorName = post.author?.displayName || post.author?.username || '未知作者';
        const authorInitial = authorName.charAt(0).toUpperCase();
        
        return `
            <div class="col-md-6 col-lg-4 mb-4">
                <article class="card post-card h-100 animate-fadeInUp" onclick="BlogApp.viewPost('${post.slug}')">
                    <div class="post-image-container">
                        <img src="${imageUrl}" class="card-img-top" alt="${post.title}">
                        <div class="post-category">${categoryName}</div>
                    </div>
                    
                    <div class="card-body">
                        <!-- 👤 作者信息 -->
                        <div class="post-author">
                            <div class="post-author-avatar">
                                ${authorInitial}
                            </div>
                            <div class="post-author-info">
                                <p class="post-author-name">${authorName}</p>
                                <p class="post-date">${Utils.formatDate(post.publishedAt || post.createdAt)}</p>
                            </div>
                        </div>
                        
                        <!-- 📝 文章標題 -->
                        <h5 class="card-title">${post.title}</h5>
                        
                        <!-- 📖 文章摘要 -->
                        <p class="card-text post-excerpt">
                            ${Utils.truncateText(post.excerpt || post.content, 120)}
                        </p>
                        
                        <!-- 📊 文章統計 -->
                        <div class="post-stats">
                            <div class="post-stat">
                                <i class="fas fa-eye"></i>
                                <span>${post.viewCount || 0}</span>
                            </div>
                            <div class="post-stat">
                                <i class="fas fa-heart"></i>
                                <span>${post.likeCount || 0}</span>
                            </div>
                            <div class="post-stat">
                                <i class="fas fa-comment"></i>
                                <span>${post.commentCount || 0}</span>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
        `;
    }
};

// 暴露到全局
window.Renderers = Renderers;
