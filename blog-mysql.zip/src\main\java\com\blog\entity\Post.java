package com.blog.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 文章實體類別
 * 對應資料庫 Posts 表格
 */
@Entity
@Table(name = "Posts")
@EntityListeners(AuditingEntityListener.class)
public class Post {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PostId")
    private Integer postId;
    
    @NotBlank(message = "文章標題不能為空")
    @Size(max = 200, message = "文章標題不能超過200個字元")
    @Column(name = "Title", nullable = false, length = 200)
    private String title;
    
    @NotBlank(message = "文章路徑不能為空")
    @Size(max = 200, message = "文章路徑不能超過200個字元")
    @Column(name = "Slug", unique = true, nullable = false, length = 200)
    private String slug;
    
    @Size(max = 500, message = "文章摘要不能超過500個字元")
    @Column(name = "Excerpt", length = 500)
    private String excerpt;
    
    @NotBlank(message = "文章內容不能為空")
    @Lob
    @Column(name = "Content", nullable = false, columnDefinition = "NTEXT")
    private String content;
    
    @Size(max = 500, message = "特色圖片路徑不能超過500個字元")
    @Column(name = "FeaturedImage", length = 500)
    private String featuredImage;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "Status", length = 20)
    private PostStatus status = PostStatus.DRAFT;
    
    @Column(name = "IsCommentEnabled")
    private Boolean isCommentEnabled = true;
    
    @Column(name = "IsFeatured")
    private Boolean isFeatured = false;
    
    @Column(name = "ViewCount")
    private Integer viewCount = 0;
    
    @Column(name = "LikeCount")
    private Integer likeCount = 0;
    
    @Size(max = 200, message = "SEO標題不能超過200個字元")
    @Column(name = "MetaTitle", length = 200)
    private String metaTitle;
    
    @Size(max = 300, message = "SEO描述不能超過300個字元")
    @Column(name = "MetaDescription", length = 300)
    private String metaDescription;
    
    @Size(max = 500, message = "SEO關鍵字不能超過500個字元")
    @Column(name = "MetaKeywords", length = 500)
    private String metaKeywords;
    
    @CreatedDate
    @Column(name = "CreatedAt", updatable = false)
    private LocalDateTime createdAt;
    
    @LastModifiedDate
    @Column(name = "UpdatedAt")
    private LocalDateTime updatedAt;
    
    @Column(name = "PublishedAt")
    private LocalDateTime publishedAt;
    
    // 關聯關係
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "AuthorId", nullable = false)
    private User author;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CategoryId")
    private Category category;
    
    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Comment> comments;
    
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "PostTags",
        joinColumns = @JoinColumn(name = "PostId"),
        inverseJoinColumns = @JoinColumn(name = "TagId")
    )
    private List<Tag> tags;
    
    // 預設建構子
    public Post() {}
    
    // 建構子
    public Post(String title, String content, User author) {
        this.title = title;
        this.content = content;
        this.author = author;
    }
    
    // Getters and Setters
    public Integer getPostId() { return postId; }
    public void setPostId(Integer postId) { this.postId = postId; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getSlug() { return slug; }
    public void setSlug(String slug) { this.slug = slug; }
    
    public String getExcerpt() { return excerpt; }
    public void setExcerpt(String excerpt) { this.excerpt = excerpt; }
    
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    
    public String getFeaturedImage() { return featuredImage; }
    public void setFeaturedImage(String featuredImage) { this.featuredImage = featuredImage; }
    
    public PostStatus getStatus() { return status; }
    public void setStatus(PostStatus status) { this.status = status; }
    
    public Boolean getIsCommentEnabled() { return isCommentEnabled; }
    public void setIsCommentEnabled(Boolean isCommentEnabled) { this.isCommentEnabled = isCommentEnabled; }
    
    public Boolean getIsFeatured() { return isFeatured; }
    public void setIsFeatured(Boolean isFeatured) { this.isFeatured = isFeatured; }
    
    public Integer getViewCount() { return viewCount; }
    public void setViewCount(Integer viewCount) { this.viewCount = viewCount; }
    
    public Integer getLikeCount() { return likeCount; }
    public void setLikeCount(Integer likeCount) { this.likeCount = likeCount; }
    
    public String getMetaTitle() { return metaTitle; }
    public void setMetaTitle(String metaTitle) { this.metaTitle = metaTitle; }
    
    public String getMetaDescription() { return metaDescription; }
    public void setMetaDescription(String metaDescription) { this.metaDescription = metaDescription; }
    
    public String getMetaKeywords() { return metaKeywords; }
    public void setMetaKeywords(String metaKeywords) { this.metaKeywords = metaKeywords; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    
    public LocalDateTime getPublishedAt() { return publishedAt; }
    public void setPublishedAt(LocalDateTime publishedAt) { this.publishedAt = publishedAt; }
    
    public User getAuthor() { return author; }
    public void setAuthor(User author) { this.author = author; }
    
    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }
    
    public List<Comment> getComments() { return comments; }
    public void setComments(List<Comment> comments) { this.comments = comments; }
    
    public List<Tag> getTags() { return tags; }
    public void setTags(List<Tag> tags) { this.tags = tags; }
}

 