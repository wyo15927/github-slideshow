package com.blog.service;

import com.blog.entity.User;
import com.blog.entity.UserRole;
import com.blog.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * 使用者業務邏輯服務
 */
@Service
@Transactional
public class UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    /**
     * 用戶註冊
     * @param username 用戶名
     * @param email 電子郵件
     * @param password 密碼
     * @param displayName 顯示名稱
     * @return 註冊成功的用戶
     * @throws RuntimeException 如果用戶名或郵件已存在
     */
    public User registerUser(String username, String email, String password, String displayName) {
        // 檢查用戶名是否已存在
        if (userRepository.findByUsername(username).isPresent()) {
            throw new RuntimeException("用戶名已存在");
        }
        
        // 檢查郵件是否已存在
        if (userRepository.findByEmail(email).isPresent()) {
            throw new RuntimeException("電子郵件已存在");
        }
        
        // 創建新用戶
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPasswordHash(passwordEncoder.encode(password));
        user.setDisplayName(displayName);
        user.setRole(UserRole.USER); // 註冊的用戶預設為普通會員
        user.setIsActive(true);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        
        return userRepository.save(user);
    }
    
    /**
     * 根據ID查找使用者
     */
    @Transactional(readOnly = true)
    public Optional<User> findById(Integer userId) {
        return userRepository.findById(userId);
    }
    
    /**
     * 根據使用者名稱查找使用者
     */
    @Transactional(readOnly = true)
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
    
    /**
     * 根據使用者名稱查找使用者（包含文章關聯）
     */
    @Transactional(readOnly = true)
    public Optional<User> findByUsernameWithPosts(String username) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            // 觸發懶載入以確保 posts 關聯被加載
            if (user.getPosts() != null) {
                user.getPosts().size(); // 觸發懶載入
            }
        }
        return userOpt;
    }
    
    /**
     * 根據電子郵件查找使用者
     */
    @Transactional(readOnly = true)
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    
    /**
     * 創建新使用者
     */
    public User createUser(User user) {
        // 驗證使用者名稱唯一性
        if (userRepository.existsByUsername(user.getUsername())) {
            throw new RuntimeException("使用者名稱已存在");
        }
        
        // 驗證電子郵件唯一性
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new RuntimeException("電子郵件已存在");
        }
        
        // 加密密碼
        user.setPasswordHash(passwordEncoder.encode(user.getPasswordHash()));
        
        // 設定預設值
        if (user.getDisplayName() == null || user.getDisplayName().isEmpty()) {
            user.setDisplayName(user.getUsername());
        }
        
        return userRepository.save(user);
    }
    
    /**
     * 更新使用者資訊
     */
    public User updateUser(Integer userId, User updatedUser) {
        User existingUser = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("使用者不存在"));
        
        // 檢查使用者名稱唯一性（排除當前使用者）
        if (!existingUser.getUsername().equals(updatedUser.getUsername()) &&
            userRepository.existsByUsername(updatedUser.getUsername())) {
            throw new RuntimeException("使用者名稱已存在");
        }
        
        // 檢查電子郵件唯一性（排除當前使用者）
        if (!existingUser.getEmail().equals(updatedUser.getEmail()) &&
            userRepository.existsByEmail(updatedUser.getEmail())) {
            throw new RuntimeException("電子郵件已存在");
        }
        
        // 更新欄位（不包括密碼）
        existingUser.setUsername(updatedUser.getUsername());
        existingUser.setEmail(updatedUser.getEmail());
        existingUser.setDisplayName(updatedUser.getDisplayName());
        existingUser.setAvatar(updatedUser.getAvatar());
        existingUser.setProfession(updatedUser.getProfession());
        existingUser.setBio(updatedUser.getBio());
        existingUser.setLocation(updatedUser.getLocation());
        existingUser.setWebsite(updatedUser.getWebsite());
        existingUser.setRole(updatedUser.getRole());
        existingUser.setIsActive(updatedUser.getIsActive());
        
        return userRepository.save(existingUser);
    }
    
    /**
     * 更新使用者資訊（重載方法，直接保存User對象）
     */
    public User updateUser(User user) {
        return userRepository.save(user);
    }
    
    /**
     * 更新使用者密碼
     */
    public void updatePassword(Integer userId, String newPassword) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("使用者不存在"));
        
        // 加密新密碼
        user.setPasswordHash(passwordEncoder.encode(newPassword));
        userRepository.save(user);
    }
    
    /**
     * 驗證使用者密碼
     */
    @Transactional(readOnly = true)
    public boolean validatePassword(String username, String password) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isEmpty()) {
            return false;
        }
        
        User user = userOpt.get();
        return passwordEncoder.matches(password, user.getPasswordHash());
    }
    
    /**
     * 認證使用者
     */
    @Transactional(readOnly = true)
    public Optional<User> authenticate(String username, String password) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isEmpty()) {
            return Optional.empty();
        }
        
        User user = userOpt.get();
        if (!user.getIsActive()) {
            throw new RuntimeException("使用者帳號已被停用");
        }
        
        System.out.println("輸入密碼: " + password);
        System.out.println("資料庫雜湊: " + user.getPasswordHash());
        System.out.println("雜湊比對結果: " + passwordEncoder.matches(password, user.getPasswordHash()));
        
        // 測試：生成正確的雜湊值
        String correctHash = passwordEncoder.encode("admin");
        System.out.println("正確的 admin 雜湊值: " + correctHash);
        System.out.println("新雜湊驗證: " + passwordEncoder.matches("admin", correctHash));
        
        if (passwordEncoder.matches(password, user.getPasswordHash())) {
            // 更新最後登入時間
            user.setLastLoginAt(LocalDateTime.now());
            userRepository.save(user);
            return Optional.of(user);
        }
        
        return Optional.empty();
    }
    
    /**
     * 更新最後登入時間
     */
    public void updateLastLoginTime(Integer userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("使用者不存在"));
        
        user.setLastLoginAt(LocalDateTime.now());
        userRepository.save(user);
    }
    
    /**
     * 刪除使用者
     */
    public void deleteUser(Integer userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("使用者不存在"));
        
        // 檢查是否有文章
        if (!user.getPosts().isEmpty()) {
            throw new RuntimeException("此使用者還有文章，無法刪除");
        }
        
        userRepository.delete(user);
    }
    
    /**
     * 啟用/禁用使用者
     */
    public User toggleUserStatus(Integer userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("使用者不存在"));
        
        user.setIsActive(!user.getIsActive());
        return userRepository.save(user);
    }
    
    /**
     * 搜尋使用者
     */
    @Transactional(readOnly = true)
    public Page<User> searchUsers(String keyword, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return userRepository.searchUsers(keyword, pageable);
    }
    
    /**
     * 根據角色查找使用者
     */
    @Transactional(readOnly = true)
    public Page<User> findUsersByRole(String role, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return userRepository.findByRole(role, pageable);
    }
    
    /**
     * 根據啟用狀態查找使用者
     */
    @Transactional(readOnly = true)
    public Page<User> findUsersByActiveStatus(Boolean isActive, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return userRepository.findByIsActive(isActive, pageable);
    }
    
    /**
     * 根據角色和狀態查找使用者
     */
    @Transactional(readOnly = true)
    public Page<User> findUsersByRoleAndStatus(String role, Boolean isActive, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return userRepository.findByRoleAndIsActive(role, isActive, pageable);
    }
    
    /**
     * 檢查使用者權限
     */
    @Transactional(readOnly = true)
    public boolean hasPermission(Integer userId, String permission) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("使用者不存在"));
        
        return switch (permission.toLowerCase()) {
            case "admin" -> "ADMIN".equals(user.getRole().name());
            case "author" -> "ADMIN".equals(user.getRole().name()) || "AUTHOR".equals(user.getRole().name());
            case "user" -> user.getIsActive();
            default -> false;
        };
    }
    
    /**
     * 檢查是否為管理員
     */
    @Transactional(readOnly = true)
    public boolean isAdmin(Integer userId) {
        return hasPermission(userId, "admin");
    }
    
    /**
     * 檢查是否為作者
     */
    @Transactional(readOnly = true)
    public boolean isAuthor(Integer userId) {
        return hasPermission(userId, "author");
    }
    
    /**
     * 獲取所有用戶（用於作者列表）
     */
    @Transactional(readOnly = true)
    public Page<User> getAllUsers(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return userRepository.findAll(pageable);
    }
    
    /**
     * 獲取所有用戶（不分頁）
     */
    @Transactional(readOnly = true)
    public java.util.List<User> getAllUsersList() {
        return userRepository.findAll();
    }
    
    /**
     * 獲取所有用戶並加載文章數據（用於作者列表）
     */
    @Transactional(readOnly = true)
    public java.util.List<User> getAllUsersWithPosts() {
        java.util.List<User> users = userRepository.findAll();
        // 觸發文章數據加載
        users.forEach(user -> {
            if (user.getPosts() != null) {
                user.getPosts().size(); // 觸發 lazy loading
            }
        });
        return users;
    }
} 