/**
 * 評論功能模組
 * 處理文章的評論功能，包括新增、編輯、刪除等
 */

class CommentManager {
    constructor() {
        this.currentPostId = null;
        this.comments = new Map(); // 臨時存儲評論數據
        this.loadStoredComments(); // 從 localStorage 載入已保存的評論
        this.init();
        
        // 添加調試方法到全域，方便測試
        window.commentManager = this;
        window.debugComments = {
            clearAll: () => {
                localStorage.removeItem('blog_comments');
                localStorage.removeItem('likedComments');
                this.comments.clear();
                console.log('已清除所有評論數據');
                // 重新載入頁面以確保狀態正確
                window.location.reload();
            },
            showAll: () => {
                console.log('=== 評論系統調試信息 ===');
                console.log('內存中的評論數據:', Object.fromEntries(this.comments));
                console.log('localStorage 中的評論數據:', localStorage.getItem('blog_comments'));
                console.log('點讚記錄:', JSON.parse(localStorage.getItem('likedComments') || '[]'));
                console.log('當前文章ID:', this.currentPostId);
                console.log('總評論數:', Array.from(this.comments.values()).reduce((total, comments) => total + comments.length, 0));
            },
            resetDefault: () => {
                this.comments.clear();
                localStorage.removeItem('blog_comments');
                localStorage.removeItem('likedComments');
                console.log('已重置，將重新創建默認評論');
                // 重新載入以觸發默認評論創建
                window.location.reload();
            },
            forceReload: () => {
                this.loadStoredComments();
                if (this.currentPostId) {
                    this.loadPostComments(this.currentPostId);
                }
                console.log('已強制重新載入評論數據');
            }
        };
    }
    
    init() {
        // 綁定全局事件
        this.bindEvents();
    }
    
    bindEvents() {
        // 移除舊的事件監聽器
        document.removeEventListener('submit', this.handleFormSubmit);
        
        // 添加新的事件監聽器
        this.handleFormSubmit = (e) => {
            if (e.target.id === 'new-comment-form') {
                e.preventDefault();
                this.submitComment();
            }
        };
        
        document.addEventListener('submit', this.handleFormSubmit);
    }
    
    // 從 localStorage 載入已保存的評論
    loadStoredComments() {
        try {
            const stored = localStorage.getItem('blog_comments');
            console.log('從 localStorage 讀取原始數據:', stored);
            
            if (stored) {
                const parsed = JSON.parse(stored);
                console.log('解析後的數據:', parsed);
                
                // 確保鍵值類型一致性：嘗試將數字字符串轉換為數字
                const entries = Object.entries(parsed).map(([key, value]) => {
                    // 如果鍵看起來像數字，轉換為數字
                    const numericKey = !isNaN(key) && !isNaN(parseFloat(key)) ? parseFloat(key) : key;
                    return [numericKey, value];
                });
                
                this.comments = new Map(entries);
                console.log('轉換為 Map 後:', this.comments);
                console.log('Map 的所有鍵:', Array.from(this.comments.keys()));
                console.log('鍵的類型:', Array.from(this.comments.keys()).map(k => typeof k));
                console.log('從 localStorage 載入評論 (全域共享):', Object.fromEntries(this.comments));
            } else {
                console.log('localStorage 中沒有評論數據，初始化空Map');
                this.comments = new Map();
            }
        } catch (error) {
            console.error('載入 localStorage 評論失敗:', error);
            this.comments = new Map();
        }
    }
    
    // 保存評論到 localStorage
    saveStoredComments() {
        try {
            const obj = Object.fromEntries(this.comments);
            localStorage.setItem('blog_comments', JSON.stringify(obj));
            console.log('保存評論到 localStorage (全域共享):', obj);
            console.log('保存的鍵值:', Object.keys(obj));
            console.log('當前 localStorage 大小:', JSON.stringify(obj).length, '字符');
        } catch (error) {
            console.error('保存評論到 localStorage 失敗:', error);
        }
    }
    
    // 設置當前文章ID
    setCurrentPostId(postId) {
        this.currentPostId = postId;
        console.log('設置當前文章ID:', postId, '(類型:', typeof postId, ')');
        console.log('當前存儲的評論:', this.comments);
        console.log('當前 Map 中的鍵:', Array.from(this.comments.keys()));
    }
    
    // 載入文章評論
    async loadPostComments(postId) {
        try {
            console.log('載入文章評論:', postId);
            
            // 確保 postId 是數字類型
            const numericPostId = parseInt(postId);
            if (isNaN(numericPostId)) {
                throw new Error('文章ID格式錯誤: ' + postId);
            }
            
            // 優先從後端 API 載入評論
            const response = await BlogAPI.comments.getByPost(numericPostId);
            console.log('後端 API 回應:', response);
            
            if (response && response.success && response.data) {
                const apiComments = response.data;
                console.log('從後端 API 載入評論:', apiComments);
                
                // 🆕 詳細日志：顯示每條評論的 likeCount
                apiComments.forEach((comment, index) => {
                    console.log(`評論 ${index + 1} (ID: ${comment.commentId}):`, {
                        author: comment.author?.displayName || comment.authorName,
                        likeCount: comment.likeCount,
                        content: comment.content.substring(0, 20) + '...'
                    });
                });
                
                // 更新本地存儲
                this.comments.set(postId, apiComments);
                this.saveStoredComments();
                
                // 渲染評論
                this.renderComments(apiComments);
                this.updateCommentCount(apiComments.length);
                return;
            }
            
            throw new Error('後端 API 返回空數據');
            
        } catch (error) {
            console.log('後端 API 載入失敗，使用本地存儲模式:', error.message);
            
            // 從臨時存儲中獲取評論
            let storedComments = this.comments.get(postId) || [];
            console.log('從臨時存儲載入評論:', { 
                postId: postId, 
                postIdType: typeof postId,
                storedComments: storedComments,
                allStoredComments: this.comments,
                allKeys: Array.from(this.comments.keys()),
                localStorage: localStorage.getItem('blog_comments')
            });
            
            // 如果沒有存儲的評論，顯示默認的模擬評論
            if (storedComments.length === 0) {
                console.log('當前文章沒有評論，檢查是否需要創建默認評論');
                
                // 檢查整個系統是否完全沒有評論數據
                const totalCommentsCount = Array.from(this.comments.values()).reduce((total, comments) => total + comments.length, 0);
                console.log('系統總評論數:', totalCommentsCount);
                
                // 只有在系統完全沒有任何評論時才創建默認評論
                if (totalCommentsCount === 0) {
                    console.log('系統首次使用，為當前文章創建默認評論');
                    const defaultComments = [
                        {
                            commentId: 1,
                            content: '這是一篇很棒的文章！感謝分享。',
                            authorName: 'Alice',
                            createdAt: '2025-08-17T10:00:00',
                            likeCount: 3
                        },
                        {
                            commentId: 2,
                            content: '內容很有幫助，學到了很多。',
                            authorName: 'Bob',
                            createdAt: '2025-08-17T11:30:00',
                            likeCount: 1
                        }
                    ];
                    
                    storedComments = defaultComments;
                    this.comments.set(postId, storedComments);
                    this.saveStoredComments();
                    
                    console.log('已保存默認評論:', this.comments.get(postId));
                } else {
                    console.log('系統已有評論，當前文章暫無評論，保持空狀態');
                    // 系統已有評論，當前文章就正常保持無評論狀態
                }
            } else {
                console.log('當前文章已有評論:', storedComments.length, '條');
            }
            
            // 渲染評論並更新計數
            console.log('準備渲染評論:', storedComments);
            this.renderComments(storedComments);
            this.updateCommentCount(storedComments.length);
            
            // 更新評論表單顯示
            this.updateCommentForm();
        }
    }
    
    // 更新評論表單顯示
    updateCommentForm() {
        const commentForm = document.getElementById('comment-form');
        if (!commentForm) return;
        
        const isLoggedIn = window.AuthManager ? window.AuthManager.isLoggedIn() : false;
        
        if (isLoggedIn) {
            // 已登入用戶顯示評論輸入框
            commentForm.innerHTML = `
                <h6>發表評論</h6>
                <form id="new-comment-form">
                    <div class="mb-3">
                        <label for="comment-content" class="form-label">評論內容 *</label>
                        <textarea class="form-control" id="comment-content" rows="3" required 
                                   placeholder="請輸入您的評論內容"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane me-1"></i>發表評論
                    </button>
                </form>
            `;
        } else {
            // 未登入用戶顯示登入提示
            commentForm.innerHTML = `
                <div class="text-center py-3">
                    <i class="fas fa-lock fa-2x text-muted mb-2"></i>
                    <h6>請先登入後再發表評論</h6>
                    <p class="text-muted small">登入後即可參與討論</p>
                    <a href="login.html" class="btn btn-primary btn-sm">
                        <i class="fas fa-sign-in-alt me-1"></i>立即登入
                    </a>
                </div>
            `;
        }
        
        // 重新綁定事件
        this.bindEvents();
    }
    
    // 渲染評論列表
    renderComments(comments) {
        console.log('renderComments 被調用:', comments);
        const commentsList = document.getElementById('comments-list');
        if (!commentsList) {
            console.error('找不到 comments-list 元素');
            return;
        }
        
        if (!comments || comments.length === 0) {
            console.log('沒有評論要顯示，顯示空狀態');
            commentsList.innerHTML = `
                <div class="text-center text-muted">
                    <i class="fas fa-comments fa-2x mb-2"></i>
                    <p>暫無評論，來發表第一條評論吧！</p>
                </div>
            `;
            // 確保評論表單正確顯示
            this.updateCommentForm();
            return;
        }
        
        console.log('準備渲染', comments.length, '條評論');
        
        // 獲取當前登入用戶信息
        const currentUser = this.getCurrentUserInfo();
        
        const commentsHtml = comments.map(comment => {
            // 檢查當前用戶是否是評論作者
            const isAuthor = currentUser && (
                currentUser.username === comment.authorName || 
                currentUser.username === comment.author?.username ||
                currentUser.displayName === comment.authorName ||
                currentUser.displayName === comment.author?.displayName
            );
            
            return `
                <div class="comment-item border-bottom pb-3 mb-3" data-comment-id="${comment.commentId}">
                    <div class="d-flex justify-content-between align-items-start">
                        <div class="flex-grow-1">
                            <div class="d-flex align-items-center mb-2">
                                <img src="${comment.author?.avatar || 'images/placeholders/avatar-default.svg'}" 
                                     class="rounded-circle me-2" width="32" height="32" 
                                     alt="${comment.author?.displayName || comment.authorName || '匿名用戶'}">
                                <div>
                                    <strong class="comment-author">${comment.author?.displayName || comment.authorName || '匿名用戶'}</strong>
                                    <div class="small text-muted">
                                        ${this.formatDate(comment.createdAt)}
                                    </div>
                                </div>
                            </div>
                            <div class="comment-content">
                                <p class="mb-2">${comment.content}</p>
                            </div>
                            <div class="comment-actions">
                                <button class="btn btn-sm btn-outline-primary me-2" onclick="commentManager.likeComment(${comment.commentId})">
                                    <i class="fas fa-thumbs-up me-1"></i>讚 (${comment.likeCount || 0})
                                </button>
                                ${isAuthor ? `
                                    <button class="btn btn-sm btn-outline-warning me-2" onclick="commentManager.editComment(${comment.commentId})">
                                        <i class="fas fa-edit me-1"></i>編輯
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger" onclick="commentManager.deleteComment(${comment.commentId})">
                                        <i class="fas fa-trash me-1"></i>刪除
                                    </button>
                                ` : ''}
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
        
        commentsList.innerHTML = commentsHtml;
        
        // ✅ 確保評論表單始終顯示（即使已有評論）
        this.updateCommentForm();
    }
    
    // 更新評論數量
    updateCommentCount(count) {
        const commentCount = document.getElementById('comment-count');
        if (commentCount) {
            commentCount.textContent = count;
        }
    }
    
    // 獲取當前登入用戶信息
    getCurrentUserInfo() {
        try {
            // 首先檢查是否已登入
            if (!window.AuthManager || !window.AuthManager.isLoggedIn()) {
                return null;
            }
            
            // 從 localStorage 或 sessionStorage 獲取用戶信息
            const userInfo = localStorage.getItem('user') || sessionStorage.getItem('user');
            if (userInfo) {
                return JSON.parse(userInfo);
            }
            
            // 如果沒有用戶信息，嘗試從 token 解析
            const token = window.AuthManager ? window.AuthManager.getToken() : null;
            if (token && token.includes(':')) {
                const username = token.split(':')[0];
                return { username: username };
            }
            
            return null;
        } catch (error) {
            console.error('獲取當前用戶信息失敗:', error);
            return null;
        }
    }
    
    // 檢查用戶是否有權限編輯/刪除評論
    canEditComment(commentId) {
        // 檢查用戶是否已登入
        if (!window.AuthManager || !window.AuthManager.isLoggedIn()) {
            return false;
        }
        
        // 獲取當前用戶信息
        const currentUser = this.getCurrentUserInfo();
        if (!currentUser) {
            return false;
        }
        
        // 獲取評論信息
        const storedComments = this.comments.get(this.currentPostId) || [];
        const comment = storedComments.find(c => c.commentId === commentId);
        if (!comment) {
            return false;
        }
        
        // 檢查是否是評論作者
        const isAuthor = (
            currentUser.username === comment.authorName || 
            currentUser.username === comment.author?.username ||
            currentUser.displayName === comment.authorName ||
            currentUser.displayName === comment.author?.displayName
        );
        
        return isAuthor;
    }
    
    // 發表新評論
    async submitComment() {
        if (!this.currentPostId) {
            Utils.showToast('無法識別文章ID', 'error');
            return;
        }
        
        // 確保 postId 是數字類型
        const postId = parseInt(this.currentPostId);
        if (isNaN(postId)) {
            Utils.showToast('文章ID格式錯誤', 'error');
            return;
        }
        
        // 檢查用戶是否已登入
        if (!window.AuthManager || !window.AuthManager.isLoggedIn()) {
            Utils.showToast('請先登入後再發表評論', 'warning');
            return;
        }
        
        const content = document.getElementById('comment-content').value.trim();
        
        if (!content) {
            Utils.showToast('請填寫評論內容', 'warning');
            return;
        }
        
        try {
            // 從 localStorage 獲取用戶信息
            const token = window.AuthManager ? window.AuthManager.getToken() : null;
            if (!token) {
                Utils.showToast('無法獲取用戶信息，請重新登入', 'error');
                return;
            }
            
            // 從 token 中提取用戶名（假設格式為 username:timestamp）
            const tokenParts = token.split(':');
            if (tokenParts.length < 1) {
                Utils.showToast('Token 格式錯誤，請重新登入', 'error');
                return;
            }
            
            const username = tokenParts[0];
            
            // 創建評論數據
            const commentData = {
                postId: postId, // 使用轉換後的數字類型
                authorName: username,
                authorEmail: username + '@example.com',
                content: content
            };
            
            console.log('提交評論到後端 API:', commentData);
            
            // 調用後端 API 創建評論
            const response = await BlogAPI.comments.create(commentData);
            console.log('後端 API 回應:', response);
            
            if (response && response.success) {
                // API 成功，使用後端返回的評論數據
                const newComment = response.data;
                console.log('後端返回的評論數據:', newComment);
                
                // 保存到臨時存儲
                let storedComments = this.comments.get(this.currentPostId) || [];
                storedComments.unshift(newComment); // 添加到開頭
                this.comments.set(this.currentPostId, storedComments);
                
                // 保存到 localStorage
                this.saveStoredComments();
                
                // 顯示成功消息
                Utils.showToast('評論發表成功！', 'success');
                
                // 清空表單
                document.getElementById('comment-content').value = '';
                
                // 重新渲染評論列表
                this.renderComments(storedComments);
                this.updateCommentCount(storedComments.length);
                
                // ✅ 重新生成評論表單（確保可以繼續發表評論）
                this.updateCommentForm();
                
                // 更新側邊欄的最新評論
                if (window.BlogApp && typeof window.BlogApp.loadRecentComments === 'function') {
                    window.BlogApp.loadRecentComments();
                }
            } else {
                throw new Error('後端 API 返回錯誤: ' + (response?.message || '未知錯誤'));
            }
            
        } catch (error) {
            console.error('發表評論失敗:', error);
            Utils.showToast('評論發表失敗，請稍後再試', 'danger');
        }
    }
    
    // 編輯評論
    editComment(commentId) {
        // 檢查權限
        if (!this.canEditComment(commentId)) {
            Utils.showToast('您沒有權限編輯此評論', 'warning');
            return;
        }
        
        const commentItem = document.querySelector(`[data-comment-id="${commentId}"]`);
        if (!commentItem) return;
        
        const contentDiv = commentItem.querySelector('.comment-content p');
        const currentContent = contentDiv.textContent;
        
        // 替換為編輯表單
        contentDiv.innerHTML = `
            <div class="edit-comment-form">
                <textarea class="form-control mb-2" rows="3">${currentContent}</textarea>
                <div class="btn-group btn-group-sm">
                    <button class="btn btn-success" onclick="commentManager.saveCommentEdit(${commentId}, this)">
                        <i class="fas fa-save me-1"></i>保存
                    </button>
                    <button class="btn btn-secondary" onclick="commentManager.cancelCommentEdit(${commentId})">
                        <i class="fas fa-times me-1"></i>取消
                    </button>
                </div>
            </div>
        `;
    }
    
    // 保存評論編輯
    async saveCommentEdit(commentId, button) {
        const textarea = button.parentElement.previousElementSibling;
        const newContent = textarea.value.trim();
        
        if (!newContent) {
            Utils.showToast('評論內容不能為空', 'warning');
            return;
        }
        
        try {
            // 🆕 調用後端 API 更新評論
            await BlogAPI.comments.update(commentId, { content: newContent });
            console.log('✅ 更新評論 API 成功');
            
            // 更新本地存儲
            let storedComments = this.comments.get(this.currentPostId) || [];
            const commentIndex = storedComments.findIndex(comment => comment.commentId === commentId);
            if (commentIndex !== -1) {
                storedComments[commentIndex].content = newContent;
                storedComments[commentIndex].updatedAt = new Date().toISOString();
                this.comments.set(this.currentPostId, storedComments);
                this.saveStoredComments();
            }
            
            Utils.showToast('評論更新成功！', 'success');
            this.renderComments(storedComments);
            
        } catch (error) {
            console.error('❌ 更新評論 API 失敗:', error);
            
            // 🔧 Workaround: 如果是懶加載錯誤，檢查數據庫是否真的更新了
            if (error.message && error.message.includes('could not initialize proxy')) {
                console.warn('⚠️ 後端返回懶加載錯誤，但數據可能已保存，重新加載評論...');
                
                try {
                    // 從後端重新加載評論
                    await this.loadPostComments(this.currentPostId);
                    
                    // 檢查評論是否已更新
                    const reloadedComments = this.comments.get(this.currentPostId) || [];
                    const updatedComment = reloadedComments.find(c => c.commentId === commentId);
                    
                    if (updatedComment && updatedComment.content === newContent) {
                        console.log('✅ 驗證成功：評論已在數據庫中更新');
                        Utils.showToast('評論更新成功！', 'success');
                        this.renderComments(reloadedComments);
                    } else {
                        Utils.showToast('評論更新失敗，請稍後再試', 'danger');
                    }
                } catch (reloadError) {
                    console.error('❌ 重新加載評論失敗:', reloadError);
                    Utils.showToast('評論更新失敗，請稍後再試', 'danger');
                }
            } else {
                Utils.showToast('評論更新失敗，請稍後再試', 'danger');
            }
        }
    }
    
    // 取消評論編輯
    cancelCommentEdit(commentId) {
        // 重新渲染評論列表以恢復原始狀態
        if (this.currentPostId) {
            const storedComments = this.comments.get(this.currentPostId) || [];
            this.renderComments(storedComments);
        }
    }
    
    // 刪除評論
    async deleteComment(commentId) {
        // 檢查權限
        if (!this.canEditComment(commentId)) {
            Utils.showToast('您沒有權限刪除此評論', 'warning');
            return;
        }
        
        if (!confirm('確定要刪除這條評論嗎？此操作無法撤銷。')) {
            return;
        }
        
        try {
            // 🆕 調用後端 API 刪除評論
            await BlogAPI.comments.delete(commentId);
            console.log('✅ 刪除評論 API 成功');
            
            // 從本地存儲中刪除評論
            let storedComments = this.comments.get(this.currentPostId) || [];
            storedComments = storedComments.filter(comment => comment.commentId !== commentId);
            this.comments.set(this.currentPostId, storedComments);
            this.saveStoredComments();
            
            Utils.showToast('評論刪除成功！', 'success');
            this.renderComments(storedComments);
            this.updateCommentCount(storedComments.length);
            
        } catch (error) {
            console.error('❌ 刪除評論 API 失敗:', error);
            Utils.showToast('評論刪除失敗，請稍後再試', 'danger');
        }
    }
    
    // 點讚/取消點讚評論
    async likeComment(commentId) {
        try {
            // 檢查是否已經點過讚
            const likedComments = JSON.parse(localStorage.getItem('likedComments') || '[]');
            const currentUser = this.getCurrentUserInfo();
            const userLikeKey = `${currentUser?.username || 'guest'}_${this.currentPostId}_${commentId}`;
            const isAlreadyLiked = likedComments.includes(userLikeKey);
            
            // 更新臨時存儲中的點讚數
            let storedComments = this.comments.get(this.currentPostId) || [];
            const commentIndex = storedComments.findIndex(comment => comment.commentId === commentId);
            
            if (commentIndex !== -1) {
                let likeCountChange = 0;
                let successMessage = '';
                
                if (isAlreadyLiked) {
                    // 取消點讚
                    successMessage = '已取消點讚';
                    
                    // 檢查是否為本地生成的評論（時間戳ID）
                    if (typeof commentId === 'number' && commentId > 1000000000000) {
                        // 本地評論，跳過API調用
                        console.log('本地評論取消點讚，跳過API調用');
                        likeCountChange = -1;
                    } else {
                        try {
                            // 調用API取消點讚
                            const response = await BlogAPI.comments.unlike(commentId);
                            console.log('✅ 取消點讚 API 成功，響應:', response);
                            
                            // 🆕 使用 API 返回的實際 likeCount
                            if (response && response.data && response.data.likeCount !== undefined) {
                                storedComments[commentIndex].likeCount = response.data.likeCount;
                                console.log('✅ 使用 API 返回的點讚數:', response.data.likeCount);
                            } else {
                                // 備用：如果 API 沒返回 likeCount，才自己 -1
                                likeCountChange = -1;
                            }
                            
                            // 從記錄中移除
                            const updatedLikedComments = likedComments.filter(key => key !== userLikeKey);
                            localStorage.setItem('likedComments', JSON.stringify(updatedLikedComments));
                            
                        } catch (apiError) {
                            console.error('❌ 取消點讚 API 失敗:', apiError);
                            Utils.showToast('取消點讚失敗，請稍後再試', 'danger');
                            return; // 🆕 API 失敗直接返回，不更新本地數據
                        }
                    }
                } else {
                    // 添加點讚
                    successMessage = '點讚成功！';
                    
                    // 檢查是否為本地生成的評論（時間戳ID）
                    if (typeof commentId === 'number' && commentId > 1000000000000) {
                        // 本地評論，跳過API調用
                        console.log('本地評論點讚，跳過API調用');
                        likeCountChange = 1;
                    } else {
                        try {
                            // 調用API點讚
                            const response = await BlogAPI.comments.like(commentId);
                            console.log('✅ 點讚 API 成功，響應:', response);
                            
                            // 🆕 使用 API 返回的實際 likeCount
                            if (response && response.data && response.data.likeCount !== undefined) {
                                storedComments[commentIndex].likeCount = response.data.likeCount;
                                console.log('✅ 使用 API 返回的點讚數:', response.data.likeCount);
                            } else {
                                // 備用：如果 API 沒返回 likeCount，才自己 +1
                                likeCountChange = 1;
                            }
                            
                            // 記錄點讚狀態
                            likedComments.push(userLikeKey);
                            localStorage.setItem('likedComments', JSON.stringify(likedComments));
                            
                        } catch (apiError) {
                            console.error('❌ 點讚 API 失敗:', apiError);
                            Utils.showToast('點讚失敗，請稍後再試', 'danger');
                            return; // 🆕 API 失敗直接返回，不更新本地數據
                        }
                    }
                }
                
                // 🆕 只有在沒有從 API 獲取到實際值時，才自己計算
                if (likeCountChange !== 0) {
                    storedComments[commentIndex].likeCount = Math.max(0, (storedComments[commentIndex].likeCount || 0) + likeCountChange);
                }
                this.comments.set(this.currentPostId, storedComments);
                
                // 保存到 localStorage
                this.saveStoredComments();
                
                Utils.showToast(successMessage, 'success');
                
                // 重新渲染評論列表
                this.renderComments(storedComments);
            }
            
        } catch (error) {
            console.error('評論點讚操作失敗:', error);
            Utils.showToast('操作失敗，請稍後再試', 'danger');
        }
    }
    
    // 格式化日期
    formatDate(dateString) {
        if (!dateString) return '未知時間';
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('zh-TW') + ' ' + date.toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit' });
        } catch (error) {
            return '未知時間';
        }
    }
}

// 創建全局評論管理器實例
const commentManager = new CommentManager();

// 暴露到全局
window.commentManager = commentManager;
